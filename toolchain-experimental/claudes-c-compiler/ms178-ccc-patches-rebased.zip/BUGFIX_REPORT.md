# BUGFIX_REPORT — every bug fixed in this audit

All fixes are folded into the single unified `ms178-1.patch`. Verification method per fix:
compile/run repro → inspect generated assembly / encodings → confirm against ground truth
(GNU as 2.44, host GCC, or the sysroot glibc) → regression suite stays green.

## A. Inline-assembly output ABI (rewrites in `store_output_from_reg`)
- **Bug:** inline-asm outputs were stored through registers that could be clobbered by the
  instruction itself, and the store sequence ignored the full output-register set.
- **Fix:** `store_output_from_reg` now honors `all_output_regs`, picks a non-output scratch
  (`r10/r11/r8/r9/rsi/rdi`), and emits load-before-push for FPO (`%rsp`-relative) slots.
- **Evidence:** new regression cases `global_load_snapshot_inline_asm.c`, `asm_label_on_definition.c`.

## B. CPUID / copy-propagation miscompiles
- **Bug:** `copy_prop` treated `InlineAsm` outputs as non-uses, so copies feeding inline-asm outputs
  were eliminated and the CPUID feature-word results were wrong.
- **Fix:** `copy_prop.rs` counts `InlineAsm` outputs in use-analysis in both `one_round` and
  `one_round_post_phi`; `copy_prop` no longer rewrites an `Intrinsic` `dest_ptr` into a `GEP`;
  `loop_unroll.rs` counts `InlineAsm` outputs as uses.

## C. Register-variable miscompile (`movzbl %__GI__libc_intl_domainname, %__GI__libc_intl_domainname`)
- **Bug:** any `asm` label (including libc symbol names with `__GI__` prefixes) was treated as an
  x86 register name during variable lowering.
- **Fix:** `definitions.rs` / `lower.rs` gate register-variable handling on real register names via
  new `is_x86_register_name()`.
- **Evidence:** glibc `intl` code no longer emits self-movs; regression `float_direct_slot.c` etc.

## D. Vector temporary folding (`src/passes/fold_vec_temp.rs`)
- **Bug:** `alloca → intrinsic → memcpy → alloca` chains for over-aligned vector temporaries
  survived into codegen, producing stack bloat and missed forwarding.
- **Fix:** new fold pass (runs before the inliner, hooked in `src/passes/mod.rs`): folds the chain,
  remaps to the destination alloca, deletes dead allocas with
  `for_each_value_use_in_instruction`, downgrades over-aligned vector allocas, and keeps
  `source_spans` 1:1 so the debug-info invariant holds.

## E. `_Float128` / `__float128` full support (new)
- **Frontend:** token `Float128`, literal suffix `Q/q/f128` (+ `f16/f32/f64/f32x/f64x/f128x`
  mapping), parser types, predefined macros (`__FLT128_*`, `__SIZEOF_FLOAT128__`).
- **IR:** carrier type `U128`, `FloatLiteralF128`, classify as real_type_class in
  `__builtin_classify_type`.
- **Softfloat:** `emit_softfloat_call`, `convert_to_f128` / `convert_from_f128`, full op set
  (add/sub/mul/div/neg/lt/eq/ne/fabs/trunc/round/floor/ceil/rint/nearbyint/lrint/llrint/
  roundeven/signbit/huge_val/fma/copysign).
- **ABI (x86-64 SysV):** `_Float128` = ONE 16-byte XMM register:
  `is_f128_sse` (params), `ret_is_f128_sse`, `struct_arg_is_f128_sse` threaded through
  `IrParam`, `FuncSig`, `CallInfo`, `IrFunction`, plus `f128_ret_classes()`;
  `movdqu` moves on XMM; 29 initializer sites auto-fixed + 7 manual.
- **Evidence:** regression suite passes; F128 self-test passes (`F128 ALL OK`).

## F. Assembler: CET shadow-stack instruction encodings (new)
- **Bug:** `rstorssp`, `saveprevssp`, `setssbsy`, `clrssbsy`, `wrssd/q`, `wrussd/q` were not
  encodable — glibc 2.44 CET stubs could not assemble.
- **Fix:** encoders in `encoder/gp_integer.rs` + dispatch in `encoder/mod.rs`, **verified
  byte-for-byte against GNU as 2.44** (see table; note WRSS=`0F 38 F6`, WRUSS=`66 0F 38 F5` —
  the opcode pair is *not* swapped):

| instruction | bytes (LCCC == GNU as 2.44) |
|---|---|
| `incsspd %ecx` | `F3 0F AE E9` |
| `incsspq %rax` / `%r8` | `F3 48 0F AE E8` / `F3 49 0F AE E8` |
| `rstorssp (%rax)` | `F3 0F 01 28` |
| `clrssbsy (%rax)` | `F3 0F AE 30` |
| `saveprevssp` | `F3 0F 01 EA` |
| `setssbsy` | `F3 0F 01 E8` |
| `wrssd %eax,(%rax)` | `0F 38 F6 00` |
| `wrssq %r9,0x10(%rdi)` | `4C 0F 38 F6 4F 10` |
| `wrussd %eax,(%rax)` | `66 0F 38 F5 00` |
| `wrussq %rax,(%rax)` | `66 48 0F 38 F5 00` |

## G. Assembler: CFI directive hardening (new)
- **Bug:** `.cfi_offset %rbx, -2*8` (constant-expression offsets, glibc style) failed to parse;
  `.cfi_*` directives with non-trivial arguments aborted assembly.
- **Fix:** `.cfi_def_cfa_offset` and `.cfi_offset` now evaluate full constant expressions via
  `parse_integer_expr`; **every other `.cfi_*` directive** (`restore`, `adjust_cfa_offset`,
  `def_cfa`, `register`, `undefined`, `escape`, `personality`, `lsda`, `sections`,
  `signal_frame`, `remember/restore_state`, `val_offset`, `expression`, …) is recorded
  tolerantly as `CfiDirective::Other`. CFI stays parsed-but-not-emitted, matching upstream design.

## H. Assembler: C integer suffixes in constant expressions (new)
- **Bug:** `testl $(1U<<1), %fs:72` (glibc `setjmp`/shadow-stack checks) failed:
  `1U` was not tokenizable.
- **Fix:** `asm_expr.rs` tokenizer and `parse_single_integer` now accept C suffixes
  (`u/U/l/L/z/Z`, incl. `LL`/`ULL`); the glibc pattern assembles to `64 F7 04 25 48 00 00 00 02 …`.

## I. Driver: `-print-libgcc-file-name` / `-print-multi-directory` sysroot support (new)
- **Bug:** `-print-libgcc-file-name` returned a host `/usr/lib/…` path even when `--sysroot` was
  given; glibc's configure probes would bind to the wrong compiler runtime.
- **Fix:** capture `--sysroot`/`-isysroot` in `handle_query_flags`; search
  `<sysroot>/usr/lib/gcc/{triple,x86_64-pc-linux-gnu}/<version>/libgcc.a` with version-directory
  enumeration (Arch ships `16.1.1`, not `16`) before falling back to host dirs.
  `-print-multi-directory` keeps printing `.` (required by glibc's `csu/Makefile`).
- **Verified:** `lccc --sysroot=$S -print-libgcc-file-name` →
  `$S/usr/lib/gcc/x86_64-pc-linux-gnu/16.1.1/libgcc.a`.

## J. Driver: `-v` output GCC-detectable (new)
- **Bug:** zlib-ng's configure greps `-v` output for `gcc`; LCCC's banner lacked it, so the
  `-fPIC`/`-std=c11` shared-library path was skipped and `.lo` objects were built without `-fPIC`
  → shared-link failure (`relocation R_X86_64_PC32 against stderr can not be used …`).
- **Fix:** `-v` now also prints `gcc version 14.2.0 (lccc)`; zlib-ng then configures with
  `-fPIC -std=c11 -Wall` and its shared library links cleanly.

## K. `_Float128` ABI initializer completeness (new)
- **Bug:** after adding the `is_f128_sse` / `ret_is_f128_sse` / `struct_arg_is_f128_sse` /
  `param_is_f128_sse` fields, 30 `CallInfo`/`FuncSig`/`IrParam`/`IrFunction` initializer sites
  were missing the fields (E0063).
- **Fix:** deterministic inserter (29 sites, brace-matched, nesting-aware) + 7 manual repairs
  (single-line literals, indented closers, `ci()` helper in `pgo/instrument.rs`, indirect-call
  `CallInfo`, `pub(crate) f128_ret_classes`, `Float128` in `classify_ctype`).
- **Evidence:** full rebuild clean; **rebuilt driver byte-identical** to the pre-reset golden
  binary.

## L. Inline tuning (kept as validated, not raised)
- `MAX_INLINE_BLOCKS=6`, `MAX_CALLER_INSTRUCTIONS_AFTER_INLINE=200`, `MAX_SMALL_INLINE=20`;
  `select_inline_site` runs tiny/small sites first, normal second. Raising to 12/400 regressed
  compile-time/codegen; reverted and locked by the regression suite.


## M. TLS symbol typing for undefined symbols (new — glibc ld.so link)
- **Bug:** `errno.os` defined `__libc_errno` as STT_TLS in `.tbss`, but
  `uname.os` referenced it via `@GOTTPOFF` as STT_NOTYPE → ld rejects:
  "TLS definition … mismatches non-TLS reference".
- **Fix:** `elf/symbol_table.rs` tracks symbols referenced by TLS relocations
  (DTPMOD/DTPOFF/TPOFF/GOTTPOFF/TLSDESC + i386 TLS set) and emits them as
  `STT_TLS` in the symbol table. Verified: `readelf` shows
  `TLS GLOBAL DEFAULT UND __libc_errno`.

## N. `.uleb128` / `.sleb128` + GNU-as symbol-difference expressions (new)
- **Bug:** glibc's `libc_sigaction.c` emits `.long (.LSTART_restore_rt-1)-.`,
  `.uleb128 .LENDAUGMNT_-.LSTARTAUGMNT_` (forward refs, no spaces) — the
  assembler emitted a literal symbol `(.LSTART_restore_rt-1)-.` and the
  host ld failed: "relocation R_X86_64_32 against undefined symbol …".
- **Fix:** parser gains `try_parse_sym_diff`/`parse_sym_addend`
  (parenthesized, no-space `a-b`, `(a-1)-.` forms → SymbolDiffAddend);
  new `.uleb128`/`.sleb128` directives (AsmItem variants + numeric-label
  rewriting in `elf/numeric_labels.rs`); deferred LEB folding with
  10-byte placeholders, backwards splice-shrink and a
  `shift_section_offsets` helper that keeps labels/relocs/jumps/align
  markers/deferred skips consistent; diff reloc resolution now honors the
  addend; `fixup_alignment_markers` runs for EVERY section (previously only
  jump-containing sections got `.align` padding, so `.eh_frame` CIE padding
  was wrong).
- **Verified:** libc_sigaction `.eh_frame` **byte-identical to GNU as 2.44**
  (152 bytes: CIE/FDE lengths, uleb128 CFI expressions, PC32 relocs).

## O. `defined X` inside macro bodies (new — glibc ISA_SHOULD_BUILD)
- **Bug:** `#define ISA_SHOULD_BUILD(l) ((MINIMUM_X86_ISA_LEVEL <= l && IS_IN(libc)) || defined ISA_DEFAULT_IMPL)` — macro expansion turned
  `defined ISA_DEFAULT_IMPL` into `defined 1`, the #if evaluated false, and
  rtld string functions (strlen etc.) compiled to empty objects → undefined
  references at ld.so link.
- **Fix:** `macro_defs.rs::expand_text` copies `defined X` / `defined (X)`
  operands verbatim (C11 6.10.1p1) instead of expanding them.
- **Verified:** `int yes;` repro now matches GCC; `rtld-strlen.os` defines
  `T strlen`.

## P. `__builtin_mempcpy` / `__builtin_stpcpy` (new)
- **Bug:** rtld's `dl-exception.c`/`dl-deps.c` call `__builtin_mempcpy` /
  `__builtin_stpcpy`; LCCC emitted calls to the literal `__builtin_*`
  symbol → undefined references.
- **Fix:** map both to `mempcpy`/`stpcpy` in `sema/builtins.rs`.

## Q. `__extern_inline` / `__USE_EXTERN_INLINES` correctness (new)
- **Bug:** `__GNUC_STDC_INLINE__`/`__GNUC_GNU_INLINE__` selection in glibc's
  `sys/cdefs.h` was inconsistent, so `bits/stdlib-bsearch.h` (inline
  `__bsearch`) could be skipped, leaving `__bsearch` undefined in rtld.
- **Fix:** explicit `-fgnu89-inline` now reliably overrides `-std=`
  (see §J); the `__GNUC_*_INLINE__` macro set matches GCC in both modes.

## Z. libc.so final-link blockers (new — glibc `_null_auth` / `__pointer_chk_guard`)
- **Bug 1:** `get_struct_base_addr` (structs.rs) emitted `GlobalAddr` with the C
  name for struct/union member bases, skipping the `__asm__("label")` redirect.
  glibc's `include/rpc/auth.h` declares `libc_hidden_proto(_null_auth)`
  (`extern __typeof(_null_auth) _null_auth __asm__("__GI__null_auth")
  __attribute__((visibility("hidden")))`), so `svc.c`'s `_null_auth.oa_flavor`
  accesses emitted a HIDDEN undefined reference to plain `_null_auth` — but the
  only definition in the archive is `_null_auth@GLIBC_2.2.5` (rpc_common.c,
  `libc_hidden_nolink_sunrpc`), which a hidden UND cannot bind to.
- **Fix 1:** apply `asm_label_map` in `get_struct_base_addr`, mirroring
  lvalue.rs/expr.rs. Verified: `_null_auth.a` repro now emits `__GI__null_auth`
  (DEFAULT UND), byte-matching GCC 14/16.
- **Bug 2:** `build_elf_symbol_table` copied the *target's* visibility onto
  `.set` aliases. rtld.c's `strong_alias (__pointer_chk_guard_local,
  __pointer_chk_guard)` therefore produced a HIDDEN `__pointer_chk_guard` in
  librtld.os; the ld.map version script cannot export hidden symbols, so the
  built ld.so lacked `__pointer_chk_guard@@GLIBC_PRIVATE` and the libc.so link
  failed with *undefined reference to `__pointer_chk_guard'* (the real libc.so
  carries `U __pointer_chk_guard@GLIBC_PRIVATE`).
- **Fix 2:** alias visibility defaults to `STV_DEFAULT` unless the alias itself
  has an explicit `.hidden`/`.protected` directive (GNU as semantics). Verified:
  `__pcg` alias of a hidden object is GLOBAL DEFAULT while the object stays
  HIDDEN — identical to `as` output.
- **Fix 3:** `emit_symbol_attrs` resolves the asm label and covers defined
  globals, so hidden attributes land on the emitted label
  (`.hidden __GI__null_auth` in rpc_common.os, `.hidden __GI__dl_argv` in
  rtld.os) while pure-reference TUs emit no `.hidden` — GCC parity.
- **Verified:** all three against GNU as 2.44 objects and GCC 14 generated
  assembly; 30/30 regression suite re-run green after the round.

## R. `__attribute__((used))` roots for rtld (new — glibc `_dl_exception`/`rtld_timer_start`)
- **Bug:** `_dl_exception`/`rtld_timer_start` (referenced only from static
  constructors / `.data` initializers, not from call-graph roots) were
  dropped by `collect_referenced_static_functions` → undefined references
  at ld.so link.
- **Fix:** symbols declared `__attribute__((used))` are kept as roots
  (`glibc-fixes4.py`, `ref_collection.rs`).

## S. `__builtin_ia32_rdtsc` / `__builtin_ia32_rdtscp` (new — glibc `rtld_timer.c`)
- **Bug:** rdtsc/rdtscp intrinsics were unknown → `rtld_timer.c` failed to compile.
- **Fix:** `IntrinsicOp::Rdtsc/Rdtscp` + `X86Rdtsc/X86Rdtscp` with the canonical
  sequence `rdtsc; shlq $32, %rdx; orq %rdx, %rax` (rdtscp additionally
  `movl %ecx, (%rdi)` for the aux output).
- **Verified:** byte-identical to GCC 16 output.

## T. `still_called` gnu-inline semantics (new — glibc `free`/`__bsearch`)
- **Bug:** functions marked `__always_inline extern inline` (gnu89 mode) that
  remain called after inlining were emitted as declarations only, or
  conversely emitted when they should stay inline — glibc's `free` /
  `__bsearch` ended up undefined or duplicated.
- **Fix:** `passes/mod.rs` gates emission on the `still_called` analysis that
  now mirrors GCC's extern-inline rules (gnu89: emit if address taken or
  not fully inlined; c99: never emit).

## U. C23 attribute syntax `[[...]]` (new — glibc `stdio-common` sources)
- **Bug:** `[[gnu::...]]` / `[[__gnu__::...]]` attributes crashed the parser.
- **Fix:** `skip_gcc_extensions` (parse.rs) skips balanced `[[...]]` groups.

## V. `__GI__` redirect on data symbols (new — glibc `_nl_default_locale` etc.)
- **Bug:** for non-function globals, `__GI_x` (hidden alias) was not applied on
  the *load* path, so internal references bound to the public symbol instead
  of the hidden alias.
- **Fix:** `expr.rs` (load path) and `lvalue.rs` (`GlobalAddr`) map
  `__GI_`-prefixed references to the renamed global.

## W. Versioned `.symver` aliases — GNU-as semantics (new, re-verified — glibc `fmemopen`/`pthread_cond_*`/`_res`/`__ctype_*`)
- **Bug:** `.symver foo, bar@GLIBC_2_2` inserted an *unversioned* alias
  (truncated at `@`), so `compat_symbol(libc, X, X, V)` patterns
  (`.symver _res, _res@GLIBC_2_0`) created a **self-alias** → duplicate
  `_res`/`__ctype_b`/`fmemopen` definitions in one object → `multiple
  definition` errors at the `libc_pic.os` link.
- **Fix:** `elf_writer_common.rs` `AsmItem::Symver` handler implements GNU-as
  semantics: `alias@VERSION` (compat, single `@`) keeps the FULL versioned
  name as the alias symbol; `alias@@VERSION` (default, double `@`) renames to
  `alias`; self-alias guard skips `alias_name == name`.
- **Verified:** byte-identical symbol tables vs GNU as 2.44 for
  `foo@GLIBC_2_0`, `bar@@GLIBC_2_1`, `_res@GLIBC_2_0`, `svc_pollfd@GLIBC_2_2`
  (`nm` comparison). Stale objects built with the pre-fix compiler must be
  deleted (make does not detect the compiler change; `make clean` + rebuild).

## X. Self-alias skip in alias emission (new — glibc `ctype-info` duplicates)
- **Bug:** `__ctype_b_loc`-style self-aliases (`alias name == target`)
  produced duplicate symbol definitions.
- **Fix:** `emit_aliases` skips aliases whose name equals their target.

## Y. `@gottpoff` / `@tpoff` case-insensitive relocation modifiers (new — glibc multiarch strcmp)
- **Bug:** glibc's `sysdeps/x86_64/multiarch/strcmp-sse2.S` (and
  strcmp-avx2/evex/sse4_2, strcasecmp_l path) emit **lowercase**
  `movq __libc_tsd_LOCALE@gottpoff(%rip), %rax`. The encoder's
  `encode_modrm_mem` only matched uppercase `GOTTPOFF`, so the modifier fell
  through to `R_X86_64_PC32` — the linker then rejected the object:
  *"TLS definition in libc_pic.a(global-locale.os) section .tdata mismatches
  non-TLS reference in libc_pic.a(strcasecmp_l.os)"*.
- **Fix:** both `SymbolMod` match sites (RIP-relative and deferred) match on
  `modifier.to_ascii_lowercase()` — `gottpoff` → `R_X86_64_GOTTPOFF` (22),
  `gotpcrel` → `R_X86_64_GOTPCREL`, `tpoff` → `R_X86_64_TPOFF32`,
  `plt` → `R_X86_64_PLT32`. The initial fix attempt used the string
  `"gotpoff"` (one t) which never matched the correctly-lowercased
  `"gottpoff"` (two t's, `GOTTPOFF` → lowercase); the typo was caught by
  instrumenting the match arm (`ZZ_DEBUG`) and comparing the computed reloc
  type against the emitted ELF relocation.
- **Verified:** `foo@gottpoff(%rip)` and `foo@GOTTPOFF(%rip)` both emit
  `R_X86_64_GOTTPOFF` (readelf), `@GOTPCREL` still `R_X86_64_GOTPCREL`;
  instruction bytes `48 8B 05 00 00 00 00` identical to GNU as 2.44; glibc
  `libc_pic.a` now links past the TLS-mismatch error.

## Regression status
`tests/regression/run_regression.sh` → **30 passed, 0 failed** (includes `huft_build_crash`,
`frexp_volatile_global`, `sse2_intrinsic_semantics`, `vla_dynamic_stack`, `struct_by_value`,
`long_double_stack_varargs`, `i128_stack_argument`, and the new inline-asm / asm-label cases).
Re-verified after every fix round; final re-run after §Z with the installed binary (30/30 green).

## AA. Open item (glibc ld.so link, not yet fixed)
`librtld.os` still emits `R_X86_64_PC32 _dl_argv` for `_dl_argv[0]` / `_dl_argv - skip`
(array/pointer-arithmetic uses in `rtld.c` bypass the `__GI__` asm-label redirect —
the redirect is applied in `expr.rs` `lower_identifier` load path but not in the
array-to-pointer decay path). Tracked; needs the same `asm_label_map` resolution
in the decay path.
