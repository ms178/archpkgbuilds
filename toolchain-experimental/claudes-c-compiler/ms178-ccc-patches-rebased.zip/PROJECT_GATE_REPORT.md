# PROJECT_GATE_REPORT — real-world build gates with the final LCCC

All gates built **from source** with the final audited driver through the wrapper
`cc-lccc-noavx512.sh` (strips `-mno-avxvnni`, rejects AVX-512/VAES/VPCLMUL/GFNI ISA flags,
appends `-std=gnu17 --sysroot=$S -Wl,--dynamic-linker=… -Wl,-rpath,…`).

## Driver acceptance matrix (mandate)

| Flag | Result |
|---|---|
| `-O3 -march=raptorlake -mtune=raptorlake -fomit-frame-pointer` | ✅ accepted, used for all gates |
| `-Os` | ✅ accepted |
| `-c / -S / -E` | ✅ accepted (gate builds use `-c`, `-S`, `-E` probes) |
| `-std=gnu17` | ✅ accepted (wrapper default) |
| `-fPIC -shared` | ✅ accepted — zlib-ng shared library links (after `-v` fix, §J) |
| `-pg` | ✅ accepted (`-pg` profile build of zbench compiles) |
| `-flto` | ✅ accepted (object produced; LTO is not a codegen path) |
| `-print-multi-directory` | ✅ prints `.` (glibc-required) |
| `-print-libgcc-file-name` | ✅ sysroot-aware (glibc-required) |

## Gate results (LCCC)

| Gate | Version | Configure | Build | Test suite | Result |
|---|---|---|---|---|---|
| **gzip** | 1.14 | ✅ | ✅ | `make check`: **30 PASS / 0 FAIL / 0 ERROR** | ✅ |
| **expat** | 2.8.2 | ✅ | ✅ | `make check` **PASS** (runtests, 0 FAIL/0 ERROR); xmltest.sh 8/8 local cases (OASIS suite not shipped upstream) | ✅ |
| **zlib-ng** | 2.3.3 | ✅ | ✅ static+shared | `make test`: **zlib test OK** (static + shared) | ✅ |
| glibc | 2.44 | (blocked, see below) | — | — | ⚠️ |

Details:
- **gzip 1.14** (`make check`): all 30 tests PASS including `hufts`, `memcpy-abuse`,
  `reproducible`, `zgrep-*`, `znew-k` — zero regressions, zero segfaults.
- **expat 2.8.2**: `make check` PASS (1 test binary `runtests`, 0 FAIL/ERROR); local xmltest
  cases pass; the XML conformance suite requires the external OASIS dataset not shipped in the
  release tarball.
- **zlib-ng 2.3.3**: full configure (autodetect: SSE2/SSSE3/SSE4.1/SSE4.2/PCLMUL/AVX2 enabled,
  AVX-512 family correctly **not** enabled), builds `libz-ng.a` + `libz-ng.so.2.3.3`, `make test`
  passes for both. zlib-compat build (`--zlib-compat`, static) also builds and passes `make test`
  — used for zbench.
- **glibc 2.44 (stretch):** the previous session progressed to build attempt 13 (assembler
  acceptance of CET, CFI expressions, `$(1U<<1)` fs-offset tests, `__pthread_kill@PLT`
  sequences). This delivery's remaining blocker was the `bad src register` failure on
  `sysdeps/posix/raise.c` — the file still needs the LCCC assembler's movsx/movzx and/or CFI
  paths exercised; the *assembler-side* prerequisites (CET, CFI, C-suffix expressions) are all
  fixed and byte-verified in this delivery, so the next attempt should start from a strictly
  better position. Full glibc + torture remains open follow-up.

## Cross-checks
- All gate binaries run against the merged sysroot (glibc 2.44) with
  `--dynamic-linker=$S/usr/lib/ld-linux-x86-64.so.2 -rpath $S/usr/lib`.
- gzip output identical between compilers (md5): see `PERF_SIZE_REPORT` correctness line.
- zbench round-trip integrity check passes (compressed data decompresses bit-exact).
