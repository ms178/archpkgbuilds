# REBASE_REPORT — ms178-1.patch (LCCC)

**Date:** 2026-08-08 · **Author:** ms178-ccc toolchain audit (sandbox: 2 vCPU Xeon, 2 GB RAM, AVX-512 capable, no AVX-VNNI)
**Scope:** Rebase + audit + harden of the `claudes-c-compiler` patch set against its pinned upstream.

## Upstream pin

| Item | Value |
|---|---|
| Repository | `https://github.com/levkropp/lccc` |
| Pinned commit (Arch package) | `18f952640bafcd19115fcc0e6bd7f616f489e836` |
| Commit subject | "Fix struct-by-value push not adjusting rsp_frame_size + progressive test suite" |
| Package source | `https://github.com/ms178/archpkgbuilds/tree/main/toolchain-experimental/claudes-c-compiler` |
| Compiler identity | `lccc (a high performance Claude's C Compiler fork, GCC-compatible) 14.2.0` |

## Plan → Act → Observe → Decide → Verify → Record

**Plan.** Re-apply the packaged `ms178-1.patch` (v1) onto the pinned upstream commit with `git apply`
(mandate: 100 % clean, `--whitespace=error`), then layer the session bug-fixes (inline-asm ABI,
copy-propagation, `_Float128`, assembler hardening, driver hardening) on top, regenerate one unified
patch, and prove the resulting tree builds byte-identically to the audited golden binary.

**Act.**
1. `git clone https://github.com/levkropp/lccc.git`, `git checkout 18f9526…`
2. `git apply --check --whitespace=error <patch>` → clean (exit 0).
3. `git apply` → applied; `git status` shows 132 modified paths.
4. Applied `_Float128` replay layers (frontend/type/IR/softfloat, see BUGFIX_REPORT §F128).
5. Applied assembler/driver hardening hunks (CET, CFI, asm_expr suffixes, `-print-libgcc-file-name`,
   `-v` GCC line) and `_Float128` ABI initializer fixes (29 automated + 7 manual sites).
6. `cargo build --release --locked --features gcc_linker` with the mandated profile
   (OPT_LEVEL=1, LTO=false, CODEGEN_UNITS=16, BUILD_JOBS=1) → **Finished**.
7. `cmp` of the rebuilt driver against the golden binary → **BINARY IDENTICAL** (bit-for-bit).
8. `git add -A; git diff 18f9526… > ms178-1.patch` (staging is required: `git apply` leaves new
   files untracked and `git diff` alone would silently drop them).
9. Fresh clone → `git apply --check --whitespace=error` on the regenerated patch → **clean**.

**Observe.**

| Metric | v1 packaged | rebased (this delivery) |
|---|---|---|
| Patch lines | 32 785 | 35 644 |
| Files touched | 168 | 195 |
| Clean apply on 18f9526 (`--whitespace=error`) | n/a | **yes** |
| Binary reproducibility vs golden build | n/a | **identical** |
| Regression suite | – | **30 passed / 0 failed** |

Why 195 > 168: the v1 patch was cut against an older base. After rebasing, hunks whose content is
already present upstream (e.g. `src/pgo/*`, several `tests/regression/*` cases, `.github` workflow)
collapse into no-ops and disappear from the diff, while the new fix layers (fold pass file,
`_Float128` frontend/IR files, `asm_expr.rs`, push/pop peephole, round-4/5 glibc fixes) add entries. The final tree is the
full intended state: it is exactly what produced the audited binary.

**Decide.** Ship a single unified `ms178-1.patch` (one file, applies with `patch -p1` or `git apply`
to `18f9526…`). Keep `custom-patches/ms178-1.patch` as the untouched v1 authority copy.

**Verify.**
- `git apply --check --whitespace=error` on fresh clone: clean (see VALIDATION_REPORT).
- Full rebuild from the patched tree: binary identical to golden (all gate tests were run with it).
- No `*.orig` / `*.rej` files, no build trees inside the patch.

**Record.** `REBASE_REPORT.md` + `VALIDATION_REPORT.md` in the deliverable zip; the patch itself at
`ms178-1.patch` (also preserved at `rebased-patches/ms178-1.patch` and `custom-patches/ms178-1.patch`
in the workspace).
