# VALIDATION_REPORT — gates G0–G8

Legend: ✅ pass · ⚠️ partial/blocked · ❌ fail

| # | Gate | State | Evidence |
|---|---|---|---|
| G0 | Patch applies 100 % clean to pinned upstream | ✅ | `git apply --check --whitespace=error` on fresh `18f9526…` clone → exit 0 (twice: before and after regeneration) |
| G1 | LCCC builds with mandated profile | ✅ | `cargo build --release --locked --features gcc_linker`, `OPT_LEVEL=1 LTO=false CODEGEN_UNITS=16 BUILD_JOBS=1` → Finished; driver `--version` = 14.2.0 |
| G1b | Rebuild reproducibility | ✅ | Fresh tree from unified patch → binary **bit-identical** to golden (`cmp` clean) |
| G2 | Regression suite | ✅ | `tests/regression/run_regression.sh` → **30 passed, 0 failed** |
| G3 | gzip 1.14 build + tests | ✅ | 30/30 PASS, 0 FAIL, 0 ERROR (project gate) |
| G4 | expat 2.8.2 build + tests | ✅ | `make check` PASS, 0 FAIL/ERROR; xmltest 8/8 local |
| G5 | zlib-ng 2.3.3 perf target | ✅ | builds, `make test` OK static+shared; benchmarked (PERF_SIZE_REPORT) |
| G6 | zlib-ng size target | ✅ | sizes measured; no regression vs pre-audit build |
| G7 | glibc 2.44 build + torture (stretch) | ⚠️ | 18 blocker rounds resolved; clean rebuild now compiles the full tree, links `libc_pic.a` → `libc_pic.os.clean` → **builds `elf/ld.so`** (incl. `-z pack-relative-relocs`, version scripts). Last remaining error at report time: `R_X86_64_PC32 against _dl_argv` in `librtld.os` (rtld.c array-arg references bypass the `__GI__` redirect — tracked in BUGFIX_REPORT §Z; all other members of the link are clean). |
| G8 | No miscompiles in gates | ✅ | gzip outputs md5-identical between compilers; zbench round-trip integrity OK |

## Detailed verification log

1. **Patch hygiene.** `git apply --check --whitespace=error` → clean; no `*.orig`/`*.rej`;
   unified patch contains 187 files / 35 012 lines; v1 authority copy preserved untouched
   (`custom-patches/ms178-1.patch`, sha256 `da84cd30…`).
2. **Assembler ground truth.** 15 CET instruction encodings from the LCCC assembler compared
   byte-for-byte with GNU as 2.44 output (objdump) — **all identical** (BUGFIX_REPORT §F).
3. **CFI + expression handling.** `.cfi_offset %rbx, -2*8`, `.cfi_def_cfa_offset 8*2`,
   `.cfi_escape 0x10, 0x00`, `.cfi_personality`, `.cfi_lsda`, `.cfi_sections`,
   `.cfi_signal_frame` + `testl $(1U<<1), %fs:72` assemble without error.
4. **Driver probes.** `-dumpmachine` = `x86_64-linux-gnu`; `-print-multi-directory` = `.`;
   `-print-libgcc-file-name --sysroot=$S` → `$S/usr/lib/gcc/x86_64-pc-linux-gnu/16.1.1/libgcc.a`;
   `-v` contains `gcc version 14.2.0 (lccc)`.
5. **Feature tests.** `_Float128` self-test OK; F128 softfloat op set complete; regression
   suite includes the previously failing `movzbl %__GI__libc_intl_domainname` shape (register-
   variable gating) and inline-asm output-ABI cases.
6. **Environment sanity.** Baselines GCC 16.1.1+r595 and glibc 2.44+r6 verified by sha256
   against the pinned manifest (`baseline-tarballs.sha256`). No global `LD_LIBRARY_PATH`
   leakage (host tools unaffected).
7. **Benchmarks.** Deterministic corpus (seeded generator) + 5-run medians; LCCC side
   re-measured with the final compiler (results-lccc-final.txt); GCC16 column from same-sandbox
   baseline builds.
8. **Relocation-modifier fix (§Y).** `foo@gottpoff(%rip)` and `foo@GOTTPOFF(%rip)` both emit
   `R_X86_64_GOTTPOFF` (readelf), `@GOTPCREL` → `R_X86_64_GOTPCREL`; bytes `48 8B 05 00 00 00 00`
   identical to GNU as 2.44. The historical `"gotpoff"` (one-t) arm never matched
   `GOTTPOFF`→`"gottpoff"`; caught by instrumenting the arm and comparing the computed vs the
   emitted relocation.
9. **`.symver` fix (§W).** `nm` output of LCCC objects byte-matches GNU as 2.44 for
   `foo@GLIBC_2_0`, `bar@@GLIBC_2_1`, `_res@GLIBC_2_0`, `svc_pollfd@GLIBC_2_2`; glibc
   `libc_pic.a` links past the previous `multiple definition of '_res'`/`fmemopen`/`__ctype_b`
   errors (objects rebuilt with the fixed compiler).

## Known limits (honest disclosure)
- Benchmarks run on the sandbox Xeon (2 vCPU), not the user's i7-14700KF; absolute numbers
  differ, ratios are indicative.
- zlib-ng AVX-VNNI paths are disabled on this CPU (no AVX-VNNI) and AVX-512 paths disabled by
  the Raptor Lake target — the published numbers reflect SSE2…AVX2/PCLMUL only.
- `-flto` is accepted but LTO codegen is not implemented (documented upstream limitation).
- glibc full build (G7) remains the open stretch item.
