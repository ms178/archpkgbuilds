#!/usr/bin/env bash
# =============================================================================
# apply-patches.sh — apply the unified ms178-1.patch to LCCC upstream 18f9526
# Usage:  bash apply-patches.sh [path-to-lccc-source] [path-to-ms178-1.patch]
# Defaults: ./lccc (source tree) and ./ms178-1.patch
#
# Compatible with the Arch PKGBUILD prepare() flow (patch -p1) and with git.
# =============================================================================
set -euo pipefail

SRC=${1:-./lccc}
PATCH=${2:-./ms178-1.patch}
PIN=18f952640bafcd19115fcc0e6bd7f616f489e836

[ -f "$PATCH" ] || { echo "error: patch not found: $PATCH" >&2; exit 1; }
[ -d "$SRC" ] || { echo "error: source dir not found: $SRC" >&2; exit 1; }

cd "$SRC"

# 1. Verify the tree is at the pinned upstream commit (best effort).
if git rev-parse --is-inside-work-tree >/dev/null 2>&1; then
    HEAD=$(git rev-parse HEAD 2>/dev/null || true)
    if [ -n "$HEAD" ] && [ "$HEAD" != "$PIN" ]; then
        echo "warning: HEAD is $HEAD, expected $PIN (proceeding anyway)" >&2
    fi
fi

# 2. Dry-run check (strict: rejects trailing whitespace and fuzz).
if command -v git >/dev/null 2>&1; then
    echo "== git apply --check (strict) =="
    git apply --check --whitespace=error "$PATCH"
fi

# 3. Apply.
if command -v git >/dev/null 2>&1 && git rev-parse --is-inside-work-tree >/dev/null 2>&1; then
    echo "== git apply =="
    git apply --whitespace=nowarn "$PATCH"
else
    echo "== patch -p1 =="
    patch -p1 --batch --no-backup-if-mismatch < "$PATCH"
fi

echo "== applied: $(grep -c '^diff --git ' "$PATCH") files =="

# 4. Optional: rebuild with the mandated profile.
if [ "${LCCC_REBUILD:-0}" = "1" ]; then
    echo "== cargo build (release, opt-level=1, no LTO, -j1, gcc_linker) =="
    CARGO_PROFILE_RELEASE_OPT_LEVEL=1 CARGO_PROFILE_RELEASE_LTO=false \
    CARGO_PROFILE_RELEASE_CODEGEN_UNITS=16 CARGO_BUILD_JOBS=1 \
    cargo build --release --locked --features gcc_linker
fi

echo "== apply-patches.sh done =="
