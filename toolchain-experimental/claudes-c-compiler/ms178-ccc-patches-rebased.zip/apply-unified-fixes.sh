#!/usr/bin/env bash
# =============================================================================
# apply-unified-fixes.sh — ONE script applying ALL validated LCCC fixes
# (rounds 1-21) on top of the ms178-1.patch base (Agent A v6.2 + v6.3 merge).
#
# Usage:  bash apply-unified-fixes.sh [path-to-lccc-src]
# Default: ./ccc-src (the tree must already have ms178-1.patch applied).
#
# Every layer is idempotent (skip-if-already-applied), so re-running is safe.
# The patch snapshot in this zip (ms178-1.patch) ALREADY CONTAINS all of these
# fixes — this script exists so the individual fixes stay reproducible and
# reviewable as layers, exactly as the session produced them.
# =============================================================================
set -euo pipefail
WORK="$(cd "$(dirname "$0")" && pwd)"
SRC="${1:-$WORK/ccc-src}"
export RUSTUP_HOME="${RUSTUP_HOME:-$HOME/ccc-work/rustup}"
export CARGO_HOME="${CARGO_HOME:-$HOME/ccc-work/cargo}"
export PATH="$CARGO_HOME/bin:$PATH"

[ -d "$SRC/src" ] || { echo "error: source tree not found: $SRC" >&2; exit 1; }

run() { echo "== $1 =="; python3 "$WORK/$1"; }

# Round 1: session fixes (inline-asm ABI, copy-prop, gnu89, exceptions, ...)
run glibc-fixes.py
# Round 2: glibc unblockers (uleb128, symdiff, TLS typing, mempcpy, ...)
run glibc-fixes2.py
# Round 3: CET/CFI/asm-expr/driver hardening
run glibc-fixes3.py
# Round 4: rdtsc, still_called, used-roots, C23 attrs, __GI redirect
run glibc-fixes4.py
# Round 5: @gottpoff case-insensitivity (two-t typo), GNU-as .symver semantics
run glibc-fixes5.py
# Round 6: struct-base redirect, .set alias visibility, emit_symbol_attrs
run glibc-fixes6.py
# Round 7: Agent A audit merge — 12 ported glibc blockers
run glibc-fixes7.py
# Round 8: GNU-as symbol-difference parsing ((.LSTART_restore_rt-1)-.)
run glibc-fixes8.py
# Round 9: array-base __GI__ redirect (_dl_argv[0])
run glibc-fixes9.py
# Round 10: emit_aliases single resolution (__strdup -> __GI___strdup)
run glibc-fixes10.py
# Round 11: _Float128 builtins (huge_valf128, copysignf128, ...)
run glibc-fixes11.py
# Round 12: _Float128 <-> i128 casts (__fixtfti/__floattitf)
run glibc-fixes12.py
# Round 13: inline F128/LD copysign+fabs bit-ops + emit_store_f128_xmm0 pub
run glibc-fixes13.py
# Round 14: proper GNU symbol versioning in LCCC's ELF linker
run glibc-fixes14.py
# Round 15: vldmxcsr/vstmxcsr + %v/%x mnemonic hints
run glibc-fixes15.py
# Round 16: GCC 'd' operand modifier, AVX scalar 2-op, strlen fold, hex-float
run glibc-fixes16.py
# Round 17: --print-file-name= (double-dash, sysroot-aware, early exit)
run glibc-fixes17.py
# Round 18: x87 fsubr/fdivr + DC-base correctness fix
run glibc-fixes18.py
# Round 19: __builtin_constant_p(strlen(literal)) after inlining
run glibc-fixes19.py
# Round 20: versioned .symver references (compat_symbol_reference)
run glibc-fixes20.py
# Round 21: ABS symbols, sym@VER@MOD parsing, x87 mem compares, ffreep,
#           fcomi/fucomi, LDCopysign generic path
run glibc-fixes21.py
# Round 22: XMM const asm inputs, F128 const bit-ops, ConstantF128 as I128
run glibc-fixes22.py

echo "ALL 21 FIX ROUNDS APPLIED"
