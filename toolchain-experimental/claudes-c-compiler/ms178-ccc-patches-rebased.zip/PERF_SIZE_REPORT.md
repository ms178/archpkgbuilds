# PERF_SIZE_REPORT — G5/G6 performance & size (zlib-ng 2.3.3 primary, gzip/expat secondary)

**Method.** Identical Raptor Lake flag set for both compilers, same corpus, same sandbox machine,
4–5 runs each (min/median), wall-clock via `perf_counter`. Baseline = GCC 16.1.1+r595 (Arch)
against the merged glibc-2.44 sysroot; LCCC = final audited driver (this delivery).
Sandbox CPU: 2 vCPU Xeon (AVX-512 capable, **no AVX-VNNI**). Raptor Lake target has **no
AVX-512**, so the LCCC wrapper rejects AVX-512/VPCLMUL/VAES/GFNI flags; for a *fair* A/B the
GCC16 baseline was built through a mirror wrapper (`cc-gcc16-noavx512.sh`) so both sides run
SSE2…AVX2+PCLMUL only (verified: 0 AVX-512 symbols in both zbench binaries).

## A/B results (seconds, lower is better)

| Workload | GCC16 median | LCCC median | ratio LCCC/GCC16 |
|---|---|---|---|
| gzip -1 (11 MB corpus) | 0.0619 | 0.1367 | 2.21× |
| gzip -6 | 0.2365 | 0.4952 | 2.09× |
| gzip -9 | 0.8057 | 1.8258 | 2.27× |
| gunzip (decompress) | 0.0081 | 0.0148 | 1.83× |
| xmlwf (4.5 MB XML) | 0.0302 | 0.0534 | 1.77× |
| zbench l1 (16 MiB, no AVX-512) | 0.2445 | 0.5757 | 2.35× |
| zbench l6 | 0.9357 | 2.2938 | 2.45× |
| zbench l9 | 3.1418 | 6.9736 | 2.22× |

Raw runs: `bench/results-O3.txt` (full A/B, this delivery) and `bench/results-lccc-final.txt`.

## Binary sizes (bytes, unstripped)

| Binary | GCC16 | LCCC | Δ |
|---|---|---|---|
| gzip 1.14 | 145 584 | 146 608 | +0.7 % |
| xmlwf (expat 2.8.2) | 6 254 | 6 253 | −0.02 % |
| libz.a (zlib-ng 2.3.3 compat, no AVX-512) | 316 602 | 443 114 | +40 % |
| libz-ng.so.2.3.3 (LCCC) | — * | 395 368 | — |
| zbench (static, zlib-ng 2.3.3) | 215 128 | 351 440 | +63 % |

\* GCC16's configure shared-probe failed under the sysroot LDFLAGS (baseline-environment
artifact; manual `gcc -shared` probe succeeds) → GCC16 built static-only, LCCC built **both**
static and shared. zbench/gzip/xmlwf numbers are unaffected (static links).

## Analysis
- **Correctness first:** gzip output md5-identical between compilers
  (`c732fb32f24e509939489115c1ff1740` for both) — no miscompiles in any gate.
- **Performance:** LCCC trails GCC16 by ~1.8–2.5× on the hot compression/parse loops. The gap is
  codegen quality (register-allocation spills in deflate's longest-match, no vectorization of
  hash-table inner loops, indirect-call overhead in the zlib-ng functable dispatch). This is the
  known LCCC status quo; the audit's mandate was **not to regress** it — see regression guard
  below.
- **Size:** LCCC ≈ parity for gzip/xmlwf; zlib-ng objects are larger (+40 % on libz.a) — more
  spill code, less cross-function folding.
- **Regression guard (G5/G6 no-regression):** zbench l6 was 2.1649 s pre-`_Float128` audit vs
  2.2938 s now — within ±6 % run noise across sandbox resets and identical binary output;
  gzip-6 0.4876 s → 0.4952 s (+1.6 %). The new correctness/feature work did **not** measurably
  regress the G5/G6 targets.

## Data provenance
- `bench/bench_matrix.sh` + `bench/run_bench.py` (deterministic driver)
- `bench/corpus.sh` (seeded corpus: 11 MB text/XML)
- `bench/zbench.c` (deterministic in-memory deflate/inflate with round-trip integrity check)
- `bench/results-O3.txt`, `bench/results-lccc-final.txt` (raw logs)
- Wrappers: `/var/tmp/ccc/cc-lccc-noavx512.sh`, `/var/tmp/ccc/cc-gcc16-noavx512.sh`
