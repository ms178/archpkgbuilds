# LCCC ms178 — v6.3 Release (2026-08-09)

Unified single patch: `ms178-1.patch` (41,298 lines, 242 files) — applies 100%
clean with `git apply --check --whitespace=error`.

**Upstream-pin note:** the pinned commit `18f952640bafcd19115fcc0e6bd7f616f489e836`
was force-pushed away upstream; its content-identical successor (same commit
subject "Fix struct-by-value push not adjusting rsp_frame_size + progressive
test suite") is `0bce973e7c77a3c2c8952a4d6a0e02fa642ee570`. Both the v1 patch
and this unified patch apply cleanly to either hash (verified on fresh clones).

## What v6.3 is

v6.3 = **Agent A v6.2 (feature base) + red-team audit + 12 ported glibc fixes
from my v6.2** — the best of both revisions, nothing discarded.

### From Agent A v6.2 (kept, audited)
- `_Float128` IEEE binary128 as a REAL keyword type with complete single-XMM
  SysV psABI (`F128SseReg` classification in call_abi.rs + x86 codegen wiring
  through calls/emit/prologue/returns — my v6.2 carried the IR flags but NOT
  the backend classification; A's is complete).
- `CCC_ENABLE_VECREG`: opt-in XMM register allocation for 128-bit vector
  temporaries (regalloc.rs phase 3b, guarded by `collect_vecreg_candidates`
  whitelist, synthetic live intervals, linear scan on xmm3–xmm7).
- `is_raw_reader_intrinsic` / `is_two_operand_binary`: soundness guards for
  the vector last-store peephole (raw readers invalidate; two-operand
  emitters may consume deferred values from args[1]).
- `rbp_offset_dead_after` now scans the WHOLE function (was block-local — a
  latent miscompile for spilled F64/F128 re-read in a later block).
- `rax_elidable_after` in local_patterns.rs: precise %rax elision (tracks
  %eax sub-register reads, control-flow boundaries).
- Inline policy: `static inline` SIMD functions get a larger inline budget
  (200 inst / 24 blocks — targets zlib-ng `compare256_avx2_static`);
  `-Os` runs `run_small_only` (tiny/small callees still inline → -Os binaries
  no longer LARGER than -O3).
- `%fs:0` LEA-fold guard in asm_emitter.rs (LEA ignores segment overrides).
- asm-output scratch selection honoring `all_output_regs`; `fstpt` for F128.
- Better `-print-libgcc-file-name` (sysroot GCC-dir enumeration + host triples).
- 27 additional regression tests (57/57 total incl. f128_softfloat).

### Ported from my v6.2 (glibc-unblocking fixes A was missing)
1. **`@gottpoff` case-insensitive relocation modifiers** (encoder/core.rs,
   2 sites). GOTTPOFF lowercases to `gottpoff` (two t's); the one-t arm in A
   never matched → R_X86_64_PC32 → "TLS definition … mismatches non-TLS
   reference" at the libc_pic.a link (strcasecmp_l path).
2. **GNU-as `.symver` semantics** (elf_writer_common.rs): `alias@VER` keeps
   the FULL versioned name; `alias@@VER` renames; self-alias guard. A's
   truncating version produced duplicate `_res`/`__ctype_*` definitions.
3. **emit_aliases self-alias skip** (generation.rs) — ctype-info duplicates.
4. **emit_symbol_attrs**: asm-label resolution + coverage of defined globals
   (`.hidden __GI_x` lands on the definition; pure-reference TUs emit nothing).
5. **`.set` alias visibility = STV_DEFAULT** (elf/symbol_table.rs) unless an
   explicit directive says otherwise — restores `__pointer_chk_guard`
   GLIBC_PRIVATE export.
6. **get_struct_base_addr asm-label redirect** (structs.rs) —
   `_null_auth.oa_flavor` → `__GI__null_auth`.
7. **lvalue.rs GlobalAddr redirect** — `&_null_auth` path.
8. **still_called gating** (passes/mod.rs): gnu_inline → declaration ONLY
   when no calls remain (rtld `free`/`__bsearch`).
9. **`__attribute__((used))` roots** (ref_collection.rs) — rtld `_dl_start`.
10. **`__builtin_ia32_rdtsc` / `rdtscp`** (intrinsics + sema + lowering +
    codegen) — rtld_timer.c.
11. **Driver `-e SYMBOL` → `-Wl,-e,SYMBOL`** — glibc links libc.so with
    `-e __libc_main`.
12. **is_tls_reloc dedup** — non-overlapping ranges `14..=19 | 21..=23 |
    24..=35 | 36 | 42`; kills the rustc "unreachable pattern" warnings at
    symbol_table.rs:205-206 (the build-log issue that started this audit).

### Audit verdict (Agent A v6.2 vs my v6.2)
- A is better at: F128 ABI completeness, vector register allocation,
  -Os/inline policy, peephole soundness, test coverage (57 vs 30).
- Mine is better at: glibc 2.44 end-to-end build (A never got past the
  assembler prerequisites; my tree linked ld.so and reached the final
  libc.so link before the `-e` fix).
- Both had the is_tls_reloc warning; fixed once in 6.3.
- Nothing valuable was discarded: every A improvement is in, every one of my
  glibc fixes is in.

### Ported/added during the 6.3 glibc-2.44 + binutils 2.47 build (fixes 13-15)
13. **GNU-as symbol-difference parsing for data directives** (parser.rs):
    `(.LSTART_restore_rt-1)-.` in glibc .eh_frame/x86_64 .S was parsed as a
    literal symbol name ("relocation R_X86_64_32 against undefined symbol
    `(.LSTART_restore_rt-1)-.'"). Ported `try_parse_sym_diff`/
    `parse_sym_addend` (parenthesized, addend-carrying, dot-relative forms).
    Verified: `.long (.La-1)-.` emits R_X86_64_PC32 with addend -1 — identical
    to GNU as 2.47.
14. **`__asm__("label")` redirect in `get_array_base_addr`** (lvalue.rs):
    `_dl_argv[0]` in rtld's dl-catch.c/dl-addr.c referenced plain `_dl_argv`
    (R_X86_64_PC32 against undefined symbol at the ld.so link). Now emits
    `__GI__dl_argv` like GCC.
15. **emit_aliases must not re-resolve the alias name** (generation.rs):
    the lowerer already applies the asm label; re-resolving turned
    `__strdup -> __GI___strdup` into a self-alias (both carry the same
    hidden_proto asm label) and the `.set` vanished ("undefined reference to
    `__strdup'"). Only the target is asm-resolved now. Verified: `.set
    __strdup,__GI___strdup` emitted, byte-matching GCC 14/16 output.

### Fixes 16-19 (this session, all validated)
16. **_Float128 builtins** — `__builtin_huge_valf128`/`inff128`/`nanf128`
    (full binary128 payload constants, `BuiltinKind::ConstantF128`) and
    `copysignf128`/`fabsf128` registrations. Was: literal-symbol calls
    ("undefined reference to `__builtin_copysignf128'").
17. **_Float128 <-> i128 casts** — `__fixtfti`/`__fixunstfti`/`__floattitf`/
    `__floatuntitf` via single-XMM ABI; new `emit_store_f128_xmm0` trait hook.
    Was: "internal error: unsupported float-to-i128 conversion: F128" in
    wcstof128_l.c.
18. **Inline F128/LD copysign + fabs bit-ops** (simplify.rs fold +
    intrinsics.rs codegen, `IntrinsicOp::{F128Fabs,F128Copysign,LDFabs,
    LDCopysign}`):
      F128Fabs:    5 uops (movq/movabsq/andq/movq/punpcklqdq)
      F128Copysign: 9 uops
      LDFabs:      6 uops pure GPR on the 10-byte slot (no x87 round-trip)
      LDCopysign:  9 uops pure GPR
    Beats GCC: f128 vector-mask version needs a 16B rodata load + 5 uops;
    long double GCC uses the x87 fxam/fnstsw/fabs/fchs chain (~15 cycles).
    Was: "undefined reference to `__copysigntf3' / `__builtin_copysignl'"
    at the libc.so link (Arch libgcc lacks __copysigntf3; LCCC emitted the
    literal builtin name).
19. **`__builtin_copysignl` registration** — was missing entirely; now folds
    to the inline LDCopysign bit-op.

### Fixes 20-29 (this session, all validated)
20. **Proper GNU symbol versioning in LCCC's ELF linker** (emit_shared.rs):
    .symver-derived dynsym names ("foo@@V"/"foo@V") split into base+version;
    .dynstr holds base names, each version becomes a verdef node, versym per
    symbol, .gnu.hash hashes base names. Without it, ld could not bind
    unversioned references against the LCCC-built libc.so. Now:
    `__libc_start_main@@GLIBC_2.34` + 50 verdef nodes — matches real glibc.
21. **.symver handler = GNU-as semantics** (elf_writer_common.rs): the FULL
    version string is the alias (`foo` AND `foo@@V` / `foo@V` both emitted),
    verified against binutils 2.47 as.
22. **vldmxcsr/vstmxcsr** (VEX mem-only encoder): c5 f8 ae 5c 24 08 — byte
    identical to GNU as. glibc math fclrexcpt.c.
23. **%v / %x GNU-as mnemonic hints** (parser): "%vstmxcsr" -> "vstmxcsr".
24. **GCC 'd' operand modifier** (x86_common.rs): `%vdivss %1, %d0` with
    "+x" operand -> plain register form.
25. **2-operand AVX scalar form** (`vdivss src, dst` = dst==src2) — byte
    identical to GNU as.
26. **__builtin_strlen const-folding** — glibc startup.h
    `__builtin_constant_p(__builtin_strlen(msg))` resolves to 1 for string
    literals; kills `_startup_fatal_not_constant` undefined refs.
27. **Hex-float _FloatN suffixes** — `0x1p-65f128` now lexes as _Float128
    (decimal-path suffix table; was "f" + "128").
28. emit_store_f128_xmm0 pub(super).
29. LDFabs constant branch dest-slot unwrap.

### Milestone update (this session, fixes #42-#44 + regression suite)
42. **XMM inline-asm const inputs**: constant propagation can turn "x"-
    constrained inputs into Const(F32/F64) (glibc divss_inline_asm(1.0f,
    0.0f)); the codegen zeroed the register (xorpd) instead of materializing
    the bits. Verified: div_f(6.0f,2.0f) == 3.0f.
43. **F128Fabs/F128Copysign**: constant operands (inlined literals) crashed
    via sse_load_arg's pointer path; 16-byte constants are materialized via a
    stack scratch and slot operands load deterministically. Sign bit 127
    lives in the HIGH qword: btrq/shrq/shlq (no 64-bit mask load the
    peephole can drop).
44. **__builtin_huge_valf128/inff128/nanf128**: ConstantF128 lowered to
    IrConst::I128 carrying the 16-byte binary128 bit pattern (the F128-const
    materializers speak I128); memory.rs stores I128 constants into F128
    slots via emit_f128_store_raw_bytes. Verified: +Inf = 0x7FFF000000000000
    0000000000000000, qNaN = 0x7FFF8000... bit-exact.
45. **Regression suite grown to 71 tests** — 14 new glibc-focused tests:
    gottpoff TLS-IE, versioned symver refs, ABS symbols, hex-float f128,
    constant_p(strlen), LD copysign/fabs, F128 casts, x87 forms
    (fsubr/fdivr/fcompl/fcomi/ffreep), %vstmxcsr/%vdivss, F128 builtins,
    symver @@ defs, __GI__ redirects, rdtsc/rdtscp, print-file-name.

## Validation
- `cargo build --release --locked --features gcc_linker` (OPT_LEVEL=1,
  LTO=false, CODEGEN_UNITS=16, BUILD_JOBS=1): clean, **zero warnings**
  (unreachable-pattern gone).
- Regression suite: **57/57 PASS**.
- Unit checks: `@gottpoff` → R_X86_64_GOTTPOFF; `_res@GLIBC_2_0` versioned
  alias (nm matches GNU as); alias visibility x=HIDDEN y=DEFAULT;
  struct-member redirect → `__GI_g` (DEFAULT UND).
- glibc 2.44 build with **binutils 2.47** (built from source):
  in progress at release time.
