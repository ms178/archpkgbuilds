#!/usr/bin/env python3
"""glibc-fixes11.py — v6.3 fix #16: _Float128 builtins
(__builtin_huge_valf128 / inff128 / nanf128 / copysignf128 / fabsf128).

glibc math (s_copysignf128.c, strtof128_l.c, wcstof128_l.c) uses these; they
were emitted as literal-symbol calls -> "undefined reference to
`__builtin_copysignf128'/'__builtin_huge_valf128'" at the libc.so link.

Design:
- BuiltinKind::ConstantF128([u8;16]) — full binary128 payload constants
  (0x7FFF... = +Inf, 0x7FFF8000... = qNaN), lowered to
  IrConst::long_double_with_bytes.
- __builtin_copysignf128/__builtin_fabsf128 -> libgcc soft-float aliases
  (__copysigntf3/__fabstf2) — later replaced by inline bit-ops (fix #18).
- builtin_return_type: inff128/huge_valf128/nanf128 -> IrType::F128.
"""
import sys

SRC = '/home/user/ccc-work/sources/ccc-src/'

def sub1(path, old, new, tag):
    p = SRC + path
    s = open(p).read()
    if new in s:
        print(f"skip (already applied): {tag}: {path}")
        return
    n = s.count(old)
    if n != 1:
        print(f"FAIL {tag}: {path}: found {n} of {old[:70]!r}")
        sys.exit(1)
    open(p, 'w').write(s.replace(old, new))
    print(f"ok {tag}: {path}")

sub1('src/frontend/sema/builtins.rs',
'''    /// Evaluate to a compile-time float constant.
    ConstantF64(f64),''',
'''    /// Evaluate to a compile-time float constant.
    ConstantF64(f64),
    /// Evaluate to a compile-time _Float128 constant (full 16-byte IEEE-754
    /// binary128 payload; glibc math uses __builtin_huge_valf128 etc.).
    ConstantF128([u8; 16]),''',
'kind_f128')

sub1('src/frontend/sema/builtins.rs',
'''    fn constant_f64(val: f64) -> Self {''',
'''    fn constant_f128(bytes: [u8; 16]) -> Self {
        BuiltinInfo { kind: BuiltinKind::ConstantF128(bytes) }
    }

    fn constant_f64(val: f64) -> Self {''',
'ctor_f128')

sub1('src/frontend/sema/builtins.rs',
'''    m.insert("__builtin_nanl", BuiltinInfo::constant_f64(f64::NAN));''',
'''    m.insert("__builtin_nanl", BuiltinInfo::constant_f64(f64::NAN));
    // _Float128 variants (IEEE binary128): +Inf = 0x7FFF0000...0,
    // qNaN = 0x7FFF8000...0 (big-endian byte order in the 16-byte payload).
    m.insert("__builtin_huge_valf128", BuiltinInfo::constant_f128([
        0x7F, 0xFF, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    ]));
    m.insert("__builtin_inff128", BuiltinInfo::constant_f128([
        0x7F, 0xFF, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    ]));
    m.insert("__builtin_nanf128", BuiltinInfo::constant_f128([
        0x7F, 0xFF, 0x80, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    ]));
    m.insert("__builtin_copysignf128", BuiltinInfo::simple("__copysigntf3"));
    m.insert("__builtin_fabsf128", BuiltinInfo::simple("__fabstf2"));''',
'regs_f128')

sub1('src/ir/lowering/expr_builtins.rs',
'''            BuiltinKind::ConstantF64(val) => {''',
'''            BuiltinKind::ConstantF128(bytes) => {
                // _Float128 constant: full 16-byte binary128 payload.
                Some(Operand::Const(IrConst::long_double_with_bytes(
                    f64::INFINITY, *bytes,
                )))
            }
            BuiltinKind::ConstantF64(val) => {''',
'lower_f128')

sub1('src/ir/lowering/expr_types.rs',
'''            "__builtin_infl" | "__builtin_huge_vall" => Some(IrType::F128),''',
'''            "__builtin_infl" | "__builtin_huge_vall" => Some(IrType::F128),
            "__builtin_inff128" | "__builtin_huge_valf128" | "__builtin_nanf128" => Some(IrType::F128),''',
'types_f128')

sub1('src/ir/lowering/expr_types.rs',
'''            | "__builtin_fmin" | "__builtin_fmax" | "__builtin_copysign"''',
'''            | "__builtin_fmin" | "__builtin_fmax" | "__builtin_copysign"
            | "__builtin_copysignf128" | "__builtin_fabsf128"''',
'types_f128_2')

print("ROUND-11 F128 BUILTINS APPLIED")
