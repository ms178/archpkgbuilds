#!/usr/bin/env python3
"""glibc-fixes17.py — v6.3 fix #30: `--print-file-name=` (double-dash) query
support with sysroot-aware search, as an EARLY-EXIT arm in handle_query_flags.

glibc's link rules use backticks around
`${CC} --print-file-name=crtbeginS.o`; the single-dash arm lived in
parse_main_args (after the "no input files" check) and the double-dash form
was not recognized at all -> "ccc: error: no input files" at the link step.

Also accepts the --print-* double-dash variants of the other query flags.
"""
import sys

SRC = '/home/user/ccc-work/sources/ccc-src/'

def sub1(path, old, new, tag):
    p = SRC + path
    s = open(p).read()
    if new in s:
        print(f"skip (already applied): {tag}")
        return
    n = s.count(old)
    if n != 1:
        print(f"FAIL {tag}: {path}: found {n} of {old[:70]!r}")
        sys.exit(1)
    open(p, 'w').write(s.replace(old, new))
    print(f"ok {tag}: {path}")

sub1('src/driver/cli.rs',
'''                "-print-libgcc-file-name" => {''',
'''                "-print-libgcc-file-name" | "--print-libgcc-file-name" => {''',
'print_libgcc_ddash')

sub1('src/driver/cli.rs',
'''                "-print-multi-directory" => {''',
'''                "-print-multi-directory" | "--print-multi-directory" => {''',
'print_multidir_ddash')

sub1('src/driver/cli.rs',
'''                "-print-search-dirs" => {''',
'''                "-print-search-dirs" | "--print-search-dirs" => {''',
'print_search_dirs_ddash')

# --print-file-name= early-exit arm (sysroot-aware), before "--version"
sub1('src/driver/cli.rs',
'''                "--version" => {''',
'''                _ if arg.starts_with("-print-file-name=") || arg.starts_with("--print-file-name=") => {
                    // glibc link rules: `${CC} --print-file-name=crtbeginS.o`.
                    let name = arg.trim_start_matches('-').trim_start_matches('-');
                    let name = name.strip_prefix("print-file-name=").unwrap_or(name);
                    if name == "include" {
                        if let Some(bundled) = crate::frontend::preprocessor::Preprocessor::bundled_include_dir() {
                            println!("{}", bundled.display());
                            return Ok(true);
                        }
                    }
                    let mut search_dirs: Vec<String> = Vec::new();
                    if let Some(ref sroot) = sysroot {
                        for gcc_triple in ["x86_64-pc-linux-gnu", target.triple()] {
                            let base = format!("{}/usr/lib/gcc/{}/", sroot, gcc_triple);
                            search_dirs.push(base.clone());
                            if let Ok(rd) = std::fs::read_dir(&base) {
                                let mut vers: Vec<String> = rd
                                    .filter_map(|e| e.ok())
                                    .filter(|e| e.file_type().map(|t| t.is_dir()).unwrap_or(false))
                                    .map(|e| e.file_name().to_string_lossy().to_string())
                                    .filter(|n| n.chars().next().map(|c| c.is_ascii_digit()).unwrap_or(false))
                                    .collect();
                                vers.sort();
                                vers.reverse();
                                for v in vers {
                                    search_dirs.push(format!("{}{}/", base, v));
                                }
                            }
                        }
                        search_dirs.push(format!("{}/usr/lib/", sroot));
                    }
                    let triple = target.triple();
                    search_dirs.push(format!("/usr/lib/gcc/{}/13/", triple));
                    search_dirs.push(format!("/usr/lib/{}/", triple));
                    search_dirs.push("/usr/lib/".to_string());
                    let mut found = false;
                    for dir in &search_dirs {
                        let path = format!("{}{}", dir, name);
                        if std::path::Path::new(&path).exists() {
                            println!("{}", path);
                            found = true;
                            break;
                        }
                    }
                    if !found {
                        println!("{}", name);
                    }
                    return Ok(true);
                }
                "--version" => {''',
'print_filename_early')

print("ROUND-17 PRINT-FILE-NAME FIX APPLIED")
