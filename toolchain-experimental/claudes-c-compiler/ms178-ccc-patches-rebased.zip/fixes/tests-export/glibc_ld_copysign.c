/* glibc_ld_copysign.c — long-double copysign/fabs bit ops. glibc
 * k_casinhl.c used to panic "LDCopysign: unsupported operand shape"; the
 * pure-GPR implementation (no x87 round-trip, byte 9 combine) must assemble
 * and run for slot-sourced and constant operands. */
#include <stdio.h>

int main(void) {
    long double x = 3.0L;
    long double a = __builtin_copysignl(x, -1.0L);   /* constant sign operand */
    long double b = __builtin_copysignl(-2.0L, x);  /* constant magnitude */
    long double c = __builtin_fabsl(-4.5L);
    /* The value path through registers is a tracked follow-up; the compile +
     * run without panic is the regression covered here. */
    (void)a; (void)b; (void)c;
    printf("PASS ld_copysign\n");
    return 0;
}
