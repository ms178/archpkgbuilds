#!/usr/bin/env python3
"""glibc-fixes16.py — v6.3 fixes #24-#27 (math libm unblockers).

#24 GCC 'd' operand modifier (x86_common.rs): glibc math-inline-asm.h uses
    VARGPREFIX "%d" -> `%vdivss %1, %d0` with a "+x" operand. '%dN' duplicates
    the operand; emit it in plain register form. Was: literal "%d0" text left
    in the instruction -> "AVX scalar 3-op requires 3 operands".
#25 2-operand AVX scalar form (avx.rs): GNU as accepts `vdivss src, dst`
    (implies dst == src2); LCCC required 3 operands. Byte-verified vs
    binutils 2.47: c5 fa 5e c1.
#26 __builtin_strlen const-folding (common/const_eval.rs): glibc startup.h
    `_startup_fatal` relies on `__builtin_constant_p(__builtin_strlen(msg))`
    being 1 for a string literal; without it, undefined
    `_startup_fatal_not_constant` at static link.
#27 hex-float _FloatN suffixes (lexer/scan.rs): `0x1p-65f128` was lexed as
    "0x1p-65f" + "128" (parse_simple_float_suffix only handled f/F/l/L).
    Use the full parse_float_suffix (f128/q/f16/...), like the decimal path.
"""
import sys

SRC = '/home/user/ccc-work/sources/ccc-src/'

def sub1(path, old, new, tag):
    p = SRC + path
    s = open(p).read()
    if new in s:
        print(f"skip (already applied): {tag}")
        return
    n = s.count(old)
    if n != 1:
        print(f"FAIL {tag}: {path}: found {n} of {old[:70]!r}")
        sys.exit(1)
    open(p, 'w').write(s.replace(old, new))
    print(f"ok {tag}: {path}")

# ---- #24a: accept 'd' modifier ----
sub1('src/backend/x86_common.rs',
'''            } else if matches!(chars[i], 'k' | 'w' | 'b' | 'h' | 'q' | 'l' | 'c' | 'a' | 'n')
                && i + 1 < chars.len() && (chars[i + 1].is_ascii_digit() || chars[i + 1] == '[') {''',
'''            } else if matches!(chars[i], 'k' | 'w' | 'b' | 'h' | 'q' | 'l' | 'c' | 'a' | 'n' | 'd')
                && i + 1 < chars.len() && (chars[i + 1].is_ascii_digit() || chars[i + 1] == '[') {''',
'd_modifier_recog')

# ---- #24b: 'd' = duplicate operand -> plain register form ----
sub1('src/backend/x86_common.rs',
'''    let is_raw = matches!(modifier, Some('c') | Some('P'));
    let is_neg = modifier == Some('n');''',
'''    // GCC's 'd' modifier duplicates the operand (glibc math-inline-asm.h uses
    // VARGPREFIX "%d" -> `%vdivss %1, %d0` with a "+x" operand): emit the
    // operand in its plain register form.
    let modifier = if modifier == Some('d') { None } else { modifier };
    let is_raw = matches!(modifier, Some('c') | Some('P'));
    let is_neg = modifier == Some('n');''',
'd_modifier_dup')

# ---- #25: 2-operand AVX scalar form ----
sub1('src/backend/x86/assembler/encoder/avx.rs',
'''    pub(crate) fn encode_avx_scalar_3op(&mut self, ops: &[Operand], opcode: u8, pp: u8) -> Result<(), String> {
        if ops.len() != 3 { return Err("AVX scalar 3-op requires 3 operands".to_string()); }
        let l = 0; // LIG - always 128-bit for scalar

        match (&ops[0], &ops[1], &ops[2]) {''',
'''    pub(crate) fn encode_avx_scalar_3op(&mut self, ops: &[Operand], opcode: u8, pp: u8) -> Result<(), String> {
        // GNU as also accepts the 2-operand form `vdivss src, dst`, which
        // implies dst == src2 (glibc math-inline-asm.h: `%vdivss %1, %d0`).
        let ops: &[Operand] = if ops.len() == 2 {
            &[ops[0].clone(), ops[1].clone(), ops[1].clone()]
        } else {
            ops
        };
        if ops.len() != 3 { return Err("AVX scalar 3-op requires 2 or 3 operands".to_string()); }
        let l = 0; // LIG - always 128-bit for scalar

        match (&ops[0], &ops[1], &ops[2]) {''',
'avx_scalar_2op')

# ---- #26: __builtin_strlen const-folding ----
sub1('src/common/const_eval.rs',
'''    match name {
        "__builtin_choose_expr" if args.len() >= 3 => {''',
'''    match name {
        "__builtin_strlen" | "strlen" => {
            // String literal -> compile-time length (without the NUL).
            // glibc startup.h: __builtin_constant_p(__builtin_strlen(msg)).
            if let Some(crate::frontend::parser::ast::Expr::StringLiteral(text, _)) = args.first() {
                Some(IrConst::I64(text.len() as i64))
            } else {
                None
            }
        }
        "__builtin_choose_expr" if args.len() >= 3 => {''',
'strlen_fold')

# ---- #27: hex-float _FloatN suffixes ----
sub1('src/frontend/lexer/scan.rs',
'''        // Check float suffix: f/F = float, l/L = long double
        let float_kind = self.parse_simple_float_suffix();
        let span = Span::new(start as u32, self.pos as u32, self.file_id);
        match float_kind {
            1 => Token::new(TokenKind::FloatLiteralF32(value), span),
            2 => {
                let hex_text = std::str::from_utf8(&self.input[start..self.pos]).unwrap_or("0x0p0");
                let f128_bytes = crate::common::long_double::parse_long_double_to_f128_bytes(hex_text);
                Token::new(TokenKind::FloatLiteralLongDouble(value, f128_bytes), span)
            }
            _ => Token::new(TokenKind::FloatLiteral(value), span),
        }''',
'''        // Check float suffix: full _FloatN set (f128/q/f16/f32/f64/f32x/f64x),
        // same as the decimal path. glibc uses `0x1p-65f128` literals.
        let (float_kind, _is_imaginary) = self.parse_float_suffix();
        let span = Span::new(start as u32, self.pos as u32, self.file_id);
        match float_kind {
            1 => Token::new(TokenKind::FloatLiteralF32(value), span),
            2 => {
                let hex_text = std::str::from_utf8(&self.input[start..self.pos]).unwrap_or("0x0p0");
                let f128_bytes = crate::common::long_double::parse_long_double_to_f128_bytes(hex_text);
                Token::new(TokenKind::FloatLiteralLongDouble(value, f128_bytes), span)
            }
            3 => {
                let hex_text = std::str::from_utf8(&self.input[start..self.pos]).unwrap_or("0x0p0");
                let f128_bytes = crate::common::long_double::parse_long_double_to_f128_bytes(hex_text);
                Token::new(TokenKind::FloatLiteralF128(value, f128_bytes), span)
            }
            _ => Token::new(TokenKind::FloatLiteral(value), span),
        }''',
'hex_float_suffix')

print("ROUND-16 FIXES 24-27 APPLIED")
