#!/usr/bin/env python3
"""Re-apply the glibc-unblocking session fixes on top of the self-contained
ms178-1.patch tree. Each step verified by assertion; tree then rebuilds to the
golden binary (cmp-verified), after which the TLS fix is added on top."""
import sys

SRC = '/home/user/ccc-work/sources/ccc-src/'

def sub1(path, old, new, tag=''):
    p = SRC + path
    s = open(p).read()
    n = s.count(old)
    if n != 1:
        print(f"FAIL {tag}: {path}: found {n} of {old[:70]!r}")
        sys.exit(1)
    open(p, 'w').write(s.replace(old, new))
    print(f"ok {tag}: {path}")

# ---------- 1. gnu89_inline_explicit (pipeline.rs) ----------
sub1('src/driver/pipeline.rs',
'''    pub(super) gnu89_inline: bool,
    /// Whether to dump preprocessor defines instead of preprocessed output (-dM).''',
'''    pub(super) gnu89_inline: bool,
    /// Set when -fgnu89-inline / -fno-gnu89-inline was given EXPLICITLY on the
    /// command line. GCC treats an explicit -fgnu89-inline/-fno-gnu89-inline as
    /// overriding any later -std= (which only implies the default inline model).
    /// Without this, glibc's `-std=gnu11 -fgnu89-inline` plus a trailing
    /// `-std=gnu17` from a driver wrapper would silently revert to C99 inline
    /// semantics, turning `extern __always_inline` into an external definition
    /// and causing "multiple definition" errors at partial-link time.
    pub(super) gnu89_inline_explicit: Option<bool>,
    /// Whether -fexceptions is in effect (defines __EXCEPTIONS like GCC).
    pub(super) exceptions: bool,
    /// Whether to dump preprocessor defines instead of preprocessed output (-dM).''',
'gnu89_explicit_field')

sub1('src/driver/pipeline.rs',
'''            gnu89_inline: false,
            dump_defines: false,''',
'''            gnu89_inline: false,
            gnu89_inline_explicit: None,
            exceptions: false,
            dump_defines: false,''',
'gnu89_explicit_init')

sub1('src/driver/pipeline.rs',
'''        if self.gnu89_inline {
            preprocessor.set_gnu89_inline(true);
        }''',
'''        if self.gnu89_inline {
            preprocessor.set_gnu89_inline(true);
        }
        // __EXCEPTIONS mirrors -fexceptions (GCC: defined for C only with
        // -fexceptions; glibc stdio-lock.h branches on it).
        preprocessor.set_exceptions(self.exceptions);''',
'gnu89_explicit_apply')

# ---------- 2. cli.rs: gnu89 explicit + exceptions parse + -std= protection ----------
sub1('src/driver/cli.rs',
'''                "-fgnu89-inline" => self.gnu89_inline = true,
                "-fno-gnu89-inline" => self.gnu89_inline = false,''',
'''                "-fgnu89-inline" => {
                    self.gnu89_inline = true;
                    self.gnu89_inline_explicit = Some(true);
                }
                "-fno-gnu89-inline" => {
                    self.gnu89_inline = false;
                    self.gnu89_inline_explicit = Some(false);
                }
                "-fexceptions" => self.exceptions = true,
                "-fno-exceptions" => self.exceptions = false,''',
'cli_exceptions')

sub1('src/driver/cli.rs',
'''                    // gnu89 and c89 use GNU inline semantics by default;
                    // gnu99+ and c99+ use C99 inline semantics.
                    // Note: -fgnu89-inline can override this later on the command line.
                    self.gnu89_inline = matches!(std_value, "gnu89" | "c89" | "gnu90" | "c90"
                        | "iso9899:1990" | "iso9899:199409");''',
'''                    // gnu89 and c89 use GNU inline semantics by default;
                    // gnu99+ and c99+ use C99 inline semantics.
                    // Note: an EXPLICIT -fgnu89-inline / -fno-gnu89-inline overrides
                    // any -std= (matching GCC: -std= only sets the default model).
                    if self.gnu89_inline_explicit.is_none() {
                        self.gnu89_inline = matches!(std_value, "gnu89" | "c89" | "gnu90" | "c90"
                            | "iso9899:1990" | "iso9899:199409");
                    }''',
'cli_std_protect')

# ---------- 3. predefined_macros.rs: set_exceptions ----------
sub1('src/frontend/preprocessor/predefined_macros.rs',
'''    /// Define __OPTIMIZE__ and __OPTIMIZE_SIZE__ based on the optimization level.''',
'''    /// Define/undefine `__EXCEPTIONS` based on `-fexceptions` (GCC-compatible).
    /// GCC defines `__EXCEPTIONS` when exceptions are enabled (-fexceptions for C,
    /// always for C++ unless -fno-exceptions). glibc's stdio-lock.h selects its
    /// lock-helper variant via `#ifdef __EXCEPTIONS`.
    pub fn set_exceptions(&mut self, enabled: bool) {
        if enabled {
            self.define_simple_macro("__EXCEPTIONS", "1");
        } else {
            self.macros.undefine("__EXCEPTIONS");
        }
    }

    /// Define __OPTIMIZE__ and __OPTIMIZE_SIZE__ based on the optimization level.''',
'predef_exceptions')

# ---------- 4. lower.rs: pub(crate) is_x86_register_name ----------
sub1('src/ir/lowering/lower.rs',
'''fn is_x86_register_name(name: &str) -> bool {''',
'''pub(crate) fn is_x86_register_name(name: &str) -> bool {''',
'is_x86_reg_pub')

# ---------- 5. global_decl.rs: gate register globals on real register names ----------
sub1('src/ir/lowering/global_decl.rs',
'''    fn try_lower_register_global(&mut self, decl: &Declaration, declarator: &InitDeclarator) -> bool {
        let Some(ref reg_name) = declarator.attrs.asm_register else { return false };
        let mut da = self.analyze_declaration(&decl.type_spec, &declarator.derived);''',
'''    fn try_lower_register_global(&mut self, decl: &Declaration, declarator: &InitDeclarator) -> bool {
        let Some(ref reg_name) = declarator.attrs.asm_register else { return false };
        // Only actual register names pin globals to registers. glibc uses
        // `extern char x[] __asm__("__GI_x")` (libc_hidden_proto) for plain
        // linker-symbol renaming; treating those as register variables made
        // the backend emit `movzbl %__GI__libc_intl_domainname, %...` and the
        // assembler failed with "bad src register". On non-x86 targets there
        // is no name predicate yet, so keep the historical behavior there.
        if matches!(self.target, crate::backend::Target::X86_64 | crate::backend::Target::I686)
            && !crate::ir::lowering::lower::is_x86_register_name(reg_name)
        {
            return false;
        }
        let mut da = self.analyze_declaration(&decl.type_spec, &declarator.derived);''',
'reg_global_gate')

# ---------- 6. external_tools.rs: stdin depfile ----------
sub1('src/driver/external_tools.rs',
'''            let input_name = if input_file == "-" { "<stdin>" } else { input_file };
            let content = format!("{}: {}\\n", output_file, input_name);
            let _ = std::fs::write(&dep_path, content);''',
'''            // Prefer the -MT/-MQ target when given (glibc passes -MT $@).
            let target = self.dep_target.as_deref().unwrap_or(output_file);
            if input_file == "-" {
                // Input came from stdin (glibc compiles syscall stubs with
                // `-x assembler-with-cpp -`). GCC omits the stdin pseudo-source
                // from the dependency rule; writing "<stdin>" here makes make
                // fail with "No rule to make target '<stdin>'". Emit a bare
                // "target:" rule (valid make syntax) plus no prerequisites.
                let _ = std::fs::write(&dep_path, format!("{}:\\n", target));
            } else {
                let content = format!("{}: {}\\n", target, input_file);
                let _ = std::fs::write(&dep_path, content);
            }''',
'depfile_stdin')

# ---------- 7. mod.rs: case-insensitive mnemonics ----------
sub1('src/backend/x86/assembler/encoder/mod.rs',
'''    fn encode_mnemonic(&mut self, instr: &Instruction) -> Result<(), String> {
        // Infer suffix for unsuffixed mnemonics (e.g., push -> pushq, mov -> movl)
        // This enables assembling hand-written .s files that omit AT&T size suffixes.
        let suffixed = infer_suffix(&instr.mnemonic, &instr.operands);
        let mnemonic = suffixed.as_str();
        let ops = &instr.operands;''',
'''    fn encode_mnemonic(&mut self, instr: &Instruction) -> Result<(), String> {
        // GNU as treats mnemonics case-insensitively (glibc .S files use
        // uppercase `LOCK`); normalize before dispatch.
        let mnemonic_raw = instr.mnemonic.to_ascii_lowercase();
        // Infer suffix for unsuffixed mnemonics (e.g., push -> pushq, mov -> movl)
        // This enables assembling hand-written .s files that omit AT&T size suffixes.
        let suffixed = infer_suffix(&mnemonic_raw, &instr.operands);
        let mnemonic = suffixed.as_str();
        let ops = &instr.operands;''',
'mnemonic_case')

# ---------- 8. mod.rs: sal aliases ----------
sub1('src/backend/x86/assembler/encoder/mod.rs',
'''            "shlq" | "shll" | "shlw" | "shlb" => self.encode_shift(ops, mnemonic, 4),''',
'''            // GNU as aliases: sal* == shl* (same opcode 4)
            "shlq" | "shll" | "shlw" | "shlb"
            | "salq" | "sall" | "salw" | "salb" => self.encode_shift(ops, mnemonic, 4),''',
'sal_aliases')

# ---------- 9. parser.rs: IFUNC SymbolKind ----------
sub1('src/backend/x86/assembler/parser.rs',
'''pub enum SymbolKind {
    Function,
    Object,
    TlsObject,
    NoType,
}''',
'''pub enum SymbolKind {
    Function,
    Object,
    TlsObject,
    NoType,
    /// STT_GNU_IFUNC (10): indirect function resolved at load time by its
    /// resolver (glibc uses `.type foo, %gnu_indirect_function`).
    GnuIndirectFunction,
}''',
'ifunc_enum')

sub1('src/backend/x86/assembler/parser.rs',
'''        "@notype" | "%notype" | "STT_NOTYPE" => SymbolKind::NoType,''',
'''        "@notype" | "%notype" | "STT_NOTYPE" => SymbolKind::NoType,
        "@gnu_indirect_function" | "%gnu_indirect_function" | "STT_GNU_IFUNC"
        | "@gnu_indirect_function," | "%gnu_indirect_function," => SymbolKind::GnuIndirectFunction,''',
'ifunc_parse')

# ---------- 10. elf_writer_common.rs: IFUNC mapping ----------
sub1('src/backend/elf_writer_common.rs',
'    STT_NOTYPE, STT_OBJECT, STT_FUNC, STT_TLS,',
'    STT_NOTYPE, STT_OBJECT, STT_FUNC, STT_TLS, STT_GNU_IFUNC,',
'ifunc_import')

sub1('src/backend/elf_writer_common.rs',
'''                Some(SymbolKind::TlsObject) => STT_TLS,
                Some(SymbolKind::NoType) | None => STT_NOTYPE,''',
'''                Some(SymbolKind::TlsObject) => STT_TLS,
                Some(SymbolKind::GnuIndirectFunction) => STT_GNU_IFUNC,
                Some(SymbolKind::NoType) | None => STT_NOTYPE,''',
'ifunc_map1')

sub1('src/backend/elf_writer_common.rs',
'''                    SymbolKind::TlsObject => STT_TLS,
                    SymbolKind::NoType => STT_NOTYPE,''',
'''                    SymbolKind::TlsObject => STT_TLS,
                    SymbolKind::GnuIndirectFunction => STT_GNU_IFUNC,
                    SymbolKind::NoType => STT_NOTYPE,''',
'ifunc_map2')

# ---------- 11. system.rs: XSAVE family ----------
sub1('src/backend/x86/assembler/encoder/system.rs',
'''    /// Encode FXSAVEQ: REX.W + 0F AE /0 (64-bit fxsave)''',
'''    /// Encode XSAVE-family: opcode /ext with optional forced REX.W (64-bit forms).
    /// GNU as encodings (verified against binutils 2.44):
    ///   xsave m       0F AE /4      xsave64 m     REX.W 0F AE /4
    ///   xrstor m      0F AE /5      xrstor64 m    REX.W 0F AE /5
    ///   xsaveopt m    0F AE /6      xsaveopt64 m  REX.W 0F AE /6
    ///   xsavec m      0F C7 /4      xsavec64 m    REX.W 0F C7 /4
    ///   xsaves m      0F C7 /5      xsaves64 m    REX.W 0F C7 /5
    ///   xrstors m     0F C7 /3      xrstors64 m   REX.W 0F C7 /3
    ///   fxrstor m     0F AE /1
    pub(crate) fn encode_xsave_family(
        &mut self, ops: &[Operand], opcode: &[u8], ext: u8, force_rex_w: bool,
    ) -> Result<(), String> {
        if ops.len() != 1 {
            return Err("instruction requires 1 memory operand".to_string());
        }
        match &ops[0] {
            Operand::Memory(mem) => {
                if force_rex_w {
                    let rex_b = mem.base.as_ref().is_some_and(|r| needs_rex_ext(&r.name));
                    let rex_x = mem.index.as_ref().is_some_and(|r| needs_rex_ext(&r.name));
                    self.bytes.push(self.rex(true, false, rex_x, rex_b));
                } else {
                    self.emit_rex_rm(0, "", mem);
                }
                self.bytes.extend_from_slice(opcode);
                self.encode_modrm_mem(ext, mem)
            }
            _ => Err("instruction requires memory operand".to_string()),
        }
    }

    /// Encode FXSAVEQ: REX.W + 0F AE /0 (64-bit fxsave)''',
'xsave_family_fn')

sub1('src/backend/x86/assembler/encoder/mod.rs',
'''            "fxsaveq" | "fxsave64" => self.encode_fxsaveq(ops),   // REX.W + 0F AE /0
            "fxrstorq" | "fxrstor64" => self.encode_fxrstorq(ops),  // REX.W + 0F AE /1
''',
'''            "fxsaveq" | "fxsave64" => self.encode_fxsaveq(ops),   // REX.W + 0F AE /0
            "fxrstorq" | "fxrstor64" => self.encode_fxrstorq(ops),  // REX.W + 0F AE /1
            // XSAVE family (encodings verified against GNU as 2.44)
            "xsave" => self.encode_xsave_family(ops, &[0x0F, 0xAE], 4, false),
            "xsave64" => self.encode_xsave_family(ops, &[0x0F, 0xAE], 4, true),
            "xrstor" => self.encode_xsave_family(ops, &[0x0F, 0xAE], 5, false),
            "xrstor64" => self.encode_xsave_family(ops, &[0x0F, 0xAE], 5, true),
            "xsaveopt" => self.encode_xsave_family(ops, &[0x0F, 0xAE], 6, false),
            "xsaveopt64" => self.encode_xsave_family(ops, &[0x0F, 0xAE], 6, true),
            "xsavec" => self.encode_xsave_family(ops, &[0x0F, 0xC7], 4, false),
            "xsavec64" => self.encode_xsave_family(ops, &[0x0F, 0xC7], 4, true),
            // Note: binutils encodes xsaves with ModRM /5 and xrstors with
            // /3 (empirically verified against GNU as 2.44) — byte-identical.
            "xsaves" => self.encode_xsave_family(ops, &[0x0F, 0xC7], 5, false),
            "xsaves64" => self.encode_xsave_family(ops, &[0x0F, 0xC7], 5, true),
            "xrstors" => self.encode_xsave_family(ops, &[0x0F, 0xC7], 3, false),
            "xrstors64" => self.encode_xsave_family(ops, &[0x0F, 0xC7], 3, true),
''',
'xsave_dispatch')

# ---------- 12. sse.rs: EVEX vmovdqa64/32 ----------
sub1('src/backend/x86/assembler/encoder/sse.rs',
'''            _ => Err(format!("unsupported {} operands", mnemonic)),
        }
    }

}
''',
'''            _ => Err(format!("unsupported {} operands", mnemonic)),
        }
    }

    // ---- EVEX (AVX-512) minimal support ----
    //
    // Encodings verified byte-for-byte against GNU as 2.44:
    //   vmovdqa64 %zmm0, 64(%rsp)   62 f1 fd 48 7f 44 24 01
    //   vmovdqa64 64(%rsp), %zmm1   62 f1 fd 48 6f 4c 24 01
    //   vmovdqa64 %zmm20, 64(%rsp)  62 e1 fd 48 7f 64 24 01
    //   vmovdqa64 %ymm2, 64(%rsp)   62 f1 fd 28 7f 54 24 02   (disp8 scaled by 32)
    //   vmovdqa64 %xmm4, 64(%rsp)   62 f1 fd 08 7f 64 24 04   (disp8 scaled by 16)
    //   vmovdqa64 %zmm0, (%rdi)     62 f1 fd 48 7f 07
    //
    // EVEX prefix layout (Intel SDM 2.3.10), P1/P2 empirically confirmed:
    //   P0 = 0x62
    //   P1 = bit7 ~reg[3], bit6 ~idx[3], bit5 ~base[3], bit4 ~reg[4], bit0 1
    //   P2 = 0x7D | (W << 7)         (vvvv=1111, pp=01=66)
    //   P3 = z(0) | L'L | b(0) | V'(1) | aaa(000)

    /// 5-bit vector register number for EVEX (xmm/ymm/zmm 0-31) + L'L class.
    fn evex_vec_reg(name: &str) -> Option<(u8, u8)> {
        for (prefix, ll) in [("zmm", 2u8), ("ymm", 1u8), ("xmm", 0u8)] {
            if let Some(num) = name.strip_prefix(prefix) {
                let n: u8 = num.parse().ok()?;
                if n < 32 {
                    return Some((n, ll));
                }
            }
        }
        None
    }

    /// 4-bit GP register number for EVEX addressing (0-15).
    fn evex_gp_num(name: &str) -> Option<u8> {
        let n = match name {
            "al" | "ax" | "eax" | "rax" => 0,
            "cl" | "cx" | "ecx" | "rcx" => 1,
            "dl" | "dx" | "edx" | "rdx" => 2,
            "bl" | "bx" | "ebx" | "rbx" => 3,
            "spl" | "sp" | "esp" | "rsp" => 4,
            "bpl" | "bp" | "ebp" | "rbp" => 5,
            "sil" | "si" | "esi" | "rsi" => 6,
            "dil" | "di" | "edi" | "rdi" => 7,
            "r8b" | "r8w" | "r8d" | "r8" => 8,
            "r9b" | "r9w" | "r9d" | "r9" => 9,
            "r10b" | "r10w" | "r10d" | "r10" => 10,
            "r11b" | "r11w" | "r11d" | "r11" => 11,
            "r12b" | "r12w" | "r12d" | "r12" => 12,
            "r13b" | "r13w" | "r13d" | "r13" => 13,
            "r14b" | "r14w" | "r14d" | "r14" => 14,
            "r15b" | "r15w" | "r15d" | "r15" => 15,
            _ => return None,
        };
        Some(n)
    }

    /// EVEX memory operand: ModRM/SIB/disp with disp8 scaled by `scale_n`
    /// (EVEX disp8 is multiplied by the vector length: 16/32/64).
    fn encode_evex_mem(&mut self, reg_field: u8, mem: &MemoryOperand, scale_n: u32) -> Result<(), String> {
        self.emit_segment_prefix(mem)?;

        // RIP-relative
        if mem.base.as_ref().is_some_and(|b| b.name == "rip") {
            self.bytes.push(self.modrm(0, reg_field, 5));
            match &mem.displacement {
                Displacement::Integer(v) => {
                    self.bytes.extend_from_slice(&(*v as i32).to_le_bytes());
                }
                Displacement::None => self.bytes.extend_from_slice(&[0, 0, 0, 0]),
                _ => return Err("unsupported EVEX RIP-relative displacement".to_string()),
            }
            return Ok(());
        }

        let base_num = match &mem.base {
            Some(b) => Some(Self::evex_gp_num(&b.name)
                .ok_or_else(|| format!("bad EVEX base register: {}", b.name))?),
            None => None,
        };
        let index_num = match &mem.index {
            Some(i) => Some(Self::evex_gp_num(&i.name)
                .ok_or_else(|| format!("bad EVEX index register: {}", i.name))?),
            None => None,
        };
        let disp: i64 = match &mem.displacement {
            Displacement::None => 0,
            Displacement::Integer(v) => *v,
            _ => return Err("unsupported EVEX symbol displacement".to_string()),
        };
        let scale = mem.scale.unwrap_or(1);
        let scale_bits = match scale { 1 => 0u8, 2 => 1, 4 => 2, 8 => 3, _ => 0 };
        let d8_ok = disp % i64::from(scale_n) == 0
            && i8::try_from(disp / i64::from(scale_n)).is_ok();
        let needs_sib = index_num.is_some() || base_num == Some(4) || base_num == Some(12);
        let rbp_like = base_num == Some(5) || base_num == Some(13);

        let mut sib_bytes: Vec<u8> = Vec::new();
        if needs_sib {
            let base7 = base_num.map(|b| b & 7).unwrap_or(5); // SIB base=5 => no base
            let idx7 = index_num.map(|i| i & 7).unwrap_or(4);  // SIB index=4 => no index
            sib_bytes.push(scale_bits << 6 | idx7 << 3 | base7);
        }

        let (mod_, rm, disp_bytes) = match (base_num, index_num) {
            (Some(b), _) => {
                let rm = if needs_sib { 4 } else { b & 7 };
                if disp == 0 && !rbp_like {
                    (0u8, rm, Vec::new())
                } else if d8_ok {
                    (1u8, rm, vec![(disp / i64::from(scale_n)) as u8])
                } else {
                    (2u8, rm, (disp as i32).to_le_bytes().to_vec())
                }
            }
            (None, Some(_)) => {
                // no base: mod=00, rm=100 (SIB, base=5), disp32
                (0u8, 4u8, (disp as i32).to_le_bytes().to_vec())
            }
            (None, None) => {
                // absolute: mod=00, rm=101, disp32
                (0u8, 5u8, (disp as i32).to_le_bytes().to_vec())
            }
        };

        self.bytes.push(self.modrm(mod_, reg_field, rm));
        self.bytes.extend_from_slice(&sib_bytes);
        self.bytes.extend_from_slice(&disp_bytes);
        Ok(())
    }

    /// Encode EVEX vmovdqa64/vmovdqa32 reg<->mem (AVX-512, glibc dl-trampoline).
    pub(crate) fn encode_evex_vmovdqa(&mut self, ops: &[Operand], is_64: bool) -> Result<(), String> {
        if ops.len() != 2 {
            return Err("vmovdqa64/32 requires 2 operands".to_string());
        }
        let w = if is_64 { 1u8 } else { 0u8 };
        match (&ops[0], &ops[1]) {
            (Operand::Register(reg), Operand::Memory(mem)) => {
                let (reg5, ll) = Self::evex_vec_reg(&reg.name)
                    .ok_or_else(|| format!("bad EVEX vector register: {}", reg.name))?;
                let scale_n = [16u32, 32, 64][ll as usize];
                let r3 = (reg5 >> 3) & 1;
                let r4 = (reg5 >> 4) & 1;
                let b3 = mem.base.as_ref()
                    .map(|b| Self::evex_gp_num(&b.name).map(|n| (n >> 3) & 1).unwrap_or(0))
                    .unwrap_or(0);
                let x3 = mem.index.as_ref()
                    .map(|i| Self::evex_gp_num(&i.name).map(|n| (n >> 3) & 1).unwrap_or(0))
                    .unwrap_or(0);
                let p1 = 0x01u8 | ((!r3 & 1) << 7) | ((!x3 & 1) << 6) | ((!b3 & 1) << 5) | ((!r4 & 1) << 4);
                // P2: 0x7D | (W << 7)  (vvvv=1111, pp=01=66; bit7 carries W)
                let p2 = 0x7Du8 | (w << 7);
                let p3 = (ll << 5) | 0b0000_1000; // z=0, L'L=ll, b=0, V'=1, aaa=0
                self.bytes.push(0x62);
                self.bytes.push(p1);
                self.bytes.push(p2);
                self.bytes.push(p3);
                self.bytes.push(0x7F); // store
                self.encode_evex_mem(reg5 & 7, mem, scale_n)
            }
            (Operand::Memory(mem), Operand::Register(reg)) => {
                let (reg5, ll) = Self::evex_vec_reg(&reg.name)
                    .ok_or_else(|| format!("bad EVEX vector register: {}", reg.name))?;
                let scale_n = [16u32, 32, 64][ll as usize];
                let r3 = (reg5 >> 3) & 1;
                let r4 = (reg5 >> 4) & 1;
                let b3 = mem.base.as_ref()
                    .map(|b| Self::evex_gp_num(&b.name).map(|n| (n >> 3) & 1).unwrap_or(0))
                    .unwrap_or(0);
                let x3 = mem.index.as_ref()
                    .map(|i| Self::evex_gp_num(&i.name).map(|n| (n >> 3) & 1).unwrap_or(0))
                    .unwrap_or(0);
                let p1 = 0x01u8 | ((!r3 & 1) << 7) | ((!x3 & 1) << 6) | ((!b3 & 1) << 5) | ((!r4 & 1) << 4);
                let p2 = 0x7Du8 | (w << 7);
                let p3 = (ll << 5) | 0b0000_1000;
                self.bytes.push(0x62);
                self.bytes.push(p1);
                self.bytes.push(p2);
                self.bytes.push(p3);
                self.bytes.push(0x6F); // load
                self.encode_evex_mem(reg5 & 7, mem, scale_n)
            }
            _ => Err("vmovdqa64/32 requires register, memory operands".to_string()),
        }
    }

}
''',
'evex_vmovdqa')

sub1('src/backend/x86/assembler/encoder/mod.rs',
'''            "vmovdqa" => self.encode_avx_mov(ops, 0x6F, 0x7F, true),''',
'''            "vmovdqa" => self.encode_avx_mov(ops, 0x6F, 0x7F, true),
            // EVEX (AVX-512): glibc's dl-trampoline saves zmm regs with these
            "vmovdqa64" => self.encode_evex_vmovdqa(ops, true),
            "vmovdqa32" => self.encode_evex_vmovdqa(ops, false),''',
'evex_dispatch')

# ---------- 13. parser.rs: % reg whitespace ----------
sub1('src/backend/x86/assembler/parser.rs',
'''fn parse_register_operand(s: &str) -> Result<Operand, String> {
    let name = &s[1..]; // strip %''',
'''fn parse_register_operand(s: &str) -> Result<Operand, String> {
    // GNU as tolerates whitespace between '%' and the register name
    // (glibc emits `mov % r13, ...` from `% " R13_LP "` macro splicing).
    let name = s[1..].trim_start(); // strip % and any following spaces''',
'ws_register')

sub1('src/backend/x86/assembler/parser.rs',
'''        if let Some(colon_pos) = s.find(':') {
            let seg = &s[1..colon_pos];
            if seg == "fs" || seg == "gs" {''',
'''        if let Some(colon_pos) = s.find(':') {
            let seg = s[1..colon_pos].trim_start();
            if seg == "fs" || seg == "gs" {''',
'ws_segment')

# ---------- 14. xchg symmetric memory ----------
sub1('src/backend/x86/assembler/encoder/gp_integer.rs',
'''        match (&ops[0], &ops[1]) {
            (Operand::Register(src), Operand::Memory(mem)) => {
                let src_num = reg_num(&src.name).ok_or("bad register")?;
                if size == 2 { self.bytes.push(0x66); }
                self.emit_rex_rm(size, &src.name, mem);
                self.bytes.push(if size == 1 { 0x86 } else { 0x87 });
                self.encode_modrm_mem(src_num, mem)
            }
            (Operand::Register(src), Operand::Register(dst)) => {
                let src_num = reg_num(&src.name).ok_or("bad register")?;
                let dst_num = reg_num(&dst.name).ok_or("bad register")?;
                if size == 2 { self.bytes.push(0x66); }
                self.emit_rex_rr(size, &src.name, &dst.name);
                self.bytes.push(if size == 1 { 0x86 } else { 0x87 });
                self.bytes.push(self.modrm(3, src_num, dst_num));
                Ok(())
            }
            _ => Err("unsupported xchg operands".to_string()),
        }
    }''',
'''        match (&ops[0], &ops[1]) {
            (Operand::Register(src), Operand::Memory(mem))
            | (Operand::Memory(mem), Operand::Register(src)) => {
                // xchg is symmetric: `xchgl (%rdx), %ecx` == `xchgl %ecx, (%rdx)`.
                let src_num = reg_num(&src.name).ok_or("bad register")?;
                if size == 2 { self.bytes.push(0x66); }
                self.emit_rex_rm(size, &src.name, mem);
                self.bytes.push(if size == 1 { 0x86 } else { 0x87 });
                self.encode_modrm_mem(src_num, mem)
            }
            (Operand::Register(src), Operand::Register(dst)) => {
                let src_num = reg_num(&src.name).ok_or("bad register")?;
                let dst_num = reg_num(&dst.name).ok_or("bad register")?;
                if size == 2 { self.bytes.push(0x66); }
                self.emit_rex_rr(size, &src.name, &dst.name);
                self.bytes.push(if size == 1 { 0x86 } else { 0x87 });
                self.bytes.push(self.modrm(3, src_num, dst_num));
                Ok(())
            }
            _ => Err("unsupported xchg operands".to_string()),
        }
    }''',
'xchg_sym')

# ---------- 15. static assertion unsigned div ----------
sub1('src/frontend/parser/declarations.rs',
'''                    BinOp::Div if r != 0 => Some(l.wrapping_div(r)),
                    BinOp::Mod if r != 0 => Some(l.wrapping_rem(r)),''',
'''                    BinOp::Div if r != 0 => {
                        // Unsigned operands must divide as u64: e.g.
                        // 18446744073709551615UL / 2 = 9223372036854775807,
                        // but the i64 view (-1) / 2 would be 0.
                        if Self::is_unsigned_int_expr(lhs) {
                            Some(((l as u64) / (r as u64)) as i64)
                        } else {
                            Some(l.wrapping_div(r))
                        }
                    }
                    BinOp::Mod if r != 0 => {
                        if Self::is_unsigned_int_expr(lhs) {
                            Some(((l as u64) % (r as u64)) as i64)
                        } else {
                            Some(l.wrapping_rem(r))
                        }
                    }''',
'static_assert_udiv')

print("ALL SESSION FIXES RE-APPLIED")
