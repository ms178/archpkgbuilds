#!/usr/bin/env python3
"""glibc-fixes7.py — v6.3 merge layer: ports the glibc-unblocking fixes that
Agent A's v6.2 is missing onto the v6.2 base (audited against tree-A).

Missing in v6.2 (verified by grep/diff against my v6.2 tree):
  1. encoder/core.rs: case-insensitive relocation modifiers (@gottpoff) —
     the glibc TLS blocker. Note GOTTPOFF lowercases to "gottpoff" (two t's);
     a one-t arm never matches and silently falls to R_X86_64_PC32.
  2. elf_writer_common.rs: GNU-as .symver semantics (alias@VER keeps the full
     versioned name; self-alias guard) — v6.2 truncates at '@' producing
     duplicate definitions for compat_symbol(libc, X, X, V).
  3. generation.rs emit_aliases: self-alias skip (ctype-info duplicates).
  4. generation.rs emit_symbol_attrs: asm-label resolution + coverage of
     defined globals (.hidden __GI_x on definitions; nothing on pure refs).
  5. elf/symbol_table.rs: .set alias visibility defaults to STV_DEFAULT
     (copying the target's visibility hid __pointer_chk_guard and broke the
     GLIBC_PRIVATE export).
  6. ir/lowering/structs.rs: get_struct_base_addr asm-label redirect
     (_null_auth.oa_flavor -> __GI__null_auth).
  7. ir/lowering/lvalue.rs: GlobalAddr asm-label redirect (&_null_auth).
  8. passes/mod.rs: gnu_inline -> declaration ONLY when no calls remain
     (still_called) — rtld free/__bsearch.
  9. ir/lowering/ref_collection.rs: __attribute__((used)) functions are roots
     (rtld _dl_start -> rtld_timer_start).
 10. __builtin_ia32_rdtsc / rdtscp intrinsics (rtld_timer.c).
 11. driver/cli.rs: linker entry point -e SYMBOL -> -Wl,-e,SYMBOL
     (glibc libc.so links with -e __libc_main).
 12. elf/symbol_table.rs is_tls_reloc: deduplicated match ranges (kills the
     rustc "unreachable pattern" warning at symbol_table.rs:205-206).
"""
import sys

SRC = '/home/user/ccc-work/sources/ccc-src/'

def sub1(path, old, new, tag=''):
    p = SRC + path
    s = open(p).read()
    if new in s:
        print(f"skip (already applied): {tag}: {path}")
        return
    n = s.count(old)
    if n != 1:
        print(f"FAIL {tag}: {path}: found {n} of {old[:70]!r}")
        sys.exit(1)
    open(p, 'w').write(s.replace(old, new))
    print(f"ok {tag}: {path}")

# ============ 1. encoder/core.rs: case-insensitive modifiers ============
sub1('src/backend/x86/assembler/encoder/core.rs',
'''                    Displacement::SymbolMod(sym, modifier) => {
                        let reloc_type = match modifier.as_str() {
                            "GOTPCREL" => R_X86_64_GOTPCREL,
                            "GOTTPOFF" => R_X86_64_GOTTPOFF,
                            "PLT" => R_X86_64_PLT32,
                            _ => R_X86_64_PC32,
                        };
                        self.add_relocation(sym, reloc_type, -4);''',
'''                    Displacement::SymbolMod(sym, modifier) => {
                        // Modifiers are case-insensitive in GNU as: glibc's
                        // multiarch sources emit lowercase `sym@gottpoff(%rip)`.
                        let reloc_type = match modifier.to_ascii_lowercase().as_str() {
                            "gotpcrel" => R_X86_64_GOTPCREL,
                            "gottpoff" => R_X86_64_GOTTPOFF, // ZZ_MARKER_GOTTPOFF
                            "tpoff" => R_X86_64_TPOFF32,
                            "plt" => R_X86_64_PLT32,
                            _ => R_X86_64_PC32,
                        };
                        self.add_relocation(sym, reloc_type, -4);''',
'gottpoff_site1')

sub1('src/backend/x86/assembler/encoder/core.rs',
'''            Displacement::SymbolMod(sym, modifier) => {
                let reloc_type = match modifier.as_str() {
                    "TPOFF" => R_X86_64_TPOFF32,
                    "GOTPCREL" => R_X86_64_GOTPCREL,
                    _ => R_X86_64_32S,
                };
                (0i64, true, Some((sym.clone(), reloc_type, 0i64)))
            }''',
'''            Displacement::SymbolMod(sym, modifier) => {
                let reloc_type = match modifier.to_ascii_lowercase().as_str() {
                    "tpoff" => R_X86_64_TPOFF32,
                    "gotpcrel" => R_X86_64_GOTPCREL,
                    "gottpoff" => R_X86_64_GOTTPOFF,
                    _ => R_X86_64_32S,
                };
                (0i64, true, Some((sym.clone(), reloc_type, 0i64)))
            }''',
'gottpoff_site2')

# ============ 2. elf_writer_common.rs: GNU-as .symver semantics ============
sub1('src/backend/elf_writer_common.rs',
'''            AsmItem::Symver(name, ver_string) => {
                // .symver name, alias@@VERSION  -> default version: create alias from "alias" to "name"
                // .symver name, alias@VERSION   -> compat version: create alias from "alias" to "name"
                // Extract the unversioned alias name from the version string
                if let Some(at_pos) = ver_string.find('@') {
                    let alias = &ver_string[..at_pos];
                    if !alias.is_empty() {
                        self.aliases.insert(alias.to_string(), name.clone());
                    }
                }
            }''',
'''            AsmItem::Symver(name, ver_string) => {
                // .symver name, alias@@VERSION  -> default version: the symbol is
                //   renamed to `alias` (symbol table entry `alias`).
                // .symver name, alias@VERSION   -> compat version: the symbol keeps
                //   `name` AND a versioned alias `alias@VERSION` is added, exactly
                //   like GNU as (e.g. glibc's `compat_symbol (libc, _res, _res,
                //   GLIBC_2_0)` -> `.symver _res, _res@GLIBC_2_0`).
                // Truncating at '@' produced a self-alias for `local == symbol`
                // cases and hence duplicate definitions in one object.
                if let Some(at_pos) = ver_string.find('@') {
                    let base = &ver_string[..at_pos];
                    let is_default = ver_string[at_pos..].starts_with("@@");
                    if !base.is_empty() {
                        let alias_name = if is_default {
                            base.to_string()
                        } else {
                            ver_string.clone()
                        };
                        if alias_name.as_str() != name.as_str() {
                            self.aliases.insert(alias_name, name.clone());
                        }
                    }
                }
            }''',
'symver_gnuas')

# ============ 3. generation.rs emit_aliases: self-alias skip ============
sub1('src/backend/generation.rs',
'''        let alias_resolved = module.asm_labels.get(alias_name).unwrap_or(alias_name);
        let target_resolved = module.asm_labels.get(target_name).unwrap_or(target_name);
        cg.state().emit("");''',
'''        let alias_resolved = module.asm_labels.get(alias_name).unwrap_or(alias_name);
        let target_resolved = module.asm_labels.get(target_name).unwrap_or(target_name);
        // Self-alias (glibc hidden_data_def: the C definition was renamed by an
        // earlier `__asm__("__GI_x")` declaration, so `__GI_x alias("x")`
        // resolves to the SAME symbol). Emitting `.set x, x` would create a
        // duplicate definition and break the libc_pic.os partial link with
        // "multiple definition" errors. GCC folds this case silently.
        if alias_resolved == target_resolved {
            continue;
        }
        cg.state().emit("");''',
'selfalias_skip')

# ============ 4. generation.rs emit_symbol_attrs ============
sub1('src/backend/generation.rs',
'''    for (name, is_weak, visibility) in &module.symbol_attrs {
        if !referenced_symbols.contains(name) {
            continue;
        }
        if *is_weak {
            cg.state().emit_fmt(format_args!(".weak {}", name));
        }
        cg.state().emit_visibility(name, visibility);
    }
}''',
'''    // Globals are emitted under their asm label (if any); the attribute on the
    // C name applies to that label.
    let defined_labels: FxHashSet<&str> =
        module.globals.iter().map(|g| g.name.as_str()).collect();
    for (name, is_weak, visibility) in &module.symbol_attrs {
        let resolved = module
            .asm_labels
            .get(name)
            .map(|s| s.as_str())
            .unwrap_or(name.as_str());
        if !referenced_symbols.contains(name) && !defined_labels.contains(resolved) {
            continue;
        }
        if *is_weak {
            cg.state().emit_fmt(format_args!(".weak {}", resolved));
        }
        cg.state().emit_visibility(resolved, visibility);
    }
}''',
'emit_symbol_attrs')

# ============ 5. symbol_table.rs: alias visibility = STV_DEFAULT ============
sub1('src/backend/elf/symbol_table.rs',
'''                binding: alias_binding.unwrap_or(target_sym.binding),
                sym_type: alias_type.unwrap_or(target_sym.sym_type),
                visibility: alias_vis.unwrap_or(target_sym.visibility),
                section_name: target_sym.section_name.clone(),
            });''',
'''                binding: alias_binding.unwrap_or(target_sym.binding),
                sym_type: alias_type.unwrap_or(target_sym.sym_type),
                // Visibility comes only from an explicit .hidden/.protected
                // directive on the alias itself (GNU as semantics). Copying the
                // target's visibility would make strong_aliases of hidden
                // objects hidden too — e.g. glibc rtld.c's
                // `strong_alias (__pointer_chk_guard_local, __pointer_chk_guard)`
                // would produce a hidden __pointer_chk_guard that the ld.map
                // version script cannot export (GLIBC_PRIVATE), leaving
                // libc.so with an undefined __pointer_chk_guard.
                visibility: alias_vis.unwrap_or(STV_DEFAULT),
                section_name: target_sym.section_name.clone(),
            });''',
'alias_visibility')

# ============ 6. structs.rs: get_struct_base_addr redirect ============
sub1('src/ir/lowering/structs.rs',
'''                if self.globals.contains_key(name) {
                    let addr = self.fresh_value();
                    self.emit(Instruction::GlobalAddr { dest: addr, name: name.clone() });
                    return addr;
                }''',
'''                if self.globals.contains_key(name) {
                    // Apply __asm__("label") redirect (glibc hidden_proto data:
                    // `extern struct opaque_auth _null_auth __asm__("__GI__null_auth")
                    // __attribute__((visibility("hidden")))` — member accesses
                    // like `_null_auth.oa_flavor` must reference __GI__null_auth,
                    // otherwise the object has an unversioned plain reference
                    // that no member defines).
                    let resolved_name = self.asm_label_map.get(name)
                        .cloned()
                        .unwrap_or_else(|| name.clone());
                    let addr = self.fresh_value();
                    self.emit(Instruction::GlobalAddr { dest: addr, name: resolved_name });
                    return addr;
                }''',
'structs_redirect')

# ============ 7. lvalue.rs: GlobalAddr redirect ============
sub1('src/ir/lowering/lvalue.rs',
'''                    // Global variable: emit GlobalAddr to get its address
                    let addr = self.fresh_value();
                    self.emit(Instruction::GlobalAddr { dest: addr, name: name.clone() });
                    Some(LValue::Address(addr, addr_space))''',
'''                    // Global variable: emit GlobalAddr to get its address.
                    // Apply __asm__("label") redirect (glibc hidden_proto data:
                    // `extern const char x[] __asm__("__GI_x")` — &x must be
                    // the address of __GI_x).
                    let resolved_name = self.asm_label_map.get(name)
                        .cloned()
                        .unwrap_or_else(|| name.clone());
                    let addr = self.fresh_value();
                    self.emit(Instruction::GlobalAddr { dest: addr, name: resolved_name });
                    Some(LValue::Address(addr, addr_space))''',
'lvalue_redirect')

# ============ 8. passes/mod.rs: still_called gating ============
sub1('src/passes/mod.rs',
'''use crate::ir::reexports::{IrFunction, IrModule};''',
'''use crate::common::fx_hash::FxHashSet;
use crate::ir::reexports::{Instruction, IrFunction, IrModule};''',
'imports')

sub1('src/passes/mod.rs',
'''    // After inlining, convert extern inline gnu_inline functions to declarations.
    // These function bodies were only needed for inlining; they must not be emitted
    // as standalone definitions because their internal calls (e.g., `call btowc`)
    // would resolve to the local definition instead of the external library symbol,
    // causing infinite recursion. Converting to declarations ensures any remaining
    // (non-inlined) calls resolve to the external symbol at link time.
    for func in &mut module.functions {
        if func.is_gnu_inline_def && !func.is_declaration {
            func.is_declaration = true;
            func.blocks.clear();
        }
    }''',
'''    // After inlining, convert extern inline gnu_inline functions to declarations —
    // but ONLY when no calls remain. The bodies were only needed for inlining;
    // they must not be emitted as standalone definitions when fully inlined away,
    // because their internal calls (e.g., `call btowc`) would resolve to the local
    // definition instead of the external library symbol, causing infinite recursion.
    // However, if any call site was NOT inlined (e.g. the caller was skipped by the
    // inliner), the function MUST still be emitted as a local (static) definition —
    // GNU89 `extern inline` semantics provide an inline definition usable locally.
    // Dropping it here made glibc's rtld link fail with undefined references to
    // `free`, `__bsearch` etc.
    let mut still_called: FxHashSet<String> = FxHashSet::default();
    for func in &module.functions {
        for block in &func.blocks {
            for inst in &block.instructions {
                if let Instruction::Call { func: callee, .. } = inst {
                    still_called.insert(callee.clone());
                }
            }
        }
    }
    for func in &mut module.functions {
        if func.is_gnu_inline_def && !func.is_declaration && !still_called.contains(&func.name) {
            func.is_declaration = true;
            func.blocks.clear();
        }
    }''',
'still_called')

# ============ 9. ref_collection.rs: used roots ============
sub1('src/ir/lowering/ref_collection.rs',
'''                ExternalDecl::FunctionDef(func) => {
                    if self.is_skippable_function(func) {
                        // For skippable functions, collect their refs into a separate map
                        // so we can do transitive closure later
                        let mut func_refs = FxHashSet::default();
                        self.collect_refs_from_compound(&func.body, &mut func_refs);
                        skippable_refs.insert(func.name.clone(), func_refs);
                    } else {
                        // Root function: collect refs directly into the referenced set
                        self.collect_refs_from_compound(&func.body, &mut referenced);
                    }
                }''',
'''                ExternalDecl::FunctionDef(func) => {
                    if self.is_skippable_function(func) && !func.attrs.is_used() {
                        // For skippable functions, collect their refs into a separate map
                        // so we can do transitive closure later
                        let mut func_refs = FxHashSet::default();
                        self.collect_refs_from_compound(&func.body, &mut func_refs);
                        skippable_refs.insert(func.name.clone(), func_refs);
                    } else {
                        // Root function: collect refs directly into the referenced set.
                        // __attribute__((used)) functions (e.g. glibc's `static
                        // __attribute__((__used__)) _dl_start`, called from asm)
                        // are roots even though they are static — otherwise their
                        // callees (rtld_timer_start etc.) get skipped and the
                        // link fails with undefined references.
                        if func.attrs.is_used() {
                            referenced.insert(func.name.clone());
                        }
                        self.collect_refs_from_compound(&func.body, &mut referenced);
                    }
                }''',
'used_roots')

# ============ 10. RDTSC / RDTSCP intrinsics ============
sub1('src/ir/intrinsics.rs',
'''    /// __builtin_frame_address(0) - returns current frame pointer
    FrameAddress,''',
'''    /// __builtin_ia32_rdtsc() - 64-bit timestamp counter (EDX:EAX)
    Rdtsc,
    /// __builtin_ia32_rdtscp(&aux) - rdtscp, stores IA32_TSC_AUX (ecx) to aux
    Rdtscp,
    /// __builtin_frame_address(0) - returns current frame pointer
    FrameAddress,''',
'rdtsc_ops')

sub1('src/frontend/sema/builtins.rs',
'''    // X86 SSE intrinsics
    X86Lfence,''',
'''    /// __builtin_ia32_rdtsc() - 64-bit timestamp counter
    X86Rdtsc,
    /// __builtin_ia32_rdtscp(&aux) - rdtscp with aux store
    X86Rdtscp,
    // X86 SSE intrinsics
    X86Lfence,''',
'rdtsc_enum')

sub1('src/frontend/sema/builtins.rs',
'''    m.insert("__builtin_thread_pointer", BuiltinInfo::intrinsic(BuiltinIntrinsic::ThreadPointer));''',
'''    m.insert("__builtin_thread_pointer", BuiltinInfo::intrinsic(BuiltinIntrinsic::ThreadPointer));
    m.insert("__builtin_ia32_rdtsc", BuiltinInfo::intrinsic(BuiltinIntrinsic::X86Rdtsc));
    m.insert("__builtin_ia32_rdtscp", BuiltinInfo::intrinsic(BuiltinIntrinsic::X86Rdtscp));''',
'rdtsc_map')

sub1('src/ir/lowering/expr_builtins.rs',
'''            BuiltinIntrinsic::X86Lfence | BuiltinIntrinsic::X86Mfence
            | BuiltinIntrinsic::X86Sfence | BuiltinIntrinsic::X86Pause
            | BuiltinIntrinsic::X86Clflush''',
'''            BuiltinIntrinsic::X86Lfence | BuiltinIntrinsic::X86Mfence
            | BuiltinIntrinsic::X86Sfence | BuiltinIntrinsic::X86Pause
            | BuiltinIntrinsic::X86Rdtsc | BuiltinIntrinsic::X86Rdtscp
            | BuiltinIntrinsic::X86Clflush''',
'rdtsc_dispatch')

sub1('src/ir/lowering/expr_builtins.rs',
'''        | BuiltinIntrinsic::X86Pextrq128 | BuiltinIntrinsic::X86Pmovmskb256 => X86IntrinsicKind::Scalar,''',
'''        | BuiltinIntrinsic::X86Pextrq128 | BuiltinIntrinsic::X86Pmovmskb256
        | BuiltinIntrinsic::X86Rdtsc | BuiltinIntrinsic::X86Rdtscp => X86IntrinsicKind::Scalar,''',
'rdtsc_kind')

sub1('src/ir/lowering/expr_builtins.rs',
'''        BuiltinIntrinsic::X86Lfence => IntrinsicOp::Lfence,''',
'''        BuiltinIntrinsic::X86Rdtsc => IntrinsicOp::Rdtsc,
        BuiltinIntrinsic::X86Rdtscp => IntrinsicOp::Rdtscp,
        BuiltinIntrinsic::X86Lfence => IntrinsicOp::Lfence,''',
'rdtsc_opmap')

sub1('src/backend/x86/codegen/intrinsics.rs',
'''            IntrinsicOp::Pause => { self.state.emit("    pause"); }''',
'''            IntrinsicOp::Pause => { self.state.emit("    pause"); }
            IntrinsicOp::Rdtsc => {
                // rdtsc: EDX:EAX -> RAX (matches GCC __builtin_ia32_rdtsc)
                self.state.emit("    rdtsc");
                self.state.emit("    shlq $32, %rdx");
                self.state.emit("    orq %rdx, %rax");
                if let Some(d) = dest {
                    self.store_rax_to(d);
                }
            }
            IntrinsicOp::Rdtscp => {
                // rdtscp: EDX:EAX -> RAX, IA32_TSC_AUX (ecx) -> *args[0]
                self.state.emit("    rdtscp");
                self.operand_to_reg(&args[0], "rdi");
                self.state.emit("    movl %ecx, (%rdi)");
                self.state.emit("    shlq $32, %rdx");
                self.state.emit("    orq %rdx, %rax");
                if let Some(d) = dest {
                    self.store_rax_to(d);
                }
            }''',
'rdtsc_emit')

# ============ 11. cli.rs: -e linker entry point ============
sub1('src/driver/cli.rs',
'''                "-Xlinker" => {
                    i += 1;
                    if i < args.len() {
                        self.linker_ordered_items.push(format!("-Wl,{}", args[i]));
                    }
                }''',
'''                "-Xlinker" => {
                    i += 1;
                    if i < args.len() {
                        self.linker_ordered_items.push(format!("-Wl,{}", args[i]));
                    }
                }

                // Linker entry point: -e SYMBOL / -eSYMBOL (glibc links libc.so
                // with `-e __libc_main`). Without this the symbol is treated as
                // an input file and the link fails.
                "-e" => {
                    i += 1;
                    if i < args.len() {
                        self.linker_ordered_items.push(format!("-Wl,-e,{}", args[i]));
                    }
                }
                arg if arg.len() > 2 && arg.starts_with("-e") && !arg.starts_with("-E") => {
                    self.linker_ordered_items.push(format!("-Wl,-e,{}", &arg[2..]));
                }''',
'driver_e')

# ============ 12. symbol_table.rs: is_tls_reloc dedup (warning fix) ============
sub1('src/backend/elf/symbol_table.rs',
'''    matches!(rtype,
        16 | 17 | 18 | 21 | 22 | 23 | 36 | 42
        | 14 | 15 | 16 | 17 | 18 | 19
        | 24 | 25 | 26 | 27 | 28 | 29 | 30 | 31 | 32 | 33 | 34 | 35)''',
'''    // Deduplicated union of the two arch sets: the 16/17/18 overlap between
    // x86-64 and i386 made the original arms unreachable (rustc warning).
    // x86-64 {16,17,18,21,22,23,36,42} ∪ i386 {14..19, 24..35} = {14..19, 21..23, 24..35, 36, 42}
    matches!(rtype, 14..=19 | 21..=23 | 24..=35 | 36 | 42)''',
'tls_reloc_dedup')

print("ROUND-7 MERGE LAYER APPLIED (12 fixes)")
