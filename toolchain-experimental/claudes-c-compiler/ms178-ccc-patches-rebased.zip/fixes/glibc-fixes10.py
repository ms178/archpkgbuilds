#!/usr/bin/env python3
"""glibc-fixes10.py — v6.3 fix #15: emit_aliases must NOT re-resolve the alias
name through asm_labels (generation.rs).

The lowerer already emits alias entries with the asm label applied
(`extern T __EI_x __asm__("__strdup") __attribute__((alias("__GI___strdup")))`
arrives as ("__strdup","__GI___strdup")). Re-resolving the alias name here
turned `__strdup` (which also carries the hidden_proto asm label
`__GI___strdup`) into a self-alias and the `.set __strdup,__GI___strdup`
vanished -> "undefined reference to `__strdup'" at the ld.so link.

Only the TARGET may need asm resolution (configure alias test:
alias("foo") where foo itself is `__asm("xyzfoo")` -> `.set xyzbar, xyzfoo`).
The self-alias guard stays (`.set x, x` after resolution = duplicate symbol
entry; GCC folds silently).

Verified: repro emits `.set __strdup,__GI___strdup`, identical to GCC 14/16;
57/57 regression green.
"""
import sys

SRC = '/home/user/ccc-work/sources/ccc-src/'

def sub1(path, old, new, tag=''):
    p = SRC + path
    s = open(p).read()
    if new in s:
        print(f"skip (already applied): {tag}: {path}")
        return
    n = s.count(old)
    if n != 1:
        print(f"FAIL {tag}: {path}: found {n} of {old[:70]!r}")
        sys.exit(1)
    open(p, 'w').write(s.replace(old, new))
    print(f"ok {tag}: {path}")

sub1('src/backend/generation.rs',
'''fn emit_aliases(cg: &mut dyn ArchCodegen, module: &IrModule) {
    for (alias_name, target_name, is_weak) in &module.aliases {
        // Resolve __asm__("label") redirects on both the alias and its target
        // (glibc's configure alias test: `extern int bar(int) __asm("xyzbar")
        // __attribute__((alias("foo")))` must emit `.set xyzbar, xyzfoo`).
        let alias_resolved = module.asm_labels.get(alias_name).unwrap_or(alias_name);
        let target_resolved = module.asm_labels.get(target_name).unwrap_or(target_name);
        // Self-alias (glibc hidden_data_def: the C definition was renamed by an
        // earlier `__asm__("__GI_x")` declaration, so `__GI_x alias("x")`
        // resolves to the SAME symbol). Emitting `.set x, x` would create a
        // duplicate definition and break the libc_pic.os partial link with
        // "multiple definition" errors. GCC folds this case silently.
        if alias_resolved == target_resolved {
            continue;
        }
        cg.state().emit("");
        if *is_weak {
            cg.state().emit_fmt(format_args!(".weak {}", alias_resolved));
        } else {
            cg.state().emit_fmt(format_args!(".globl {}", alias_resolved));
        }
        cg.state()
            .emit_fmt(format_args!(".set {},{}\", alias_resolved, target_resolved));
    }
}''',
'''fn emit_aliases(cg: &mut dyn ArchCodegen, module: &IrModule) {
    for (alias_name, target_name, is_weak) in &module.aliases {
        // The alias name is already asm-resolved by the lowerer (e.g.
        // `extern int bar __asm("xyzbar") __attribute__((alias("foo")))`
        // arrives as ("xyzbar","foo")). Resolving it AGAIN here would corrupt
        // glibc hidden_ver aliases: `__strdup -> __GI___strdup` must stay
        // `.set __strdup,__GI___strdup`, but `__strdup` also carries the
        // hidden_proto asm label `__GI___strdup`, so a second resolution
        // turns it into a self-alias and the alias silently vanishes
        // (undefined `__strdup` at the ld.so link).
        // The TARGET may still need asm resolution (configure alias test:
        // alias("foo") where foo itself is `__asm("xyzfoo")` -> `.set xyzbar, xyzfoo`).
        let target_resolved = module.asm_labels.get(target_name).unwrap_or(target_name);
        // Self-alias guard: `.set x, x` after resolution (e.g. a renamed
        // definition whose __EI__ alias re-points at itself) would create a
        // duplicate symbol entry; GCC folds it silently.
        if alias_name.as_str() == target_resolved.as_str() {
            continue;
        }
        cg.state().emit("");
        if *is_weak {
            cg.state().emit_fmt(format_args!(".weak {}", alias_name));
        } else {
            cg.state().emit_fmt(format_args!(".globl {}", alias_name));
        }
        cg.state()
            .emit_fmt(format_args!(".set {},{}\", alias_name, target_resolved));
    }
}''',
'emit_aliases_no_double_resolve')

print("ROUND-10 EMIT_ALIASES FIX APPLIED")
