#!/usr/bin/env python3
"""glibc-fixes2.py — round-2 glibc-unblocking fixes reconstructed from the
session audit (all verified during the glibc 2.44 build attempts):

  A. TLS symbol type for undefined symbols (elf/symbol_table.rs)
  B. .uleb128/.sleb128 support (parser.rs + elf_writer_common.rs)
  C. GNU-as symbol-difference expressions without spaces/parens (parser.rs)
  D. numeric-label rewriting for Uleb128/Sleb128 (elf/numeric_labels.rs)
  E. addend honored in diff relocation resolution
  F. shift_section_offsets also shifts align markers + deferred skips
  G. fixup_alignment_markers runs for EVERY section (not only jump sections)
  H. `defined X` operands protected from macro expansion (macro_defs.rs)
  I. __builtin_mempcpy / __builtin_stpcpy builtins (sema/builtins.rs)

Each step asserted; run against a freshly reconstructed tree only.
"""
import sys

SRC = '/home/user/ccc-work/sources/ccc-src/'

def sub1(path, old, new, tag=''):
    p = SRC + path
    s = open(p).read()
    n = s.count(old)
    if n != 1:
        print(f"FAIL {tag}: {path}: found {n} of {old[:70]!r}")
        sys.exit(1)
    open(p, 'w').write(s.replace(old, new))
    print(f"ok {tag}: {path}")

# ============ A. TLS symbol type for undefined symbols ============
sub1('src/backend/elf/symbol_table.rs',
'''    // Add undefined symbols (referenced in relocations but not defined)
    let mut referenced: HashSet<String> = HashSet::new();
    for sec in input.sections.values() {
        for reloc in &sec.relocs {
            if reloc.symbol_name.is_empty() {
                continue;
            }
            if !reloc.symbol_name.starts_with(".L") && !reloc.symbol_name.starts_with(".l") {
                referenced.insert(reloc.symbol_name.clone());
            }
        }
    }
''',
'''    // Add undefined symbols (referenced in relocations but not defined)
    let mut referenced: HashSet<String> = HashSet::new();
    // Symbols referenced by TLS relocations must be STT_TLS in the symbol
    // table; otherwise the linker rejects the object with
    // "TLS definition ... mismatches non-TLS reference" (glibc's errno.os /
    // __libc_errno via @GOTTPOFF hits this).
    let mut tls_referenced: HashSet<String> = HashSet::new();
    for sec in input.sections.values() {
        for reloc in &sec.relocs {
            if reloc.symbol_name.is_empty() {
                continue;
            }
            if reloc.symbol_name.starts_with(".L") || reloc.symbol_name.starts_with(".l") {
                continue;
            }
            referenced.insert(reloc.symbol_name.clone());
            if is_tls_reloc(reloc.reloc_type) {
                tls_referenced.insert(reloc.symbol_name.clone());
            }
        }
    }
''',
'A_tls_refs')

sub1('src/backend/elf/symbol_table.rs',
'''            symbols.push(ObjSymbol {
                name: name.clone(),
                value: 0,
                size: 0,
                binding,
                sym_type: input.symbol_types.get(name).copied().unwrap_or(STT_NOTYPE),
                visibility: input.symbol_visibility.get(name).copied().unwrap_or(STV_DEFAULT),
                section_name: "*UND*".to_string(),
            });''',
'''            symbols.push(ObjSymbol {
                name: name.clone(),
                value: 0,
                size: 0,
                binding,
                sym_type: input.symbol_types.get(name).copied().unwrap_or_else(|| {
                    if tls_referenced.contains(name) { STT_TLS } else { STT_NOTYPE }
                }),
                visibility: input.symbol_visibility.get(name).copied().unwrap_or(STV_DEFAULT),
                section_name: "*UND*".to_string(),
            });''',
'A_tls_type')

s = open(SRC + 'src/backend/elf/symbol_table.rs').read()
if 'fn is_tls_reloc' not in s:
    s += '''
/// True if the relocation type is a TLS relocation (x86-64 and i386).
/// Undefined symbols referenced by these must be emitted as STT_TLS so the
/// static linker can match them against TLS definitions.
fn is_tls_reloc(rtype: u32) -> bool {
    // x86-64: R_X86_64_DTPMOD64=16, DTPOFF64=17, TPOFF64=18, TPOFF32=23,
    //          DTPOFF32=21, GOTTPOFF=22, TLSDESC=36, TLSDESC_CALL=42
    // i386:    R_386_TLS_TPOFF=14, TLS_IE=15, TLS_GOTIE=16, TLS_LE=17,
    //          TLS_GD=18, TLS_LDM=19, TLS_GD_32=24..TLS_TPOFF32=35
    matches!(rtype,
        16 | 17 | 18 | 21 | 22 | 23 | 36 | 42
        | 14 | 15 | 16 | 17 | 18 | 19
        | 24 | 25 | 26 | 27 | 28 | 29 | 30 | 31 | 32 | 33 | 34 | 35)
}
'''
    open(SRC + 'src/backend/elf/symbol_table.rs', 'w').write(s)
print("ok A_tls_helper")

# ============ B1. parser.rs: AsmItem variants + directive parsing ============
sub1('src/backend/x86/assembler/parser.rs',
'''    /// Emit 64-bit values: `.quad val, ...` (can be symbol references)
    Quad(Vec<DataValue>),''',
'''    /// Emit 64-bit values: `.quad val, ...` (can be symbol references)
    Quad(Vec<DataValue>),
    /// Emit ULEB128-encoded values: `.uleb128 val, ...` (DWARF/.eh_frame)
    Uleb128(Vec<DataValue>),
    /// Emit SLEB128-encoded values: `.sleb128 val, ...` (DWARF/.eh_frame)
    Sleb128(Vec<DataValue>),''',
'B_uleb_variants')

sub1('src/backend/x86/assembler/parser.rs',
'''        ".long" | ".4byte" | ".int" => {
            let vals = parse_data_values(args)?;
            Ok(AsmItem::Long(vals))
        }''',
'''        ".long" | ".4byte" | ".int" => {
            let vals = parse_data_values(args)?;
            Ok(AsmItem::Long(vals))
        }
        ".uleb128" => {
            let vals = parse_data_values(args)?;
            Ok(AsmItem::Uleb128(vals))
        }
        ".sleb128" => {
            let vals = parse_data_values(args)?;
            Ok(AsmItem::Sleb128(vals))
        }''',
'B_uleb_parse')

# ============ C. GNU-as symbol-diff expressions ============
sub1('src/backend/x86/assembler/parser.rs',
'''        // Symbol reference
        vals.push(DataValue::Symbol(trimmed.to_string()));
    }
    Ok(vals)
}''',
'''        // GNU as symbol-difference forms without spaces or with parentheses
        // (glibc .eh_frame emits `(.LSTART_restore_rt-1)-.`,
        //  `.LEND_restore_rt-(.LSTART_restore_rt-1)`, `.LENDCIE_-.LSTARTCIE_`).
        if let Some(val) = try_parse_sym_diff(trimmed) {
            vals.push(val);
            continue;
        }

        // Symbol reference
        vals.push(DataValue::Symbol(trimmed.to_string()));
    }
    Ok(vals)
}

/// Split `sym`, `sym+N`, `sym-N`, `(sym±N)` into (symbol, addend) where the
/// value equals `symbol + addend`. Returns None for non-label strings.
fn parse_sym_addend(s: &str) -> Option<(String, i64)> {
    let t = s.trim();
    let t = t.strip_prefix('(').and_then(|x| x.strip_suffix(')')).unwrap_or(t);
    let t = t.trim();
    if t.is_empty() {
        return None;
    }
    for (i, c) in t.char_indices().skip(1) {
        if c == '+' || c == '-' {
            let sym = t[..i].trim();
            if !is_label_like(sym) {
                continue;
            }
            let num_raw: String = t[i..].chars().filter(|c| !c.is_whitespace()).collect();
            let v: i64 = if let Some(r) = num_raw.strip_prefix('+') {
                r.parse().ok()?
            } else if let Some(r) = num_raw.strip_prefix('-') {
                -r.parse::<i64>().ok()?
            } else {
                continue;
            };
            return Some((sym.to_string(), v));
        }
    }
    if is_label_like(t) {
        Some((t.to_string(), 0))
    } else {
        None
    }
}

/// Parse GNU-as symbol-difference expressions that lack spaces around the
/// operator or use parentheses: `(a-1)-.`, `a-(b-1)`, `(a+2)-b`, `a-b`.
/// Returns DataValue::SymbolDiffAddend(a, b, add) meaning `a - b + add`.
fn try_parse_sym_diff(s: &str) -> Option<DataValue> {
    let s = s.trim();
    if s.is_empty() {
        return None;
    }
    let bytes = s.as_bytes();
    let mut depth = 0i32;
    for i in 0..bytes.len() {
        let c = bytes[i] as char;
        if c == '(' {
            depth += 1;
        } else if c == ')' {
            depth -= 1;
        } else if c == '-' && depth == 0 && i > 0 {
            let lhs = &s[..i];
            let rhs = &s[i + 1..];
            let (a, add_a) = parse_sym_addend(lhs)?;
            if rhs.trim() == "." {
                // (a ± N) - .  ==  a - . ± N   (PC-relative, GNU as encodes as
                // a PC32 reloc with the addend folded in)
                return Some(DataValue::SymbolDiffAddend(a, ".".to_string(), add_a));
            }
            if let Some((b, add_b)) = parse_sym_addend(rhs) {
                // a + add_a - (b + add_b) = a - b + (add_a - add_b)
                return Some(DataValue::SymbolDiffAddend(a, b, add_a - add_b));
            }
            return None;
        }
    }
    None
}''',
'C_symdiff_parse')

# ============ D. numeric labels for Uleb128/Sleb128 ============
sub1('src/backend/elf/numeric_labels.rs',
'''            AsmItem::Byte(vals) => {
                result.push(AsmItem::Byte(resolve_numeric_data_values(vals, i, &defs)));
            }''',
'''            AsmItem::Byte(vals) => {
                result.push(AsmItem::Byte(resolve_numeric_data_values(vals, i, &defs)));
            }
            AsmItem::Uleb128(vals) => {
                result.push(AsmItem::Uleb128(resolve_numeric_data_values(vals, i, &defs)));
            }
            AsmItem::Sleb128(vals) => {
                result.push(AsmItem::Sleb128(resolve_numeric_data_values(vals, i, &defs)));
            }''',
'D_uleb_numlabel')

# ============ B2. elf_writer_common.rs: LEB infrastructure ============
sub1('src/backend/elf_writer_common.rs',
'''    /// Deferred byte-sized symbol diffs: (section_index, offset, sym_a, sym_b, size, addend).
    deferred_byte_diffs: Vec<(usize, usize, String, String, usize, i64)>,''',
'''    /// Deferred byte-sized symbol diffs: (section_index, offset, sym_a, sym_b, size, addend).
    deferred_byte_diffs: Vec<(usize, usize, String, String, usize, i64)>,
    /// Deferred ULEB/SLEB128 symbol diffs: (section, offset, sym_a, sym_b, addend, signed).
    /// GNU as folds same-section local-label differences to constants at
    /// assembly time; we defer until label positions are known (glibc .eh_frame).
    deferred_leb_diffs: Vec<(usize, usize, String, String, i64, bool)>,''',
'B_leb_field')

sub1('src/backend/elf_writer_common.rs',
'''            deferred_byte_diffs: Vec::new(),
            code_mode: A::default_code_mode(),''',
'''            deferred_byte_diffs: Vec::new(),
            deferred_leb_diffs: Vec::new(),
            code_mode: A::default_code_mode(),''',
'B_leb_init')

sub1('src/backend/elf_writer_common.rs',
'''            AsmItem::Quad(vals) => {
                self.emit_data_values(vals, 8)?;
            }''',
'''            AsmItem::Quad(vals) => {
                self.emit_data_values(vals, 8)?;
            }
            AsmItem::Uleb128(vals) => {
                self.emit_leb_values(vals, false)?;
            }
            AsmItem::Sleb128(vals) => {
                self.emit_leb_values(vals, true)?;
            }''',
'B_leb_dispatch')

# emit_symbol_diff tail: keep the diff_symbol path; add LEB emit + defer_leb_diff after it
sub1('src/backend/elf_writer_common.rs',
'''            let section = &mut self.sections[sec_idx];
            section.data.extend(std::iter::repeat_n(0, size));
        }
        Ok(())
    }

    fn encode_instruction(&mut self, instr: &Instruction) -> Result<(), String> {''',
'''            let section = &mut self.sections[sec_idx];
            section.data.extend(std::iter::repeat_n(0, size));
        }
        Ok(())
    }

    /// Emit ULEB128/SLEB128 data values. Integer values are encoded directly;
    /// symbol differences are deferred and folded once label positions are known.
    fn emit_leb_values(&mut self, vals: &[DataValue], signed: bool) -> Result<(), String> {
        self.ensure_section()?;
        let sec_idx = self.current_section.unwrap();
        for val in vals {
            match val {
                DataValue::Integer(v) => {
                    let section = &mut self.sections[sec_idx];
                    if signed {
                        encode_sleb128(&mut section.data, *v);
                    } else {
                        encode_uleb128(&mut section.data, *v as u64);
                    }
                }
                DataValue::SymbolDiff(a, b) => {
                    self.defer_leb_diff(sec_idx, a, b, 0, signed)?;
                }
                DataValue::SymbolDiffAddend(a, b, addend) => {
                    self.defer_leb_diff(sec_idx, a, b, *addend, signed)?;
                }
                DataValue::Symbol(sym) | DataValue::SymbolOffset(sym, _) => {
                    return Err(format!(
                        "unsupported symbol reference {} in .uleb128/.sleb128", sym
                    ));
                }
            }
        }
        Ok(())
    }

    fn defer_leb_diff(
        &mut self, sec_idx: usize, a: &str, b: &str, addend: i64, signed: bool,
    ) -> Result<(), String> {
        let a_resolved = self.aliases.get(a).cloned().unwrap_or_else(|| a.to_string());
        let b_resolved = self.aliases.get(b).cloned().unwrap_or_else(|| b.to_string());
        let offset = self.sections[sec_idx].data.len();
        if b_resolved == "." {
            return Err("symbol minus current position in .uleb128 is unsupported".to_string());
        }
        // Forward references are fine: resolution happens after all items
        // are processed and every label position is known. Reserve the
        // maximum LEB128 width (10 bytes for u64); resolve shrinks to fit.
        self.deferred_leb_diffs.push((sec_idx, offset, a_resolved, b_resolved, addend, signed));
        self.sections[sec_idx].data.extend(std::iter::repeat_n(0, 10));
        Ok(())
    }

    fn encode_instruction(&mut self, instr: &Instruction) -> Result<(), String> {''',
'B_leb_emit')

# shift helper + restructured resolve_deferred_byte_diffs
sub1('src/backend/elf_writer_common.rs',
'''    fn resolve_deferred_byte_diffs(&mut self) -> Result<(), String> {
        let diffs = std::mem::take(&mut self.deferred_byte_diffs);''',
'''    /// Shift offsets >= `from` in section `sec_idx` by `-delta` (used when
    /// LEB128 placeholders shrink). Keeps labels, numeric labels, relocations,
    /// jumps, alignment markers and deferred skips consistent after splicing.
    fn shift_section_offsets(&mut self, sec_idx: usize, from: usize, delta: u64) {
        for (_, (lsec, loff)) in self.label_positions.iter_mut() {
            if *lsec == sec_idx && (*loff as usize) >= from {
                *loff -= delta;
            }
        }
        for (_, positions) in self.numeric_label_positions.iter_mut() {
            for (lsec, loff) in positions.iter_mut() {
                if *lsec == sec_idx && (*loff as usize) >= from {
                    *loff -= delta;
                }
            }
        }
        for reloc in self.sections[sec_idx].relocations.iter_mut() {
            if (reloc.offset as usize) >= from {
                reloc.offset -= delta;
            }
        }
        for jump in self.sections[sec_idx].jumps.iter_mut() {
            if jump.offset >= from {
                jump.offset -= delta as usize;
            }
        }
        for marker in self.sections[sec_idx].align_markers.iter_mut() {
            if marker.offset >= from {
                marker.offset -= delta as usize;
            }
        }
        for (skip_sec, skip_off, _, _) in self.deferred_skips.iter_mut() {
            if *skip_sec == sec_idx && *skip_off >= from {
                *skip_off -= delta as usize;
            }
        }
    }

    fn resolve_deferred_byte_diffs(&mut self) -> Result<(), String> {
        // Fold deferred LEB128 diffs once label positions are known.
        // Resolve from the END of each section backwards so shrinking the
        // 10-byte placeholder does not invalidate earlier offsets.
        let mut leb_diffs = std::mem::take(&mut self.deferred_leb_diffs);
        leb_diffs.sort_by(|a, b| b.0.cmp(&a.0).then(b.1.cmp(&a.1)));
        let mut diffs = std::mem::take(&mut self.deferred_byte_diffs);
        for (sec_idx, offset, sym_a, sym_b, addend, signed) in &leb_diffs {
            let pos_a = self.label_positions.get(sym_a)
                .ok_or_else(|| format!("undefined label in .uleb128 diff: {}", sym_a))?;
            let pos_b = self.label_positions.get(sym_b)
                .ok_or_else(|| format!("undefined label in .uleb128 diff: {}", sym_b))?;
            let diff = (pos_a.1 as i64) - (pos_b.1 as i64) + addend;
            let mut encoded: Vec<u8> = Vec::new();
            if *signed {
                encode_sleb128(&mut encoded, diff);
            } else {
                encode_uleb128(&mut encoded, diff as u64);
            }
            const PLACE: usize = 10;
            if *offset + PLACE > self.sections[*sec_idx].data.len() {
                return Err("internal: .uleb128 diff placeholder overflow".to_string());
            }
            self.sections[*sec_idx].data.splice(*offset..*offset + PLACE, encoded.iter().copied());
            let delta = PLACE - encoded.len();
            if delta > 0 {
                let from = *offset + encoded.len();
                self.shift_section_offsets(*sec_idx, from, delta as u64);
                for (dsec, doff, _, _, _, _) in diffs.iter_mut() {
                    if *dsec == *sec_idx && *doff >= from {
                        *doff -= delta;
                    }
                }
            }
        }
        let diffs = std::mem::take(&mut self.deferred_byte_diffs);''',
'B_leb_resolve')

# extend deferred-byte-diff shifting for LEB diffs too (in relax path)
sub1('src/backend/elf_writer_common.rs',
'''            for (bsec, boff, _, _, _, _) in self.deferred_byte_diffs.iter_mut() {
                if *bsec == *sec_idx && *boff >= *offset {
                    *boff += count;
                }
            }''',
'''            for (bsec, boff, _, _, _, _) in self.deferred_byte_diffs.iter_mut() {
                if *bsec == *sec_idx && *boff >= *offset {
                    *boff += count;
                }
            }
            for (bsec, boff, _, _, _, _) in self.deferred_leb_diffs.iter_mut() {
                if *bsec == *sec_idx && *boff >= *offset {
                    *boff += count;
                }
            }''',
'B_leb_shift')

# size 4/8 support in deferred byte diff resolution + LEB encoders at file end
sub1('src/backend/elf_writer_common.rs',
'''            let diff = (pos_a.1 as i64) - (pos_b.1 as i64) + addend;
            match size {
                1 => {
                    self.sections[*sec_idx].data[*offset] = diff as u8;
                }
                2 => {
                    let bytes = (diff as i16).to_le_bytes();
                    self.sections[*sec_idx].data[*offset] = bytes[0];
                    self.sections[*sec_idx].data[*offset + 1] = bytes[1];
                }
                _ => unreachable!(),
            }
        }
        Ok(())
    }''',
'''            let diff = (pos_a.1 as i64) - (pos_b.1 as i64) + addend;
            match size {
                1 => {
                    self.sections[*sec_idx].data[*offset] = diff as u8;
                }
                2 => {
                    let bytes = (diff as i16).to_le_bytes();
                    self.sections[*sec_idx].data[*offset] = bytes[0];
                    self.sections[*sec_idx].data[*offset + 1] = bytes[1];
                }
                4 => {
                    let bytes = (diff as i32).to_le_bytes();
                    for (k, b) in bytes.iter().enumerate() {
                        self.sections[*sec_idx].data[*offset + k] = *b;
                    }
                }
                8 => {
                    let bytes = diff.to_le_bytes();
                    for (k, b) in bytes.iter().enumerate() {
                        self.sections[*sec_idx].data[*offset + k] = *b;
                    }
                }
                _ => unreachable!(),
            }
        }
        Ok(())
    }''',
'B_diff_48')

s = open(SRC + 'src/backend/elf_writer_common.rs').read()
if 'fn encode_uleb128(' not in s:
    s += '''
/// ULEB128 encode (used by .uleb128 data emission).
pub(crate) fn encode_uleb128(out: &mut Vec<u8>, mut v: u64) {
    loop {
        let mut byte = (v & 0x7F) as u8;
        v >>= 7;
        if v != 0 {
            byte |= 0x80;
        }
        out.push(byte);
        if v == 0 {
            break;
        }
    }
}

/// SLEB128 encode (used by .sleb128 data emission).
pub(crate) fn encode_sleb128(out: &mut Vec<u8>, mut val: i64) {
    loop {
        let mut byte = (val & 0x7F) as u8;
        val >>= 7;
        let sign = byte & 0x40 != 0;
        if (val == 0 && !sign) || (val == -1 && sign) {
            out.push(byte);
            break;
        }
        byte |= 0x80;
        out.push(byte);
    }
}
'''
    open(SRC + 'src/backend/elf_writer_common.rs', 'w').write(s)
print("ok B_leb_encoders")

# ============ E. addend honored in diff relocation resolution ============
sub1('src/backend/elf_writer_common.rs',
'''                            if a_sec == b_sec {
                                let val = a_off as i64 - b_off as i64;
                                resolved.push((reloc.offset as usize, val, reloc.patch_size as usize));
                                continue;
                            }''',
'''                            if a_sec == b_sec {
                                let val = a_off as i64 - b_off as i64 + reloc.addend;
                                resolved.push((reloc.offset as usize, val, reloc.patch_size as usize));
                                continue;
                            }''',
'E_diff_addend')

# ============ G. alignment fixup for EVERY section ============
sub1('src/backend/elf_writer_common.rs',
'''        if A::supports_deferred_skips() {
            self.resolve_deferred_skips()?;
            self.resolve_deferred_byte_diffs()?;
        }

        // Resolve internal relocations
        self.resolve_internal_relocations();''',
'''        if A::supports_deferred_skips() {
            self.resolve_deferred_skips()?;
            self.resolve_deferred_byte_diffs()?;
        }

        // Fix alignment/org markers for EVERY section (the jump-relaxation
        // path only does this for sections with jumps; .eh_frame never had
        // its `.align` padding fixed up otherwise).
        for sec_idx in 0..self.sections.len() {
            self.fixup_alignment_markers(sec_idx);
        }

        // Resolve internal relocations
        self.resolve_internal_relocations();''',
'G_align_all')

# ============ H. `defined X` protected from macro expansion ============
sub1('src/frontend/preprocessor/macro_defs.rs',
'''            } else if is_ident_start_byte(b) && !(self.asm_mode && b == b'$') {
                i = self.expand_identifier(text, bytes, i, &mut result, expanding);
            } else if b == b'/' && i + 1 < len && bytes[i + 1] == b'*' {''',
'''            } else if is_ident_start_byte(b) && !(self.asm_mode && b == b'$') {
                // `defined X` / `defined(X)` operands must not be macro-expanded
                // (C11 6.10.1p1). This matters when a macro BODY contains
                // `defined X` (e.g. glibc's ISA_SHOULD_BUILD): expanding the
                // operand here would turn `defined FOO` into `defined 1` and
                // the #if evaluator could no longer resolve it.
                if bytes[i..].starts_with(b"defined")
                    && (i + 7 >= len || !is_ident_cont_byte(bytes[i + 7]))
                {
                    let mut j = i + 7;
                    while j < len && (bytes[j] == b' ' || bytes[j] == b'\\t') { j += 1; }
                    let has_paren = j < len && bytes[j] == b'(';
                    if has_paren {
                        j += 1;
                        while j < len && (bytes[j] == b' ' || bytes[j] == b'\\t') { j += 1; }
                    }
                    let name_start = j;
                    while j < len && is_ident_cont_byte(bytes[j]) { j += 1; }
                    if name_start == j {
                        // Not a valid defined-operand; fall back to normal expansion.
                        i = self.expand_identifier(text, bytes, i, &mut result, expanding);
                        continue;
                    }
                    result.push_str(&text[i..j]); // "defined X" or "defined (X"
                    i = j;
                    if has_paren {
                        while i < len && (bytes[i] == b' ' || bytes[i] == b'\\t') { i += 1; }
                        if i < len && bytes[i] == b')' {
                            result.push(')');
                            i += 1;
                        }
                    }
                    continue;
                }
                i = self.expand_identifier(text, bytes, i, &mut result, expanding);
            } else if b == b'/' && i + 1 < len && bytes[i + 1] == b'*' {''',
'H_defined_operand')

# ============ I. mempcpy / stpcpy builtins ============
sub1('src/frontend/sema/builtins.rs',
'''    m.insert("__builtin_memcpy", BuiltinInfo::simple("memcpy"));''',
'''    m.insert("__builtin_memcpy", BuiltinInfo::simple("memcpy"));
    m.insert("__builtin_mempcpy", BuiltinInfo::simple("mempcpy"));''',
'I_mempcpy')

sub1('src/frontend/sema/builtins.rs',
'''    m.insert("__builtin_strcpy", BuiltinInfo::simple("strcpy"));''',
'''    m.insert("__builtin_strcpy", BuiltinInfo::simple("strcpy"));
    m.insert("__builtin_stpcpy", BuiltinInfo::simple("stpcpy"));''',
'I_stpcpy')

print("ALL ROUND-2 FIXES APPLIED")
