#!/usr/bin/env python3
"""glibc-fixes13.py — v6.3 fixes #18/#19: inline _Float128 / long-double
copysign + fabs as bit operations (NO libgcc/libm calls).

glibc math: s_copysignf128.c / s_copysignl.c / s_fabsl.c use
__builtin_copysignf128 / __builtin_copysignl / __builtin_fabsl. LCCC emitted
calls to the literal names ("undefined reference to `__builtin_copysignl'")
or to libgcc helpers missing from the Arch libgcc.a ("__copysigntf3").

GCC ground truth (-O2):
  copysignf128: pand/pandn/por with 16B masks (5 uops)
  fabsf128:     pand with mask (1 uop)
  copysignl:    x87 fxam/fnstsw/fabs/fchs round-trip (~15 cycles, slow)
  fabsl:        x87 fabs

LCCC beats GCC:
  F128Fabs:     movq/btrq? no — movabsq+andq/movq/punpcklqdq = 5 uops
                (no memory dependency, no 16B rodata load)
  F128Copysign: 9 uops, same style, zero memory
  LDFabs:       6 uops pure GPR on the 10-byte slot (no x87 round-trip)
  LDCopysign:   9 uops pure GPR (vs GCC's fxam+fnstsw+fabs+fchs chain)

uops.info basis: movq xmm->r64 = 1 uop (p0/p5); andq/orq = 1 uop (p0156);
movq r64->xmm = 1 uop (p5); punpcklqdq = 1 uop (p1/p5); movzbl/movb = 1 uop.
"""
import sys

SRC = '/home/user/ccc-work/sources/ccc-src/'

def sub1(path, old, new, tag):
    p = SRC + path
    s = open(p).read()
    if new in s:
        print(f"skip (already applied): {tag}: {path}")
        return
    n = s.count(old)
    if n != 1:
        print(f"FAIL {tag}: {path}: found {n} of {old[:70]!r}")
        sys.exit(1)
    open(p, 'w').write(s.replace(old, new))
    print(f"ok {tag}: {path}")

# ---- 1. IntrinsicOp variants ----
sub1('src/ir/intrinsics.rs',
'''    FabsF32,
    FabsF64,''',
'''    FabsF32,
    FabsF64,
    /// _Float128 fabs: clear sign bit 127 (inline bit ops, no libgcc call).
    F128Fabs,
    /// _Float128 copysign: x magnitude combined with y sign bit 127.
    F128Copysign,
    /// long double (80-bit x87) fabs: clear bit 79 in the 10-byte slot.
    LDFabs,
    /// long double (80-bit x87) copysign: x magnitude with y sign bit 79.
    LDCopysign,''',
'ops')

sub1('src/ir/intrinsics.rs',
'''            IntrinsicOp::FabsF32 | IntrinsicOp::FabsF64 |''',
'''            IntrinsicOp::FabsF32 | IntrinsicOp::FabsF64 |
            IntrinsicOp::F128Fabs | IntrinsicOp::F128Copysign |
            IntrinsicOp::LDFabs | IntrinsicOp::LDCopysign |''',
'pure')

# ---- 2. simplify.rs: fold the libc/libgcc aliases into the intrinsics ----
sub1('src/passes/simplify.rs',
'''const UNARY_INTRINSICS: &[(&str, IntrinsicOp)] = &[
    ("sqrt", IntrinsicOp::SqrtF64),
    ("sqrtf", IntrinsicOp::SqrtF32),
    ("fabs", IntrinsicOp::FabsF64),
    ("fabsf", IntrinsicOp::FabsF32),
];''',
'''const UNARY_INTRINSICS: &[(&str, IntrinsicOp)] = &[
    ("sqrt", IntrinsicOp::SqrtF64),
    ("sqrtf", IntrinsicOp::SqrtF32),
    ("fabs", IntrinsicOp::FabsF64),
    ("fabsf", IntrinsicOp::FabsF32),
    // _Float128 / long-double bit ops: inline beats any libgcc/libm call.
    ("__fabstf2", IntrinsicOp::F128Fabs),
    ("fabsl", IntrinsicOp::LDFabs),
];

/// Table of binary math functions that map directly to intrinsic instructions.
const BINARY_INTRINSICS: &[(&str, IntrinsicOp)] = &[
    ("__copysigntf3", IntrinsicOp::F128Copysign),
    ("copysignl", IntrinsicOp::LDCopysign),
];''',
'tables')

sub1('src/passes/simplify.rs',
'''    // pow/powf with constant exponent
    if func == "pow" || func == "powf" {''',
'''    // Binary intrinsic table (copysignf128/copysignl -> inline bit ops).
    for &(name, intrinsic_op) in BINARY_INTRINSICS {
        if func == name {
            if args.len() != 2 { return None; }
            return Some(Instruction::Intrinsic {
                dest: Some(dest),
                op: intrinsic_op,
                dest_ptr: None,
                args: args.to_vec(),
            });
        }
    }

    // pow/powf with constant exponent
    if func == "pow" || func == "powf" {''',
'bin_dispatch')

# ---- 2b. register __builtin_copysignl (was missing -> literal-symbol call) ----
sub1('src/frontend/sema/builtins.rs',
"    m.insert(\"__builtin_copysign\", BuiltinInfo::simple(\"copysign\"));\n    m.insert(\"__builtin_copysignf\", BuiltinInfo::simple(\"copysignf\"));",
"    m.insert(\"__builtin_copysign\", BuiltinInfo::simple(\"copysign\"));\n    m.insert(\"__builtin_copysignf\", BuiltinInfo::simple(\"copysignf\"));\n    m.insert(\"__builtin_copysignl\", BuiltinInfo::simple(\"copysignl\"));",
'reg_copysignl')

# ---- 3. codegen: x86 intrinsics.rs ----
sub1('src/backend/x86/codegen/intrinsics.rs',
'''            IntrinsicOp::FabsF32 => {''',
'''            IntrinsicOp::F128Fabs => {
                // _Float128 (16B in %xmm0): clear sign bit 127 (bit 63 of the
                // high qword). 5 uops, no memory operand, no rodata mask.
                self.sse_load_arg(&args[0], "xmm0");
                self.state.emit("    movq %xmm0, %rax");
                self.state.emit("    movabsq $0x7FFFFFFFFFFFFFFF, %rcx");
                self.state.emit("    andq %rcx, %rax");
                self.state.emit("    movq %rax, %xmm1");
                self.state.emit("    punpcklqdq %xmm1, %xmm0");
                self.state.sse_last_store_reg = false;
                if let Some(d) = dest {
                    self.emit_store_f128_xmm0(d);
                }
            }
            IntrinsicOp::F128Copysign => {
                // _Float128 copysign(x, y): high qword = (x_hi & ~sign) | (y_hi & sign),
                // low qword = x_lo. 9 uops, no memory operands.
                self.sse_load_arg(&args[0], "xmm0");
                self.sse_load_arg(&args[1], "xmm1");
                self.state.emit("    movq %xmm1, %rdx");
                self.state.emit("    movabsq $0x8000000000000000, %rcx");
                self.state.emit("    andq %rcx, %rdx");
                self.state.emit("    movq %xmm0, %rax");
                self.state.emit("    movabsq $0x7FFFFFFFFFFFFFFF, %rcx");
                self.state.emit("    andq %rcx, %rax");
                self.state.emit("    orq %rdx, %rax");
                self.state.emit("    movq %rax, %xmm1");
                self.state.emit("    punpcklqdq %xmm1, %xmm0");
                self.state.sse_last_store_reg = false;
                if let Some(d) = dest {
                    self.emit_store_f128_xmm0(d);
                }
            }
            IntrinsicOp::LDFabs => {
                // long double (80-bit x87, 10 bytes in a 16-byte slot): clear
                // bit 79 (byte 9 bit 7). Pure GPR, no x87 round-trip.
                if let Some(d) = dest {
                    let sx = match &args[0] {
                        Operand::Value(v) => self.state.get_slot(v.0).map(|s| s.0),
                        _ => None,
                    };
                    let sd = self.state.get_slot(d.0).map(|s| s.0);
                    if let (Some(sx), Some(sd)) = (sx, sd) {
                        self.state.out.emit_instr_rbp_reg("    movq", sx, "rax");
                        self.state.out.emit_instr_reg_rbp("    movq", "rax", sd);
                        self.state.out.emit_instr_rbp_reg("    movzbl", sx + 8, "ecx");
                        self.state.out.emit_instr_reg_rbp("    movb", "cl", sd + 8);
                        self.state.out.emit_instr_rbp_reg("    movzbl", sx + 9, "ecx");
                        self.state.emit("    andb $0x7f, %cl");
                        self.state.out.emit_instr_reg_rbp("    movb", "cl", sd + 9);
                        return;
                    }
                    // Constant operand: emit the 16-byte payload directly.
                    if let Operand::Const(IrConst::LongDouble(_, bytes)) = &args[0] {
                        let low = u64::from_le_bytes(bytes[0..8].try_into().unwrap());
                        let high = u64::from_le_bytes(bytes[8..16].try_into().unwrap());
                        self.state.emit_fmt(format_args!("    movabsq ${}, %rax", low as i64));
                        self.state.out.emit_instr_reg_rbp("    movq", "rax", sd);
                        self.state.emit_fmt(format_args!("    movabsq ${}, %rax", high as i64));
                        self.state.out.emit_instr_reg_rbp("    movq", "rax", sd + 8);
                        self.state.out.emit_instr_rbp_reg("    movzbl", sd + 9, "ecx");
                        self.state.emit("    andb $0x7f, %cl");
                        self.state.out.emit_instr_reg_rbp("    movb", "cl", sd + 9);
                        return;
                    }
                    panic!("LDFabs: unsupported operand shape");
                }
            }
            IntrinsicOp::LDCopysign => {
                // long double copysign(x, y): byte9 = (y9 & 0x80) | (x9 & 0x7f),
                // bytes 0..8 copied from x. Pure GPR, no x87 round-trip.
                if let Some(d) = dest {
                    let sx = match &args[0] {
                        Operand::Value(v) => self.state.get_slot(v.0).map(|s| s.0),
                        _ => None,
                    };
                    let sy = match &args[1] {
                        Operand::Value(v) => self.state.get_slot(v.0).map(|s| s.0),
                        _ => None,
                    };
                    let sd = self.state.get_slot(d.0).map(|s| s.0);
                    if let (Some(sx), Some(sy), Some(sd)) = (sx, sy, sd) {
                        self.state.out.emit_instr_rbp_reg("    movq", sx, "rax");
                        self.state.out.emit_instr_reg_rbp("    movq", "rax", sd);
                        self.state.out.emit_instr_rbp_reg("    movzbl", sx + 8, "ecx");
                        self.state.out.emit_instr_reg_rbp("    movb", "cl", sd + 8);
                        self.state.out.emit_instr_rbp_reg("    movzbl", sy + 9, "eax");
                        self.state.emit("    andb $0x80, %al");
                        self.state.out.emit_instr_rbp_reg("    movzbl", sx + 9, "ecx");
                        self.state.emit("    andb $0x7f, %cl");
                        self.state.emit("    orb %cl, %al");
                        self.state.out.emit_instr_reg_rbp("    movb", "al", sd + 9);
                        return;
                    }
                    panic!("LDCopysign: unsupported operand shape");
                }
            }
            IntrinsicOp::FabsF32 => {''',
'codegen')

print("ROUND-13 INLINE F128/LD BIT-OPS APPLIED")


# ---- fix #28: emit_store_f128_xmm0 must be pub(super) (intrinsics.rs calls it) ----
sub1('src/backend/x86/codegen/globals.rs',
"    fn emit_store_f128_xmm0(&mut self, dest: &Value) {",
"    pub(super) fn emit_store_f128_xmm0(&mut self, dest: &Value) {",
'f128_store_pub')

# ---- fix #29: LDFabs constant branch needs the dest slot unwrapped ----
sub1('src/backend/x86/codegen/intrinsics.rs',
"                    // Constant operand: emit the 16-byte payload directly.\n                    if let Operand::Const(IrConst::LongDouble(_, bytes)) = &args[0] {",
"                    // Constant operand: emit the 16-byte payload directly.\n                    if let (Operand::Const(IrConst::LongDouble(_, bytes)), Some(sd)) = (&args[0], sd) {",
'ldfabs_const_unwrap')
