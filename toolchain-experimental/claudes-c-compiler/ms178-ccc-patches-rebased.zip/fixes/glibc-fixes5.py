#!/usr/bin/env python3
"""glibc-fixes5.py — round-5 deterministic fix layer.

PERSISTED THIS SESSION (survives sandbox resets; the previous session's
symver fix was lost exactly because it was never scripted):

 1. encoder/core.rs: relocation-modifier matches must be case-insensitive
    (GNU as semantics). glibc emits lowercase `sym@gottpoff(%rip)`.
    NOTE the historical typo: GOTTPOFF lowercased is "gottpoff" (two t's),
    NOT "gotpoff" — a one-t arm never matches and silently fell through
    to R_X86_64_PC32, which produced the
    "TLS definition ... mismatches non-TLS reference" linker error.
 2. elf_writer_common.rs: `.symver name, alias@VERSION` (compat) must create
    the versioned alias name `alias@VERSION` (full string incl. @VERSION);
    `.symver name, alias@@VERSION` (default) renames to `alias`. Truncating
    at '@' created a SELF-alias for glibc's `compat_symbol(libc, X, X, V)`
    pattern (.symver _res, _res@GLIBC_2_0) -> duplicate `_res` in one object
    -> "multiple definition of `_res'" at the libc_pic.os link.
"""
import re, sys

def patch(path, old, new, tag):
    s = open(path).read()
    if tag in s:
        print(f"skip (already applied): {path} [{tag}]")
        return
    assert s.count(old) == 1, f"{path}: pattern not unique/found ({tag})"
    open(path, 'w').write(s.replace(old, new))
    print(f"ok: {path} [{tag}]")

ROOT = '/home/user/ccc-work/sources/ccc-src'

# ---- 1. core.rs: case-insensitive modifiers (both match sites) ----
core = f'{ROOT}/src/backend/x86/assembler/encoder/core.rs'
s = open(core).read()
if 'ZZ_MARKER_GOTTPOFF' in s:
    print("skip (already applied): core.rs [modifier lowercase]")
else:
    old1 = '''                    Displacement::SymbolMod(sym, modifier) => {
                        let reloc_type = match modifier.as_str() {
                            "GOTPCREL" => R_X86_64_GOTPCREL,
                            "GOTTPOFF" => R_X86_64_GOTTPOFF,
                            "PLT" => R_X86_64_PLT32,
                            _ => R_X86_64_PC32,
                        };
                        self.add_relocation(sym, reloc_type, -4);'''
    new1 = '''                    Displacement::SymbolMod(sym, modifier) => {
                        // Modifiers are case-insensitive in GNU as: glibc's
                        // multiarch sources emit lowercase `sym@gottpoff(%rip)`.
                        let reloc_type = match modifier.to_ascii_lowercase().as_str() {
                            "gotpcrel" => R_X86_64_GOTPCREL,
                            "gottpoff" => R_X86_64_GOTTPOFF, // ZZ_MARKER_GOTTPOFF
                            "tpoff" => R_X86_64_TPOFF32,
                            "plt" => R_X86_64_PLT32,
                            _ => R_X86_64_PC32,
                        };
                        self.add_relocation(sym, reloc_type, -4);'''
    assert s.count(old1) == 1, "core.rs site1 not found"
    s = s.replace(old1, new1)
    old2 = '''            Displacement::SymbolMod(sym, modifier) => {
                let reloc_type = match modifier.as_str() {
                    "TPOFF" => R_X86_64_TPOFF32,
                    "GOTPCREL" => R_X86_64_GOTPCREL,
                    _ => R_X86_64_32S,
                };
                (0i64, true, Some((sym.clone(), reloc_type, 0i64)))
            }'''
    new2 = '''            Displacement::SymbolMod(sym, modifier) => {
                let reloc_type = match modifier.to_ascii_lowercase().as_str() {
                    "tpoff" => R_X86_64_TPOFF32,
                    "gotpcrel" => R_X86_64_GOTPCREL,
                    "gottpoff" => R_X86_64_GOTTPOFF,
                    _ => R_X86_64_32S,
                };
                (0i64, true, Some((sym.clone(), reloc_type, 0i64)))
            }'''
    assert s.count(old2) == 1, "core.rs site2 not found"
    s = s.replace(old2, new2)
    open(core, 'w').write(s)
    print("ok: core.rs [modifier lowercase, both sites]")

# ---- 2. elf_writer_common.rs: proper GNU-as .symver alias names ----
w = f'{ROOT}/src/backend/elf_writer_common.rs'
s = open(w).read()
if 'versioned alias `alias@VERSION` is added' in s:
    print("skip (already applied): elf_writer_common.rs [symver]")
else:
    old = '''            AsmItem::Symver(name, ver_string) => {
                // .symver name, alias@@VERSION  -> default version: create alias from "alias" to "name"
                // .symver name, alias@VERSION   -> compat version: create alias from "alias" to "name"
                // Extract the unversioned alias name from the version string
                if let Some(at_pos) = ver_string.find('@') {
                    let alias = &ver_string[..at_pos];
                    if !alias.is_empty() {
                        self.aliases.insert(alias.to_string(), name.clone());
                    }
                }
            }'''
    new = '''            AsmItem::Symver(name, ver_string) => {
                // .symver name, alias@@VERSION  -> default version: the symbol is
                //   renamed to `alias` (symbol table entry `alias`).
                // .symver name, alias@VERSION   -> compat version: the symbol keeps
                //   `name` AND a versioned alias `alias@VERSION` is added, exactly
                //   like GNU as (e.g. glibc's `compat_symbol (libc, _res, _res,
                //   GLIBC_2_0)` -> `.symver _res, _res@GLIBC_2_0`).
                // Truncating at '@' produced a self-alias for `local == symbol`
                // cases and hence duplicate definitions in one object.
                if let Some(at_pos) = ver_string.find('@') {
                    let base = &ver_string[..at_pos];
                    let is_default = ver_string[at_pos..].starts_with("@@");
                    if !base.is_empty() {
                        let alias_name = if is_default {
                            base.to_string()
                        } else {
                            ver_string.clone()
                        };
                        if alias_name.as_str() != name.as_str() {
                            self.aliases.insert(alias_name, name.clone());
                        }
                    }
                }
            }'''
    assert s.count(old) == 1, "elf_writer_common.rs symver handler not found"
    open(w, 'w').write(s.replace(old, new))
    print("ok: elf_writer_common.rs [symver GNU-as semantics]")

print("ROUND-5 FIXES APPLIED")
