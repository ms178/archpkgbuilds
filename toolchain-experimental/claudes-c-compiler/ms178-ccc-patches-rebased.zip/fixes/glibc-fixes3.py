#!/usr/bin/env python3
"""glibc-fixes3.py — round-3 reconstruction of the FIRST-session assembler and
driver fixes (lost with the rebased patch; all encodings verified byte-for-byte
against GNU as 2.44 during the audit):

  1. CET shadow-stack instruction family (mod.rs + gp_integer.rs)
  2. CFI directive expression parsing + tolerant .cfi_* handling (parser.rs)
  3. C integer suffixes in assembler constant expressions (asm_expr.rs)
  4. -print-libgcc-file-name sysroot resolution + `-v` GCC line (cli.rs)

Each step asserted; run against a freshly reconstructed tree only.
"""
import sys

SRC = '/home/user/ccc-work/sources/ccc-src/'

def sub1(path, old, new, tag=''):
    p = SRC + path
    s = open(p).read()
    n = s.count(old)
    if n != 1:
        print(f"FAIL {tag}: {path}: found {n} of {old[:70]!r}")
        sys.exit(1)
    open(p, 'w').write(s.replace(old, new))
    print(f"ok {tag}: {path}")

# ============ 1. CET family ============
# 1a. encoders in gp_integer.rs (before the final closing brace)
sub1('src/backend/x86/assembler/encoder/gp_integer.rs',
'''            _ => Err("unsupported xadd operands".to_string()),
        }
    }
}''',
'''            _ => Err("unsupported xadd operands".to_string()),
        }
    }

    // ---- CET shadow-stack family (Intel CET / SHSTK) ----
    // Encodings verified against GNU binutils 2.44 (AT&T syntax):
    //   rstorssp m64      F3 0F 01 /5
    //   saveprevssp       F3 0F 01 EA        (fixed, no ModRM)
    //   setssbsy          F3 0F 01 E8        (fixed, no ModRM)
    //   clrssbsy m64      F3 0F AE /6        (memory operand, mod != 11)
    //   wrssd r32, m32    0F 38 F6 /r
    //   wrssq r64, m64    REX.W 0F 38 F6 /r
    //   wrussd r32, m32   66 0F 38 F5 /r
    //   wrussq r64, m64   66 REX.W 0F 38 F5 /r

    pub(crate) fn encode_rstorssp(&mut self, ops: &[Operand]) -> Result<(), String> {
        if ops.len() != 1 {
            return Err("rstorssp requires 1 memory operand".to_string());
        }
        match &ops[0] {
            Operand::Memory(mem) => {
                self.emit_segment_prefix(mem)?;
                self.bytes.extend_from_slice(&[0xF3, 0x0F, 0x01]);
                self.encode_modrm_mem(5, mem) // /5
            }
            _ => Err("rstorssp requires a memory operand".to_string()),
        }
    }

    pub(crate) fn encode_clrssbsy(&mut self, ops: &[Operand]) -> Result<(), String> {
        if ops.len() != 1 {
            return Err("clrssbsy requires 1 memory operand".to_string());
        }
        match &ops[0] {
            Operand::Memory(mem) => {
                self.emit_segment_prefix(mem)?;
                self.bytes.extend_from_slice(&[0xF3, 0x0F, 0xAE]);
                self.encode_modrm_mem(6, mem) // /6
            }
            _ => Err("clrssbsy requires a memory operand".to_string()),
        }
    }

    /// WRSSD/WRSSQ/WRUSSD/WRUSSQ: store to shadow stack (reg -> memory).
    /// `is_user` selects the WRUSS variant (66-prefixed, opcode F5 vs F6).
    pub(crate) fn encode_wrss(&mut self, ops: &[Operand], size: u8, is_user: bool) -> Result<(), String> {
        if ops.len() != 2 {
            return Err("wrss/wruss requires 2 operands".to_string());
        }
        match (&ops[0], &ops[1]) {
            (Operand::Register(src), Operand::Memory(mem)) => {
                let src_num = reg_num(&src.name).ok_or("bad register")?;
                self.emit_segment_prefix(mem)?;
                if is_user {
                    self.bytes.push(0x66); // 66 operand-size prefix (WRUSS only)
                }
                self.emit_rex_rm(size, &src.name, mem);
                self.bytes.extend_from_slice(&[0x0F, 0x38, if is_user { 0xF5 } else { 0xF6 }]);
                self.encode_modrm_mem(src_num, mem)
            }
            _ => Err("wrss/wruss requires register, memory operands".to_string()),
        }
    }
}''',
'CET_encoders')

# 1b. dispatch in mod.rs after incsspd (incsspd/incsspq may not exist in v1;
#     add the whole family including them)
sub1('src/backend/x86/assembler/encoder/mod.rs',
'''            "pause" => { self.bytes.extend_from_slice(&[0xF3, 0x90]); Ok(()) }''',
'''            // CET shadow-stack family (encodings verified against GNU binutils 2.44)
            "incsspd" => {
                if let Some(Operand::Register(reg)) = ops.first() {
                    let rm = reg_num(&reg.name).ok_or_else(|| format!("unknown register: {}", reg.name))?;
                    self.bytes.push(0xF3);
                    if needs_rex_ext(&reg.name) {
                        self.bytes.push(0x41);
                    }
                    self.bytes.extend_from_slice(&[0x0F, 0xAE]);
                    self.bytes.push(0xE8 | rm);
                    Ok(())
                } else {
                    Err("incsspd requires a 32-bit register operand".to_string())
                }
            }
            "incsspq" => {
                if let Some(Operand::Register(reg)) = ops.first() {
                    let rm = reg_num(&reg.name).ok_or_else(|| format!("unknown register: {}", reg.name))?;
                    self.bytes.push(0xF3);
                    let rex_b = if needs_rex_ext(&reg.name) { 1 } else { 0 };
                    self.bytes.push(0x48 | rex_b);
                    self.bytes.extend_from_slice(&[0x0F, 0xAE]);
                    self.bytes.push(0xE8 | rm);
                    Ok(())
                } else {
                    Err("incsspq requires a 64-bit register operand".to_string())
                }
            }
            "rstorssp" => self.encode_rstorssp(ops),
            "clrssbsy" => self.encode_clrssbsy(ops),
            "saveprevssp" => {
                if ops.is_empty() {
                    self.bytes.extend_from_slice(&[0xF3, 0x0F, 0x01, 0xEA]);
                    Ok(())
                } else {
                    Err("saveprevssp takes no operands".to_string())
                }
            }
            "setssbsy" => {
                if ops.is_empty() {
                    self.bytes.extend_from_slice(&[0xF3, 0x0F, 0x01, 0xE8]);
                    Ok(())
                } else {
                    Err("setssbsy takes no operands".to_string())
                }
            }
            "wrssd" => self.encode_wrss(ops, 4, false),
            "wrssq" => self.encode_wrss(ops, 8, false),
            "wrussd" => self.encode_wrss(ops, 4, true),
            "wrussq" => self.encode_wrss(ops, 8, true),
            "pause" => { self.bytes.extend_from_slice(&[0xF3, 0x90]); Ok(()) }''',
'CET_dispatch')

# ============ 2. CFI directives ============
sub1('src/backend/x86/assembler/parser.rs',
'''        ".cfi_def_cfa_offset" => {
            let val: i32 = args.trim().parse()
                .map_err(|_| format!("bad cfi offset: {}", args))?;
            Ok(AsmItem::Cfi(CfiDirective::DefCfaOffset(val)))
        }''',
'''        ".cfi_def_cfa_offset" => {
            // Accept full constant expressions (e.g. "8*2", "N*8+N").
            let val = parse_integer_expr(args.trim())
                .map_err(|_| format!("bad cfi offset: {}", args))?;
            Ok(AsmItem::Cfi(CfiDirective::DefCfaOffset(val as i32)))
        }''',
'CFI_defcfa')

sub1('src/backend/x86/assembler/parser.rs',
'''        ".cfi_offset" => {
            // .cfi_offset %rbp, -16
            let parts: Vec<&str> = args.splitn(2, ',').collect();
            if parts.len() != 2 {
                return Ok(AsmItem::Cfi(CfiDirective::Other(line.to_string())));
            }
            let reg = parts[0].trim().trim_start_matches('%').to_string();
            let off: i32 = parts[1].trim().parse()
                .map_err(|_| format!("bad cfi offset value: {}", args))?;
            Ok(AsmItem::Cfi(CfiDirective::Offset(reg, off)))
        }''',
'''        ".cfi_offset" => {
            // .cfi_offset %rbp, -16  (offset may be a constant expression)
            let parts: Vec<&str> = args.splitn(2, ',').collect();
            if parts.len() != 2 {
                return Ok(AsmItem::Cfi(CfiDirective::Other(line.to_string())));
            }
            let reg = parts[0].trim().trim_start_matches('%').to_string();
            let off = parse_integer_expr(parts[1].trim())
                .map_err(|_| format!("bad cfi offset value: {}", args))?;
            Ok(AsmItem::Cfi(CfiDirective::Offset(reg, off as i32)))
        }''',
'CFI_offset')

sub1('src/backend/x86/assembler/parser.rs',
'''        _ => {
            // Unknown directive - just ignore it with a warning
            // This handles .ident, .addrsig, etc. that GCC might emit
            Ok(AsmItem::Empty)
        }
    }
}''',
'''        d if d.starts_with(".cfi_") => {
            // Any other .cfi_* directive (e.g. .cfi_restore, .cfi_adjust_cfa_offset,
            // .cfi_def_cfa, .cfi_register, .cfi_undefined, .cfi_escape, .cfi_personality,
            // .cfi_lsda, .cfi_sections, .cfi_signal_frame, .cfi_remember_state,
            // .cfi_restore_state, .cfi_val_offset, .cfi_expression, ...): record
            // tolerantly. CFI is parsed but not emitted by the builtin assembler,
            // so any argument shape (registers, constant expressions, symbols,
            // string args) must never abort assembly of glibc/GCC-generated .S.
            Ok(AsmItem::Cfi(CfiDirective::Other(line.to_string())))
        }
        _ => {
            // Unknown directive - just ignore it with a warning
            // This handles .ident, .addrsig, etc. that GCC might emit
            Ok(AsmItem::Empty)
        }
    }
}''',
'CFI_catchall')

# ============ 3. asm_expr C integer suffixes ============
sub1('src/backend/asm_expr.rs',
'''fn parse_single_integer(s: &str) -> Result<i64, String> {
    let s = s.trim();
    if s.is_empty() {
        return Err("empty integer".to_string());
    }

    // Character literal:''',
'''fn parse_single_integer(s: &str) -> Result<i64, String> {
    let s = s.trim();
    if s.is_empty() {
        return Err("empty integer".to_string());
    }

    // Strip C integer suffixes (u/U/l/L/z/Z, incl. LL/ULL combos).
    let s = {
        let bytes = s.as_bytes();
        let mut end = bytes.len();
        while end > 0 && matches!(bytes[end - 1], b'u' | b'U' | b'l' | b'L' | b'z' | b'Z') {
            end -= 1;
        }
        &s[..end]
    };
    if s.is_empty() {
        return Err("integer has only a suffix".to_string());
    }

    // Character literal:''',
'ASMEXPR_suffix_strip')

sub1('src/backend/asm_expr.rs',
'''            } else {
                while i < bytes.len() && bytes[i].is_ascii_digit() { i += 1; }
            }
            let num_str = &s[start..i];
            let val = parse_single_integer(num_str)?;
            tokens.push(ExprToken::Num(val));
        } else {''',
'''            } else {
                while i < bytes.len() && bytes[i].is_ascii_digit() { i += 1; }
            }
            // C integer suffixes (u/U/l/L/z/Z, incl. LL/ULL combos) are valid
            // in assembler constant expressions (e.g. `$(1U<<1)` from glibc).
            let mut suffix_len = 0;
            while i + suffix_len < bytes.len()
                && matches!(bytes[i + suffix_len], b'u' | b'U' | b'l' | b'L' | b'z' | b'Z')
                && suffix_len < 4
            {
                suffix_len += 1;
            }
            i += suffix_len;
            let num_str = &s[start..i];
            let val = parse_single_integer(num_str)?;
            tokens.push(ExprToken::Num(val));
        } else {''',
'ASMEXPR_tokenizer')

# ============ 4. driver: -print-libgcc-file-name sysroot + -v GCC line ============




print("ALL ROUND-3 FIXES APPLIED")

# ============ 4b. driver: sysroot capture + query arms + -v GCC line ============
# (v1 does not contain these query arms at all; insert the full validated set)
sub1('src/driver/cli.rs',
'''    fn handle_query_flags(args: &[String], target: &Target) -> Result<bool, String> {
        for arg in &args[1..] {''',
'''    fn handle_query_flags(args: &[String], target: &Target) -> Result<bool, String> {
        // Capture --sysroot / -isysroot so -print-libgcc-file-name and
        // -print-file-name= resolve against the sysroot when one is given.
        let mut sysroot: Option<String> = None;
        {
            let mut it = args[1..].iter();
            while let Some(a) = it.next() {
                if let Some(v) = a.strip_prefix("--sysroot=") {
                    if !v.is_empty() {
                        sysroot = Some(v.to_string());
                    }
                } else if a == "--sysroot" || a == "-isysroot" {
                    if let Some(v) = it.next() {
                        sysroot = Some(v.clone());
                    }
                }
            }
        }

        for arg in &args[1..] {''',
'CLI_sysroot_capture')

sub1('src/driver/cli.rs',
'''                "-v" if args.len() == 2 => {
                    println!("lccc (a high performance Claude's C Compiler fork, GCC-compatible) 14.2.0");
                    println!("Target: {}", target.triple());
                    return Ok(true);
                }''',
'''                "-v" if args.len() == 2 => {
                    println!("lccc (a high performance Claude's C Compiler fork, GCC-compatible) 14.2.0");
                    // GCC-style line so configure scripts that grep `-v` output
                    // for "gcc" (e.g. zlib-ng's compiler detection) classify the
                    // driver as GCC-compatible and enable the -fPIC/-std paths.
                    println!("gcc version 14.2.0 (lccc)");
                    println!("Target: {}", target.triple());
                    return Ok(true);
                }''',
'CLI_vline')

sub1('src/driver/cli.rs',
'''                _ if arg.starts_with("-print-file-name=") => {''',
'''                "-print-multi-directory" => {
                    // GCC prints "." for native x86-64. glibc derives its
                    // `multidir` from this; an empty answer makes glibc's
                    // csu/Makefile try to create a symlink to an empty
                    // directory name and fail.
                    println!(".");
                    return Ok(true);
                }
                "-print-libgcc-file-name" => {
                    // GCC query used by build systems (glibc) to find the
                    // compiler runtime. Reuse the -print-file-name= search for
                    // libgcc.a so glibc's configure accepts the toolchain.
                    let name = "libgcc.a";
                    let triple = target.triple();
                    // Prefer sysroot-relative GCC runtimes (glibc cross-style builds),
                    // then fall back to host GCC installs. Version directories are
                    // enumerated (Arch ships e.g. "16.1.1", not "16").
                    let mut search_dirs: Vec<String> = Vec::new();
                    if let Some(ref s) = sysroot {
                        for triple_dir in [
                            format!("{}/usr/lib/gcc/{}/", s, triple),
                            format!("{}/usr/lib/gcc/x86_64-pc-linux-gnu/", s),
                        ] {
                            if let Ok(rd) = std::fs::read_dir(&triple_dir) {
                                let mut vers: Vec<String> = rd
                                    .filter_map(|e| e.ok())
                                    .filter(|e| e.file_type().map(|t| t.is_dir()).unwrap_or(false))
                                    .map(|e| e.file_name().to_string_lossy().to_string())
                                    .filter(|n| n.chars().next().map(|c| c.is_ascii_digit()).unwrap_or(false))
                                    .collect();
                                vers.sort();
                                vers.reverse();
                                for v in vers {
                                    search_dirs.push(format!("{}{}/", triple_dir, v));
                                }
                            }
                        }
                        search_dirs.push(format!("{}/usr/lib/", s));
                    }
                    search_dirs.extend([
                        format!("/usr/lib/gcc/{}/13/", triple),
                        format!("/usr/lib/gcc/{}/12/", triple),
                        format!("/usr/lib/gcc/{}/11/", triple),
                        format!("/usr/lib/gcc/{}/14/", triple),
                        format!("/usr/lib/gcc/{}/15/", triple),
                        format!("/usr/lib/gcc/{}/16/", triple),
                        "/usr/lib/gcc/x86_64-linux-gnu/14/".to_string(),
                        "/usr/lib/".to_string(),
                    ]);
                    let mut found = false;
                    for dir in &search_dirs {
                        let path = format!("{}{}", dir, name);
                        if std::path::Path::new(&path).exists() {
                            println!("{}", path);
                            found = true;
                            break;
                        }
                    }
                    if !found {
                        println!("{}", name);
                    }
                    return Ok(true);
                }
                _ if arg.starts_with("-print-file-name=") => {''',
'CLI_query_arms')
