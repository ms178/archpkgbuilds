#!/usr/bin/env python3
"""glibc-fixes4.py — round-4 fixes from the final glibc build attempts
(reconstructed verbatim from the validated session; all verified with the
regression suite 30/30 and byte-level tests):

  1. C23 `[[attr]]` statement/declaration attribute skip (parser/parse.rs)
     - glibc cpu-features.c uses `[[fallthrough]];`
  2. `__attribute__((used))` static functions are reachability ROOTS
     (ir/lowering/ref_collection.rs) — glibc `static __used__ _dl_start`
     is called from asm; its callees (rtld_timer_start) were skipped.
  3. __builtin_ia32_rdtsc / __builtin_ia32_rdtscp intrinsics
     (ir/intrinsics.rs, sema/builtins.rs, expr_builtins.rs, x86 intrinsics.rs)
  4. gnu_inline conversion to declaration ONLY when no calls remain
     (passes/mod.rs) — glibc rtld `free`/`__bsearch` extern-inline defs
     must stay emitted as local definitions when a call site survived.
  5. Global-variable `__asm__("label")` redirect in expr.rs load path
     (glibc hidden_proto data: `extern const char x[] __asm__("__GI_x")`).

Each step asserted; run against a freshly reconstructed tree only.
"""
import sys

SRC = '/home/user/ccc-work/sources/ccc-src/'

def sub1(path, old, new, tag=''):
    p = SRC + path
    s = open(p).read()
    n = s.count(old)
    if n != 1:
        print(f"FAIL {tag}: {path}: found {n} of {old[:70]!r}")
        sys.exit(1)
    open(p, 'w').write(s.replace(old, new))
    print(f"ok {tag}: {path}")

# ============ 1. C23 [[attr]] skip ============
sub1('src/frontend/parser/parse.rs',
'''    pub(super) fn skip_gcc_extensions(&mut self) {
        let (_, aligned, _, _) = self.parse_gcc_attributes();''',
'''    pub(super) fn skip_gcc_extensions(&mut self) {
        // C23 [[...]] attribute lists before statements/declarations
        // (e.g. `[[fallthrough]];` from glibc's cpu-features.c): skip them.
        // LCCC does not model statement attributes, so they are ignored.
        loop {
            if self.pos + 1 < self.tokens.len()
                && matches!(self.tokens[self.pos].kind, TokenKind::LBracket)
                && matches!(self.tokens[self.pos + 1].kind, TokenKind::LBracket)
            {
                self.advance();
                self.advance();
                let mut depth = 0usize;
                loop {
                    if self.at_eof() {
                        break;
                    }
                    match self.peek() {
                        TokenKind::LBracket => {
                            depth += 1;
                            self.advance();
                        }
                        TokenKind::RBracket => {
                            if depth > 0 {
                                depth -= 1;
                                self.advance();
                            } else if self.pos + 1 < self.tokens.len()
                                && matches!(self.tokens[self.pos + 1].kind, TokenKind::RBracket)
                            {
                                self.advance();
                                self.advance();
                                break;
                            } else {
                                self.advance();
                            }
                        }
                        _ => {
                            self.advance();
                        }
                    }
                }
            } else {
                break;
            }
        }
        let (_, aligned, _, _) = self.parse_gcc_attributes();''',
'c23_attrs')

# ============ 2. __attribute__((used)) roots ============
sub1('src/ir/lowering/ref_collection.rs',
'''                ExternalDecl::FunctionDef(func) => {
                    if self.is_skippable_function(func) {
                        // For skippable functions, collect their refs into a separate map
                        // so we can do transitive closure later
                        let mut func_refs = FxHashSet::default();
                        self.collect_refs_from_compound(&func.body, &mut func_refs);
                        skippable_refs.insert(func.name.clone(), func_refs);
                    } else {
                        // Root function: collect refs directly into the referenced set
                        self.collect_refs_from_compound(&func.body, &mut referenced);
                    }
                }''',
'''                ExternalDecl::FunctionDef(func) => {
                    if self.is_skippable_function(func) && !func.attrs.is_used() {
                        // For skippable functions, collect their refs into a separate map
                        // so we can do transitive closure later
                        let mut func_refs = FxHashSet::default();
                        self.collect_refs_from_compound(&func.body, &mut func_refs);
                        skippable_refs.insert(func.name.clone(), func_refs);
                    } else {
                        // Root function: collect refs directly into the referenced set.
                        // __attribute__((used)) functions (e.g. glibc's `static
                        // __attribute__((__used__)) _dl_start`, called from asm)
                        // are roots even though they are static — otherwise their
                        // callees (rtld_timer_start etc.) get skipped and the
                        // link fails with undefined references.
                        if func.attrs.is_used() {
                            referenced.insert(func.name.clone());
                        }
                        self.collect_refs_from_compound(&func.body, &mut referenced);
                    }
                }''',
'used_roots')

# ============ 3. RDTSC / RDTSCP intrinsics ============
sub1('src/ir/intrinsics.rs',
'''    /// __builtin_frame_address(0) - returns current frame pointer
    FrameAddress,''',
'''    /// __builtin_ia32_rdtsc() - 64-bit timestamp counter (EDX:EAX)
    Rdtsc,
    /// __builtin_ia32_rdtscp(&aux) - rdtscp, stores IA32_TSC_AUX (ecx) to aux
    Rdtscp,
    /// __builtin_frame_address(0) - returns current frame pointer
    FrameAddress,''',
'rdtsc_ops')

sub1('src/frontend/sema/builtins.rs',
'''    // X86 SSE intrinsics
    X86Lfence,''',
'''    /// __builtin_ia32_rdtsc() - 64-bit timestamp counter
    X86Rdtsc,
    /// __builtin_ia32_rdtscp(&aux) - rdtscp with aux store
    X86Rdtscp,
    // X86 SSE intrinsics
    X86Lfence,''',
'rdtsc_enum')

sub1('src/frontend/sema/builtins.rs',
'''    m.insert("__builtin_thread_pointer", BuiltinInfo::intrinsic(BuiltinIntrinsic::ThreadPointer));''',
'''    m.insert("__builtin_thread_pointer", BuiltinInfo::intrinsic(BuiltinIntrinsic::ThreadPointer));
    m.insert("__builtin_ia32_rdtsc", BuiltinInfo::intrinsic(BuiltinIntrinsic::X86Rdtsc));
    m.insert("__builtin_ia32_rdtscp", BuiltinInfo::intrinsic(BuiltinIntrinsic::X86Rdtscp));''',
'rdtsc_map')

sub1('src/ir/lowering/expr_builtins.rs',
'''            BuiltinIntrinsic::X86Lfence | BuiltinIntrinsic::X86Mfence
            | BuiltinIntrinsic::X86Sfence | BuiltinIntrinsic::X86Pause
            | BuiltinIntrinsic::X86Clflush''',
'''            BuiltinIntrinsic::X86Lfence | BuiltinIntrinsic::X86Mfence
            | BuiltinIntrinsic::X86Sfence | BuiltinIntrinsic::X86Pause
            | BuiltinIntrinsic::X86Rdtsc | BuiltinIntrinsic::X86Rdtscp
            | BuiltinIntrinsic::X86Clflush''',
'rdtsc_dispatch')

sub1('src/ir/lowering/expr_builtins.rs',
'''        | BuiltinIntrinsic::X86Pextrq128 | BuiltinIntrinsic::X86Pmovmskb256 => X86IntrinsicKind::Scalar,''',
'''        | BuiltinIntrinsic::X86Pextrq128 | BuiltinIntrinsic::X86Pmovmskb256
        | BuiltinIntrinsic::X86Rdtsc | BuiltinIntrinsic::X86Rdtscp => X86IntrinsicKind::Scalar,''',
'rdtsc_kind')

sub1('src/ir/lowering/expr_builtins.rs',
'''        BuiltinIntrinsic::X86Lfence => IntrinsicOp::Lfence,''',
'''        BuiltinIntrinsic::X86Rdtsc => IntrinsicOp::Rdtsc,
        BuiltinIntrinsic::X86Rdtscp => IntrinsicOp::Rdtscp,
        BuiltinIntrinsic::X86Lfence => IntrinsicOp::Lfence,''',
'rdtsc_opmap')

sub1('src/backend/x86/codegen/intrinsics.rs',
'''            IntrinsicOp::Pause => { self.state.emit("    pause"); }''',
'''            IntrinsicOp::Pause => { self.state.emit("    pause"); }
            IntrinsicOp::Rdtsc => {
                // rdtsc: EDX:EAX -> RAX (matches GCC __builtin_ia32_rdtsc)
                self.state.emit("    rdtsc");
                self.state.emit("    shlq $32, %rdx");
                self.state.emit("    orq %rdx, %rax");
                if let Some(d) = dest {
                    self.store_rax_to(d);
                }
            }
            IntrinsicOp::Rdtscp => {
                // rdtscp: EDX:EAX -> RAX, IA32_TSC_AUX (ecx) -> *args[0]
                self.state.emit("    rdtscp");
                self.operand_to_reg(&args[0], "rdi");
                self.state.emit("    movl %ecx, (%rdi)");
                self.state.emit("    shlq $32, %rdx");
                self.state.emit("    orq %rdx, %rax");
                if let Some(d) = dest {
                    self.store_rax_to(d);
                }
            }''',
'rdtsc_emit')

# ============ 3b. imports for the still_called fix (passes/mod.rs) ============
sub1('src/passes/mod.rs',
'''use crate::ir::reexports::{IrFunction, IrModule};''',
'''use crate::common::fx_hash::FxHashSet;
use crate::ir::reexports::{Instruction, IrFunction, IrModule};''',
'imports')

# ============ 4. gnu_inline -> declaration only when no calls remain ============
sub1('src/passes/mod.rs',
'''    // After inlining, convert extern inline gnu_inline functions to declarations.
    // These function bodies were only needed for inlining; they must not be emitted
    // as standalone definitions because their internal calls (e.g., `call btowc`)
    // would resolve to the local definition instead of the external library symbol,
    // causing infinite recursion. Converting to declarations ensures any remaining
    // (non-inlined) calls resolve to the external symbol at link time.
    for func in &mut module.functions {
        if func.is_gnu_inline_def && !func.is_declaration {
            func.is_declaration = true;
            func.blocks.clear();
        }
    }''',
'''    // After inlining, convert extern inline gnu_inline functions to declarations —
    // but ONLY when no calls remain. The bodies were only needed for inlining;
    // they must not be emitted as standalone definitions when fully inlined away,
    // because their internal calls (e.g., `call btowc`) would resolve to the local
    // definition instead of the external library symbol, causing infinite recursion.
    // However, if any call site was NOT inlined (e.g. the caller was skipped by the
    // inliner), the function MUST still be emitted as a local (static) definition —
    // GNU89 `extern inline` semantics provide an inline definition usable locally.
    // Dropping it here made glibc's rtld link fail with undefined references to
    // `free`, `__bsearch` etc.
    let mut still_called: FxHashSet<String> = FxHashSet::default();
    for func in &module.functions {
        for block in &func.blocks {
            for inst in &block.instructions {
                if let Instruction::Call { func: callee, .. } = inst {
                    still_called.insert(callee.clone());
                }
            }
        }
    }
    for func in &mut module.functions {
        if func.is_gnu_inline_def && !func.is_declaration && !still_called.contains(&func.name) {
            func.is_declaration = true;
            func.blocks.clear();
        }
    }''',
'still_called')

# ============ 5. global __asm__("label") redirect in expr.rs load path ============
sub1('src/ir/lowering/expr.rs',
'''        if let Some(ginfo) = self.globals.get(name).cloned() {
            // Global register variable: read the register directly via inline asm
            if let Some(ref reg_name) = ginfo.asm_register {
                return self.read_global_register(reg_name, ginfo.ty);
            }
            return self.load_global_var(name.to_string(), &ginfo);
        }''',
'''        if let Some(ginfo) = self.globals.get(name).cloned() {
            // Global register variable: read the register directly via inline asm
            if let Some(ref reg_name) = ginfo.asm_register {
                return self.read_global_register(reg_name, ginfo.ty);
            }
            // Apply __asm__("label") redirect (glibc hidden_proto: extern
            // const char x[] __asm__("__GI_x") must reference __GI_x).
            let resolved_name = self.asm_label_map.get(name)
                .cloned()
                .unwrap_or_else(|| name.to_string());
            return self.load_global_var(resolved_name, &ginfo);
        }''',
'expr_gi_redirect')

# ============ 6. lvalue GlobalAddr __asm__("label") redirect ============
sub1('src/ir/lowering/lvalue.rs',
'''                    let addr_space = ginfo.address_space;
                    // Global variable: emit GlobalAddr to get its address
                    let addr = self.fresh_value();
                    self.emit(Instruction::GlobalAddr { dest: addr, name: name.clone() });
                    Some(LValue::Address(addr, addr_space))''',
'''                    let addr_space = ginfo.address_space;
                    // Global variable: emit GlobalAddr to get its address.
                    // Apply __asm__("label") redirect (glibc hidden_proto data:
                    // `extern const char x[] __asm__("__GI_x")` — &x must be
                    // the address of __GI_x).
                    let resolved_name = self.asm_label_map.get(name)
                        .cloned()
                        .unwrap_or_else(|| name.clone());
                    let addr = self.fresh_value();
                    self.emit(Instruction::GlobalAddr { dest: addr, name: resolved_name });
                    Some(LValue::Address(addr, addr_space))''',
'lvalue_gi_redirect')

# ============ 7. emit_aliases self-alias skip ============
sub1('src/backend/generation.rs',
'''        let alias_resolved = module.asm_labels.get(alias_name).unwrap_or(alias_name);
        let target_resolved = module.asm_labels.get(target_name).unwrap_or(target_name);
        cg.state().emit("");''',
'''        let alias_resolved = module.asm_labels.get(alias_name).unwrap_or(alias_name);
        let target_resolved = module.asm_labels.get(target_name).unwrap_or(target_name);
        // Self-alias (glibc hidden_data_def: the C definition was renamed by an
        // earlier `__asm__("__GI_x")` declaration, so `__GI_x alias("x")`
        // resolves to the SAME symbol). Emitting `.set x, x` would create a
        // duplicate definition and break the libc_pic.os partial link with
        // "multiple definition" errors. GCC folds this case silently.
        if alias_resolved == target_resolved {
            continue;
        }
        cg.state().emit("");''',
'self_alias_skip')

print("ALL ROUND-4 FIXES APPLIED")
