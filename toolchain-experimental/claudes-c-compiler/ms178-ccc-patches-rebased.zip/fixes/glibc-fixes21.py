#!/usr/bin/env python3
"""glibc-fixes21.py — v6.3 fixes #36-#41 (late glibc libm/libc blockers,
all byte-verified against GNU as 2.47 / GCC 14).

#36 ABSOLUTE symbols: `.set sym, <int>` (glibc localeinfo.h
    `_NL_CURRENT_DEFINE` -> `.set _nl_current_LC_CTYPE_used, 2`) must produce
    an SHN_ABS symbol, else the static libc link fails with undefined
    references from setlocale.o. (elf/linker_symbols.rs section_index,
    elf/symbol_table.rs numeric-alias branch.)

#37 `sym@VER@GOTPCREL` parsing: versioned references lowered by fix #35 must
    split at the LAST '@' (the relocation modifier), keeping `sym@VER` as the
    symbol name; a bare `sym@VER` (unknown suffix) stays a plain symbol.
    (x86 assembler parser: is_known_reloc_modifier + split_sym_modifier.)

#38 x87 memory compares: fcoms/fcoml/fcomps/fcompl (D8/DC, /2 and /3).
    glibc e_log10l.S uses `fcompl MO(limit)`.

#39 ffreep %st(i) (DF C0+i) — glibc e_powl.S drops x87 stack entries.

#40 fcomi/fucomi (DB F0+i / DB E8+i) — glibc e_powl.S.

#41 LDCopysign generic path + emit_ld10_to_rsp: copysignl with non-slot
    operands (constants / register-held) used to panic in k_casinhl.o.
    New code materializes both operands in a 32-byte scratch buffer at
    (%rsp), combines byte 9, copies to dest (slot or %xmm0).
"""
import sys

SRC = '/home/user/ccc-work/sources/ccc-src/'

def sub1(path, old, new, tag):
    p = SRC + path
    s = open(p).read()
    if new in s:
        print(f"skip (already applied): {tag}")
        return
    n = s.count(old)
    if n != 1:
        print(f"FAIL {tag}: {path}: found {n} of {old[:70]!r}")
        sys.exit(1)
    open(p, 'w').write(s.replace(old, new))
    print(f"ok {tag}: {path}")

# ================= #36a ABS symbols in section_index =================
sub1('src/backend/elf/linker_symbols.rs',
'''    if section_name == "*COM*" {
        SHN_COMMON
    } else if section_name == "*UND*" || section_name.is_empty() {
        SHN_UNDEF
    } else {''',
'''    if section_name == "*COM*" {
        SHN_COMMON
    } else if section_name == "*ABS*" {
        SHN_ABS
    } else if section_name == "*UND*" || section_name.is_empty() {
        SHN_UNDEF
    } else {''',
'abs_section_index')

# ================= #36b numeric .set -> ABS symbol =================
sub1('src/backend/elf/symbol_table.rs',
'''        } else if let Some((section, offset)) = input.labels.get(resolved) {
            symbols.push(ObjSymbol {
                name: alias.clone(),
                value: *offset,
                size: 0,
                binding: alias_binding.unwrap_or(STB_LOCAL),
                sym_type: alias_type.unwrap_or(STT_NOTYPE),
                visibility: alias_vis.unwrap_or(STV_DEFAULT),
                section_name: section.clone(),
            });
        }''',
'''        } else if let Some((section, offset)) = input.labels.get(resolved) {
            symbols.push(ObjSymbol {
                name: alias.clone(),
                value: *offset,
                size: 0,
                binding: alias_binding.unwrap_or(STB_LOCAL),
                sym_type: alias_type.unwrap_or(STT_NOTYPE),
                visibility: alias_vis.unwrap_or(STV_DEFAULT),
                section_name: section.clone(),
            });
        } else if let Ok(abs_val) = resolved.parse::<i64>() {
            // `.set sym, <integer>` defines an ABSOLUTE symbol (GNU as
            // semantics). glibc localeinfo.h `_NL_CURRENT_DEFINE` emits
            // `.set _nl_current_LC_CTYPE_used, 2` in inline asm; without the
            // absolute symbol the static libc link fails with undefined
            // references from setlocale.o.
            symbols.push(ObjSymbol {
                name: alias.clone(),
                value: abs_val as u64,
                size: 0,
                binding: alias_binding.unwrap_or(STB_GLOBAL),
                sym_type: alias_type.unwrap_or(STT_NOTYPE),
                visibility: alias_vis.unwrap_or(STV_DEFAULT),
                section_name: "*ABS*".to_string(),
            });
        }''',
'abs_numeric_set')

# ================= #37 split_sym_modifier =================
sub1('src/backend/x86/assembler/parser.rs',
'''/// Try to parse a symbol difference expression in an immediate value.''',
'''/// Known relocation modifiers (GNU as). `sym@VER@GOTPCREL` must split at the
/// LAST '@' (the modifier), keeping `sym@VER` as the versioned symbol name;
/// a bare `sym@VER` (suffix not in this list) stays a plain symbol.
fn is_known_reloc_modifier(m: &str) -> bool {
    matches!(m.to_ascii_uppercase().as_str(),
        "GOT" | "GOTPCREL" | "GOTPCRELX" | "GOTOFF" | "GOTTPOFF" | "GOTNTPOFF"
        | "PLT" | "TPOFF" | "TPREL" | "NTPOFF" | "INDNTPOFF" | "TLSGD"
        | "TLSLD" | "DTPMOD" | "DTPOFF" | "TLSDESC" | "PLTOFF"
        | "SECREL" | "SIZE" | "CALL" | "PAGEOFF" | "PAGE" | "GOTPLT")
}

/// Split `sym@mod` at the LAST '@' when the suffix is a known relocation
/// modifier; otherwise return the whole string as a plain symbol.
fn split_sym_modifier(s: &str) -> Option<(String, String)> {
    let mut last = None;
    for (i, c) in s.char_indices() {
        if c == '@' {
            last = Some(i);
        }
    }
    let i = last?;
    let modifier = &s[i + 1..];
    if modifier.is_empty() || !is_known_reloc_modifier(modifier) {
        return None;
    }
    Some((s[..i].to_string(), modifier.to_string()))
}

/// Try to parse a symbol difference expression in an immediate value.''',
'split_sym_modifier_helpers')

sub1('src/backend/x86/assembler/parser.rs',
'''    // Symbol with modifier: symbol@GOTPCREL, etc.
    if let Some(at_pos) = s.find('@') {
        let sym = s[..at_pos].to_string();
        let modifier = s[at_pos + 1..].to_string();
        return Ok(Operand::Immediate(ImmediateValue::SymbolMod(sym, modifier)));
    }

    // Check for symbol difference: SYM-LABEL (e.g., $_DYNAMIC-1b, $4f-1b)''',
'''    // Symbol with modifier: symbol@GOTPCREL, sym@VER@GOTPCREL, etc.
    if let Some((sym, modifier)) = split_sym_modifier(s) {
        return Ok(Operand::Immediate(ImmediateValue::SymbolMod(sym, modifier)));
    }

    // Check for symbol difference: SYM-LABEL (e.g., $_DYNAMIC-1b, $4f-1b)''',
'split_sym_modifier_imm')

sub1('src/backend/x86/assembler/parser.rs',
'''    // Symbol with modifier: symbol@GOTPCREL, symbol@TPOFF, etc.
    if let Some(at_pos) = s.find('@') {
        let sym = s[..at_pos].to_string();
        let modifier = s[at_pos + 1..].to_string();
        return Ok(Displacement::SymbolMod(sym, modifier));
    }''',
'''    // Symbol with modifier: symbol@GOTPCREL, sym@VER@GOTPCREL, etc.
    if let Some((sym, modifier)) = split_sym_modifier(s) {
        return Ok(Displacement::SymbolMod(sym, modifier));
    }''',
'split_sym_modifier_disp')

# ================= #38 x87 memory compares =================
sub1('src/backend/x86/assembler/encoder/x87_misc.rs',
'''    /// Encode fcomp (compare real and pop).  Operand handling mirrors fcom.
    pub(crate) fn encode_fcomp(&mut self, ops: &[Operand]) -> Result<(), String> {
        if ops.is_empty() {
            self.bytes.extend_from_slice(&[0xD8, 0xD9]);
            return Ok(());
        }
        if ops.len() == 1 || ops.len() == 2 {
            match &ops[0] {
                Operand::Register(reg) => {
                    let n = parse_st_num(&reg.name)?;
                    self.bytes.extend_from_slice(&[0xD8, 0xD8 + n]);
                    Ok(())
                }
                _ => Err("fcomp requires st register".to_string()),
            }
        } else {
            Err("fcomp requires 0, 1 or 2 operands".to_string())
        }''',
'''    /// Encode fcomp (compare real and pop).  Operand handling mirrors fcom.
    pub(crate) fn encode_fcomp(&mut self, ops: &[Operand]) -> Result<(), String> {
        if ops.is_empty() {
            self.bytes.extend_from_slice(&[0xD8, 0xD9]);
            return Ok(());
        }
        if ops.len() == 1 || ops.len() == 2 {
            match &ops[0] {
                Operand::Register(reg) => {
                    let n = parse_st_num(&reg.name)?;
                    self.bytes.extend_from_slice(&[0xD8, 0xD8 + n]);
                    Ok(())
                }
                Operand::Memory(mem) => {
                    // fcomp m32: D8 /3 (default for a bare memory operand).
                    self.emit_segment_prefix(mem)?;
                    self.emit_rex_rm(0, "", mem);
                    self.bytes.extend_from_slice(&[0xD8]);
                    self.encode_modrm_mem(3, mem)
                }
                _ => Err("fcomp requires st register or memory operand".to_string()),
            }
        } else {
            Err("fcomp requires 0, 1 or 2 operands".to_string())
        }''',
'fcomp_mem')

sub1('src/backend/x86/assembler/encoder/x87_misc.rs',
'''        if ops.len() == 1 || ops.len() == 2 {
            match &ops[0] {
                Operand::Register(reg) => {
                    let n = parse_st_num(&reg.name)?;
                    self.bytes.extend_from_slice(&[0xD8, 0xD0 + n]);
                    Ok(())
                }
                _ => Err("fcom requires st register".to_string()),
            }
        } else {
            Err("fcom requires 0, 1 or 2 operands".to_string())
        }
    }''',
'''        if ops.len() == 1 || ops.len() == 2 {
            match &ops[0] {
                Operand::Register(reg) => {
                    let n = parse_st_num(&reg.name)?;
                    self.bytes.extend_from_slice(&[0xD8, 0xD0 + n]);
                    Ok(())
                }
                Operand::Memory(mem) => {
                    // fcom m32: D8 /2 (default for a bare memory operand).
                    self.emit_segment_prefix(mem)?;
                    self.emit_rex_rm(0, "", mem);
                    self.bytes.extend_from_slice(&[0xD8]);
                    self.encode_modrm_mem(2, mem)
                }
                _ => Err("fcom requires st register or memory operand".to_string()),
            }
        } else {
            Err("fcom requires 0, 1 or 2 operands".to_string())
        }
    }

    /// Encode a sized x87 memory compare: fcoms/fcoml (opcode D8/DC, /2) and
    /// fcomps/fcompl (D8/DC, /3). AT&T suffixes: s=m32, l=m64.
    pub(crate) fn encode_fcom_mem(&mut self, ops: &[Operand], opcode: u8, ext: u8) -> Result<(), String> {
        if ops.len() != 1 {
            return Err("sized fcom requires 1 memory operand".to_string());
        }
        match &ops[0] {
            Operand::Memory(mem) => {
                self.emit_segment_prefix(mem)?;
                self.emit_rex_rm(0, "", mem);
                self.bytes.push(opcode);
                self.encode_modrm_mem(ext, mem)
            }
            _ => Err("sized fcom requires memory operand".to_string()),
        }
    }''',
'fcom_mem')

sub1('src/backend/x86/assembler/encoder/mod.rs',
'''            "fcom" => self.encode_fcom(ops),
            "fcomp" => self.encode_fcomp(ops),''',
'''            "fcom" => self.encode_fcom(ops),
            "fcoms" => self.encode_fcom_mem(ops, 0xD8, 2),
            "fcoml" => self.encode_fcom_mem(ops, 0xDC, 2),
            "fcomp" => self.encode_fcomp(ops),
            "fcomps" => self.encode_fcom_mem(ops, 0xD8, 3),
            "fcompl" => self.encode_fcom_mem(ops, 0xDC, 3),''',
'fcom_mem_dispatch')

# ================= #39 ffreep =================
sub1('src/backend/x86/assembler/encoder/mod.rs',
'''            "fcompp" => { self.bytes.extend_from_slice(&[0xDE, 0xD9]); Ok(()) }''',
'''            "fcompp" => { self.bytes.extend_from_slice(&[0xDE, 0xD9]); Ok(()) }
            // ffreep %st(i): undocumented AMD/Intel encoding DF /0 (pop without
            // compare; glibc e_powl.S uses it to drop x87 stack entries).
            "ffreep" => {
                let n = match ops.first() {
                    Some(Operand::Register(reg)) => parse_st_num(&reg.name)?,
                    _ => 0,
                };
                self.bytes.extend_from_slice(&[0xDF, 0xC0 + n]);
                Ok(())
            }''',
'ffreep')

# ================= #40 fcomi/fucomi =================
sub1('src/backend/x86/assembler/encoder/x87_misc.rs',
'''    pub(crate) fn encode_fucomip(&mut self, ops: &[Operand]) -> Result<(), String> {''',
'''    /// Encode fcomi/fucomi (compare, no pop): fcomi = DB F0+i, fucomi = DB E8+i.
    pub(crate) fn encode_fcomi(&mut self, ops: &[Operand], base: u8) -> Result<(), String> {
        if ops.len() == 2 {
            match &ops[0] {
                Operand::Register(reg) => {
                    let n = parse_st_num(&reg.name)?;
                    self.bytes.extend_from_slice(&[0xDB, base + n]);
                    Ok(())
                }
                _ => Err("fcomi requires st register".to_string()),
            }
        } else if ops.is_empty() {
            self.bytes.extend_from_slice(&[0xDB, base + 1]);
            Ok(())
        } else {
            Err("fcomi requires 0 or 2 operands".to_string())
        }
    }

    pub(crate) fn encode_fucomip(&mut self, ops: &[Operand]) -> Result<(), String> {''',
'fcomi_encoder')

sub1('src/backend/x86/assembler/encoder/mod.rs',
'''            "fcomip" => self.encode_fcomip(ops),
            "fucomip" => self.encode_fucomip(ops),''',
'''            "fcomi" => self.encode_fcomi(ops, 0xF0),
            "fcomip" => self.encode_fcomip(ops),
            "fucomi" => self.encode_fcomi(ops, 0xE8),
            "fucomip" => self.encode_fucomip(ops),''',
'fcomi_dispatch')

# ================= #41 LDCopysign generic path =================
sub1('src/backend/x86/codegen/intrinsics.rs',
'''                    if let (Some(sx), Some(sy), Some(sd)) = (sx, sy, sd) {
                        self.state.out.emit_instr_rbp_reg("    movq", sx, "rax");
                        self.state.out.emit_instr_reg_rbp("    movq", "rax", sd);
                        self.state.out.emit_instr_rbp_reg("    movzbl", sx + 8, "ecx");
                        self.state.out.emit_instr_reg_rbp("    movb", "cl", sd + 8);
                        self.state.out.emit_instr_rbp_reg("    movzbl", sy + 9, "eax");
                        self.state.emit("    andb $0x80, %al");
                        self.state.out.emit_instr_rbp_reg("    movzbl", sx + 9, "ecx");
                        self.state.emit("    andb $0x7f, %cl");
                        self.state.emit("    orb %cl, %al");
                        self.state.out.emit_instr_reg_rbp("    movb", "al", sd + 9);
                        return;
                    }
                    panic!("LDCopysign: unsupported operand shape");''',
'''                    if let (Some(sx), Some(sy), Some(sd)) = (sx, sy, sd) {
                        self.state.out.emit_instr_rbp_reg("    movq", sx, "rax");
                        self.state.out.emit_instr_reg_rbp("    movq", "rax", sd);
                        self.state.out.emit_instr_rbp_reg("    movzbl", sx + 8, "ecx");
                        self.state.out.emit_instr_reg_rbp("    movb", "cl", sd + 8);
                        self.state.out.emit_instr_rbp_reg("    movzbl", sy + 9, "eax");
                        self.state.emit("    andb $0x80, %al");
                        self.state.out.emit_instr_rbp_reg("    movzbl", sx + 9, "ecx");
                        self.state.emit("    andb $0x7f, %cl");
                        self.state.emit("    orb %cl, %al");
                        self.state.out.emit_instr_reg_rbp("    movb", "al", sd + 9);
                        return;
                    }
                    // Generic path: materialize both operands in a 32-byte
                    // scratch buffer at (%rsp), combine, copy to dest
                    // (glibc k_casinhl: copysignl(x, const)).
                    self.state.emit("    subq $32, %rsp");
                    self.emit_ld10_to_rsp(&args[0], 0);
                    self.emit_ld10_to_rsp(&args[1], 16);
                    self.state.emit("    movzbl 25(%rsp), %eax");
                    self.state.emit("    andb $0x80, %al");
                    self.state.emit("    movzbl 9(%rsp), %ecx");
                    self.state.emit("    andb $0x7f, %cl");
                    self.state.emit("    orb %cl, %al");
                    self.state.emit("    movb %al, 9(%rsp)");
                    if let Some(sd) = sd {
                        self.state.emit("    movq (%rsp), %rax");
                        self.state.out.emit_instr_reg_rbp("    movq", "rax", sd);
                        self.state.emit("    movzbl 8(%rsp), %ecx");
                        self.state.out.emit_instr_reg_rbp("    movb", "cl", sd + 8);
                        self.state.emit("    movzbl 9(%rsp), %ecx");
                        self.state.out.emit_instr_reg_rbp("    movb", "cl", sd + 9);
                    } else {
                        // dest without slot: 16-byte copy through %xmm0
                        self.state.emit("    movdqu (%rsp), %xmm0");
                        self.emit_store_f128_xmm0(d);
                    }
                    self.state.emit("    addq $32, %rsp");
                    return;''',
'ldcopysign_generic')

sub1('src/backend/x86/codegen/intrinsics.rs',
'''    /// AVX2 256-bit unary op with immediate, 3-operand form: `inst $imm, %ymm1, %ymm0`.''',
'''    /// Store a long-double (10-byte) operand into (%rsp)+off. Handles stack
    /// slots and _Float128/long-double constants; values without a slot are
    /// copied via %xmm0 (16 bytes, pad bytes harmless).
    fn emit_ld10_to_rsp(&mut self, op: &Operand, off: i64) {
        match op {
            Operand::Value(v) => {
                if let Some(slot) = self.state.get_slot(v.0) {
                    self.state.out.emit_instr_rbp_reg("    movq", slot.0, "rax");
                    self.state.emit_fmt(format_args!("    movq %rax, {}(%rsp)", off));
                    self.state.out.emit_instr_rbp_reg("    movzbl", slot.0 + 8, "ecx");
                    self.state.emit_fmt(format_args!("    movb %cl, {}(%rsp)", off + 8));
                    self.state.out.emit_instr_rbp_reg("    movzbl", slot.0 + 9, "ecx");
                    self.state.emit_fmt(format_args!("    movb %cl, {}(%rsp)", off + 9));
                } else {
                    // Register-held value: 16-byte copy through %xmm0.
                    self.emit_store_f128_xmm0_dest_to_rsp(v, off);
                }
            }
            Operand::Const(IrConst::LongDouble(_, bytes)) => {
                let low = u64::from_le_bytes(bytes[0..8].try_into().unwrap());
                let high = u64::from_le_bytes(bytes[8..16].try_into().unwrap());
                self.state.emit_fmt(format_args!("    movabsq ${}, %rax", low as i64));
                self.state.emit_fmt(format_args!("    movq %rax, {}(%rsp)", off));
                self.state.emit_fmt(format_args!("    movabsq ${}, %rax", high as i64));
                self.state.emit_fmt(format_args!("    movq %rax, {}(%rsp)", off + 8));
            }
            _ => {
                // Should not happen (frontend only produces these two shapes).
                self.state.emit("    ud2");
            }
        }
    }

    /// Copy a register-held 16-byte value to (%rsp)+off via %xmm0.
    fn emit_store_f128_xmm0_dest_to_rsp(&mut self, v: &Value, off: i64) {
        if let Some(&held) = self.state.vec_live_regs.get(&v.0) {
            self.state.emit_fmt(format_args!("    movdqa %{}, %xmm0", held));
        } else if let Some(&reg) = self.reg_assignments.get(&v.0) {
            if is_xmm_reg(reg) {
                self.state.emit_fmt(format_args!("    movdqa %{}, %xmm0", phys_reg_name(reg)));
            } else {
                self.state.emit_fmt(format_args!("    movq %{}, %xmm0", phys_reg_name(reg)));
            }
        } else {
            self.operand_to_reg(&Operand::Value(*v), "rax");
            self.state.emit("    movdqu (%rax), %xmm0");
        }
        self.state.emit_fmt(format_args!("    movdqu %xmm0, {}(%rsp)", off));
    }

    /// AVX2 256-bit unary op with immediate, 3-operand form: `inst $imm, %ymm1, %ymm0`.''',
'ld10_to_rsp_helpers')

print("ROUND-21 FIXES 36-41 APPLIED")
