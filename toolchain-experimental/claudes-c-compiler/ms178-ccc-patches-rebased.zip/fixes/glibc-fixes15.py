#!/usr/bin/env python3
"""glibc-fixes15.py — v6.3 fix #22: VEX-prefixed MXCSR instructions
(vldmxcsr/vstmxcsr). glibc math fclrexcpt.c uses vstmxcsr; the encoder only
had the legacy SSE forms. Verified byte-identical to GNU as 2.47:
  vstmxcsr 0x8(%rsp) -> c5 f8 ae 5c 24 08
  vldmxcsr (%rax)    -> c5 f8 ae 10
VEX.128.0F implies map 0F -> only the final opcode byte is emitted.
"""
import sys

SRC = '/home/user/ccc-work/sources/ccc-src/'

def sub1(path, old, new, tag):
    p = SRC + path
    s = open(p).read()
    if new in s:
        print(f"skip (already applied): {tag}")
        return
    n = s.count(old)
    if n != 1:
        print(f"FAIL {tag}: {path}: found {n}")
        sys.exit(1)
    open(p, 'w').write(s.replace(old, new))
    print(f"ok {tag}")

sub1('src/backend/x86/assembler/encoder/mod.rs',
'''            "ldmxcsr" => self.encode_sse_mem_only(ops, &[0x0F, 0xAE], 2),
            "stmxcsr" => self.encode_sse_mem_only(ops, &[0x0F, 0xAE], 3),''',
'''            "ldmxcsr" => self.encode_sse_mem_only(ops, &[0x0F, 0xAE], 2),
            "stmxcsr" => self.encode_sse_mem_only(ops, &[0x0F, 0xAE], 3),
            // VEX.128.0F.WIG 0F AE /2 /3 (AVX forms; glibc math uses vstmxcsr)
            "vldmxcsr" => self.encode_vex_mem_only(ops, &[0x0F, 0xAE], 2),
            "vstmxcsr" => self.encode_vex_mem_only(ops, &[0x0F, 0xAE], 3),''',
'dispatch')

sub1('src/backend/x86/assembler/encoder/sse.rs',
'''    // ---- BSF/BSR encoding ----''',
'''    /// Encode a VEX-prefixed memory-only instruction (vldmxcsr/vstmxcsr):
    /// VEX.128.0F.WIG 0F AE /r. Map 0F is implicit in VEX.
    pub(crate) fn encode_vex_mem_only(&mut self, ops: &[Operand], opcode: &[u8], ext: u8) -> Result<(), String> {
        if ops.len() != 1 {
            return Err("VEX mem-only op requires 1 operand".to_string());
        }
        match &ops[0] {
            Operand::Memory(mem) => {
                self.emit_segment_prefix(mem)?;
                let x_bit = mem.index.as_ref().is_some_and(|i| needs_rex_ext(&i.name));
                let b_bit = mem.base.as_ref().is_some_and(|b| needs_rex_ext(&b.name));
                self.emit_vex(false, x_bit, b_bit, 1, 0, 0, 0, 0);
                // VEX.128.0F implies map 0F: emit only the final opcode byte.
                self.bytes.push(opcode[opcode.len() - 1]);
                self.encode_modrm_mem(ext, mem)
            }
            _ => Err("VEX mem-only op requires memory operand".to_string()),
        }
    }

    // ---- BSF/BSR encoding ----''',
'encoder')

print("ROUND-15 VEX MEM-ONLY APPLIED")

# ---- fix #23: %v / %x GNU-as encoding hints on mnemonics ----
sub1('src/backend/x86/assembler/parser.rs',
'''    let trimmed = if let Some(rest) = trimmed.strip_prefix("{vex} ")
        .or_else(|| trimmed.strip_prefix("{vex3} "))
        .or_else(|| trimmed.strip_prefix("{vex2} "))
        .or_else(|| trimmed.strip_prefix("{evex} "))
    {
        rest
    } else {
        trimmed
    };''',
'''    let trimmed = if let Some(rest) = trimmed.strip_prefix("{vex} ")
        .or_else(|| trimmed.strip_prefix("{vex3} "))
        .or_else(|| trimmed.strip_prefix("{vex2} "))
        .or_else(|| trimmed.strip_prefix("{evex} "))
    {
        rest
    } else {
        trimmed
    };
    let trimmed = if (trimmed.starts_with("%v") || trimmed.starts_with("%x"))
        && trimmed.len() > 2
        && trimmed.as_bytes()[2].is_ascii_alphabetic()
    {
        // Keep the v: "%vstmxcsr" -> "vstmxcsr" (GNU as selects the VEX
        // encoding for the %v hint; LCCC's v* encoders match).
        &trimmed[1..]
    } else {
        trimmed
    };''',
'percent_v_hint')
