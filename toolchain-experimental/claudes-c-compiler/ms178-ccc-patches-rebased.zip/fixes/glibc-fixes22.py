#!/usr/bin/env python3
"""glibc-fixes22.py — v6.3 fixes #42-#44 (inline-asm + _Float128 constants).

#42 XMM inline-asm inputs: constant propagation can turn "x"-constrained
    inputs into Const(F32/F64) (glibc divss_inline_asm(1.0f, 0.0f)); the
    codegen zeroed the register (xorpd) instead of materializing the bits.

#43 F128Fabs/F128Copysign: constant operands (inlined literals) crashed via
    sse_load_arg's pointer path; materialize 16-byte constants through a
    stack scratch; load slot operands deterministically. Sign bit 127 lives
    in the HIGH qword: use btrq/shrq/shlq (no 64-bit mask load the peephole
    can drop).

#44 __builtin_huge_valf128/inff128/nanf128: ConstantF128 is now lowered to
    IrConst::I128 carrying the 16-byte binary128 bit pattern (the F128-const
    materializers in calls.rs/returns.rs speak I128), and memory.rs stores
    I128 constants into F128 slots via emit_f128_store_raw_bytes.
"""
import sys

SRC = '/home/user/ccc-work/sources/ccc-src/'

def sub1(path, old, new, tag):
    p = SRC + path
    s = open(p).read()
    if new in s:
        print(f"skip (already applied): {tag}")
        return
    n = s.count(old)
    if n != 1:
        print(f"FAIL {tag}: {path}: found {n} of {old[:70]!r}")
        sys.exit(1)
    open(p, 'w').write(s.replace(old, new))
    print(f"ok {tag}: {path}")

# ================= #42 XMM const inputs =================
sub1('src/backend/x86/codegen/asm_emitter.rs',
'''                Operand::Const(_) => {
                    // TODO: non-zero float constants need to be materialized via
                    // memory (e.g., load from .rodata). For now, zero the register.
                    // In practice, inline asm "x" inputs are almost always variables.
                    self.state.out.emit_instr_reg_reg("    xorpd", reg, reg);
                }''',
'''                Operand::Const(c) => {
                    // Materialize float constants bit-exact (constant
                    // propagation can turn inline-asm "x" inputs into
                    // Const(F32/F64) — glibc divss_inline_asm(1.0f, 0.0f)).
                    let bits = match ty {
                        IrType::F32 => {
                            let f = c.to_f64().unwrap_or(0.0) as f32;
                            f.to_bits() as u64
                        }
                        IrType::F64 => {
                            let f = c.to_f64().unwrap_or(0.0);
                            f.to_bits()
                        }
                        _ => 0,
                    };
                    self.state.out.emit_instr_imm_reg("    movabsq", bits as i64, "rax");
                    self.state.emit_fmt(format_args!("    movq %rax, %{}", reg));
                }''',
'xmm_const_inputs')

# ================= #43a F128 const bytes helper =================
sub1('src/backend/x86/codegen/intrinsics.rs',
'''    /// Materialize a 16-byte _Float128 constant into an XMM register via a''',
'''    /// Extract the 16 payload bytes from any _Float128 constant form
    /// (LongDouble carries them explicitly; I128 carries them as bits).
    fn f128_const_bytes(op: &Operand) -> Option<[u8; 16]> {
        match op {
            Operand::Const(IrConst::LongDouble(_, bytes)) => Some(*bytes),
            Operand::Const(IrConst::I128(v)) => {
                Some((*v as u128).to_le_bytes())
            }
            _ => None,
        }
    }

    /// Load a 16-byte _Float128 operand into an XMM register. Deterministic
    /// slot addressing; falls back to a pointer load only for register-held
    /// values (avoids sse_load_arg's assumptions for F128 slots).
    fn emit_f128_operand_to_xmm(&mut self, arg: &Operand, xmm: &str) {
        if let Operand::Value(v) = arg {
            if let Some(slot) = self.state.get_slot(v.0) {
                self.state.out.emit_instr_rbp_reg("    movdqu", slot.0, xmm);
                return;
            }
            if let Some(&held) = self.state.vec_live_regs.get(&v.0) {
                if held != xmm {
                    self.state.emit_fmt(format_args!("    movdqa %{}, %{}", held, xmm));
                }
                return;
            }
        }
        self.operand_to_reg(arg, "rax");
        self.state.emit_fmt(format_args!("    movdqu (%rax), %{}", xmm));
    }

    /// Materialize a 16-byte _Float128 constant into an XMM register via a''',
'f128_const_bytes_helper')

# ================= #43b F128Fabs const/operand path =================
sub1('src/backend/x86/codegen/intrinsics.rs',
'''                if let Operand::Const(IrConst::LongDouble(_, bytes)) = &args[0] {
                    self.emit_f128_const_to_xmm(*bytes, "xmm0");
                } else {
                    self.sse_load_arg(&args[0], "xmm0");
                }
                // Sign bit 127 lives in the HIGH qword: move it down with
                // movhlps, mask, and re-insert via punpcklqdq.
                self.state.emit("    movhlps %xmm0, %xmm1");
                self.state.emit("    movq %xmm1, %rax");
                self.state.emit("    movabsq $0x7FFFFFFFFFFFFFFF, %rcx");
                self.state.emit("    andq %rcx, %rax");
                self.state.emit("    movq %rax, %xmm1");
                self.state.emit("    punpcklqdq %xmm1, %xmm0");''',
'''                if let Some(bytes) = Self::f128_const_bytes(&args[0]) {
                    self.emit_f128_const_to_xmm(bytes, "xmm0");
                } else {
                    self.emit_f128_operand_to_xmm(&args[0], "xmm0");
                }
                // Sign bit 127 lives in the HIGH qword: move it down with
                // movhlps, clear bit 63 with btrq (no 64-bit constant load —
                // the peephole must not eat the mask), re-insert via punpcklqdq.
                self.state.emit("    movhlps %xmm0, %xmm1");
                self.state.emit("    movq %xmm1, %rax");
                self.state.emit("    btrq $63, %rax");
                self.state.emit("    movq %rax, %xmm1");
                self.state.emit("    punpcklqdq %xmm1, %xmm0");''',
'f128fabs_const')

# ================= #43c F128Copysign const/operand path =================
sub1('src/backend/x86/codegen/intrinsics.rs',
'''                if let Operand::Const(IrConst::LongDouble(_, bytes)) = &args[0] {
                    self.emit_f128_const_to_xmm(*bytes, "xmm0");
                } else {
                    self.sse_load_arg(&args[0], "xmm0");
                }
                if let Operand::Const(IrConst::LongDouble(_, bytes)) = &args[1] {
                    self.emit_f128_const_to_xmm(*bytes, "xmm1");
                } else {
                    self.sse_load_arg(&args[1], "xmm1");
                }
                // y's sign bit (bit 127, HIGH qword) and x's magnitude.
                self.state.emit("    movhlps %xmm1, %xmm2");
                self.state.emit("    movq %xmm2, %rdx");
                self.state.emit("    movabsq $0x8000000000000000, %rcx");
                self.state.emit("    andq %rcx, %rdx");
                self.state.emit("    movhlps %xmm0, %xmm2");
                self.state.emit("    movq %xmm2, %rax");
                self.state.emit("    movabsq $0x7FFFFFFFFFFFFFFF, %rcx");
                self.state.emit("    andq %rcx, %rax");
                self.state.emit("    orq %rdx, %rax");
                self.state.emit("    movq %rax, %xmm1");
                self.state.emit("    punpcklqdq %xmm1, %xmm0");''',
'''                if let Some(bytes) = Self::f128_const_bytes(&args[0]) {
                    self.emit_f128_const_to_xmm(bytes, "xmm0");
                } else {
                    self.emit_f128_operand_to_xmm(&args[0], "xmm0");
                }
                if let Some(bytes) = Self::f128_const_bytes(&args[1]) {
                    self.emit_f128_const_to_xmm(bytes, "xmm1");
                } else {
                    self.emit_f128_operand_to_xmm(&args[1], "xmm1");
                }
                // y's sign bit (bit 127, HIGH qword) and x's magnitude —
                // constant-free (btrq/shrq/shlq) so no 64-bit mask load can
                // be dropped by the peephole.
                self.state.emit("    movhlps %xmm1, %xmm2");
                self.state.emit("    movq %xmm2, %rdx");
                self.state.emit("    shrq $63, %rdx");
                self.state.emit("    movhlps %xmm0, %xmm2");
                self.state.emit("    movq %xmm2, %rax");
                self.state.emit("    btrq $63, %rax");
                self.state.emit("    shlq $63, %rdx");
                self.state.emit("    orq %rdx, %rax");
                self.state.emit("    movq %rax, %xmm1");
                self.state.emit("    punpcklqdq %xmm1, %xmm0");''',
'f128copysign_const')

# ================= #44a ConstantF128 lowering -> I128 =================
sub1('src/ir/lowering/expr_builtins.rs',
'''            BuiltinKind::ConstantF128(bytes) => {
                // _Float128 constant: full 16-byte binary128 payload.
                Some(Operand::Const(IrConst::long_double_with_bytes(
                    f64::INFINITY, *bytes,
                )))
            }''',
'''            BuiltinKind::ConstantF128(bytes) => {
                // _Float128 constant: full 16-byte binary128 payload carried
                // as an I128 bit pattern (the F128-const materializers in
                // calls/returns/memory all speak I128).
                let bits = u128::from_be_bytes(*bytes) as i128;
                Some(Operand::Const(IrConst::I128(bits)))
            }''',
'const_f128_i128')

# ================= #44b F128 slot store of I128 const =================
sub1('src/backend/x86/codegen/memory.rs',
'''            if let Operand::Const(IrConst::LongDouble(_, f128_bytes)) = val {
                let x87 = crate::common::long_double::f128_bytes_to_x87_bytes(f128_bytes);
                let lo = u64::from_le_bytes(x87[0..8].try_into().unwrap());
                let hi_bytes: [u8; 8] = [x87[8], x87[9], 0, 0, 0, 0, 0, 0];
                let hi = u64::from_le_bytes(hi_bytes);
                if let Some(addr) = self.state.resolve_slot_addr(ptr.0) {
                    self.emit_f128_store_raw_bytes(&addr, ptr.0, 0, lo, hi);
                }
                return;
            }''',
'''            if let Operand::Const(IrConst::LongDouble(_, f128_bytes)) = val {
                let x87 = crate::common::long_double::f128_bytes_to_x87_bytes(f128_bytes);
                let lo = u64::from_le_bytes(x87[0..8].try_into().unwrap());
                let hi_bytes: [u8; 8] = [x87[8], x87[9], 0, 0, 0, 0, 0, 0];
                let hi = u64::from_le_bytes(hi_bytes);
                if let Some(addr) = self.state.resolve_slot_addr(ptr.0) {
                    self.emit_f128_store_raw_bytes(&addr, ptr.0, 0, lo, hi);
                }
                return;
            }
            if let Operand::Const(IrConst::I128(c)) = val {
                // _Float128 constant as a 16-byte bit pattern (huge_valf128 etc.).
                let bytes = (*c as u128).to_le_bytes();
                let lo = u64::from_le_bytes(bytes[0..8].try_into().unwrap());
                let hi = u64::from_le_bytes(bytes[8..16].try_into().unwrap());
                if let Some(addr) = self.state.resolve_slot_addr(ptr.0) {
                    self.emit_f128_store_raw_bytes(&addr, ptr.0, 0, lo, hi);
                }
                return;
            }''',
'f128_store_i128')

print("ROUND-22 FIXES 42-44 APPLIED")
