#!/usr/bin/env python3
"""glibc-fixes6.py — round-6 deterministic fix layer (libc.so final-link blockers).

 1. structs.rs `get_struct_base_addr`: apply the __asm__("label") redirect for
    struct/union global bases. Without it, `_null_auth.oa_flavor`-style member
    accesses referenced the plain C name while the definition was emitted under
    the asm label — svc.os/svc_auth.os/compat-svc.os ended up with undefined
    plain `_null_auth` (and the hidden_proto declaration made it a HIDDEN UND,
    which cannot bind to the versioned definition `_null_auth@GLIBC_2.2.5`).

 2. symbol_table.rs: `.set` alias symbols get STV_DEFAULT visibility unless an
    explicit .hidden/.protected directive names them (GNU as semantics).
    Copying the target's visibility made `strong_alias (__pointer_chk_guard_local,
    __pointer_chk_guard)` produce a HIDDEN __pointer_chk_guard in librtld.os,
    which the ld.map version script cannot export (GLIBC_PRIVATE), leaving
    libc.so with an undefined __pointer_chk_guard.

 3. generation.rs `emit_symbol_attrs`: resolve the __asm__("label") redirect
    and emit visibility for defined globals too, so definitions land on the
    emitted label (`.hidden __GI__null_auth` in rpc_common.os, `.hidden
    __GI__dl_argv` in rtld.os) while pure-reference TUs emit nothing (GCC
    parity).
"""
import sys

def patch(path, old, new, tag):
    s = open(path).read()
    if tag in s:
        print(f"skip (already applied): {path} [{tag}]")
        return
    assert s.count(old) == 1, f"{path}: pattern not unique/found ({tag})"
    open(path, 'w').write(s.replace(old, new))
    print(f"ok: {path} [{tag}]")

ROOT = '/home/user/ccc-work/sources/ccc-src'

# ---- 1. structs.rs redirect ----
patch(
    f'{ROOT}/src/ir/lowering/structs.rs',
    '''                if self.globals.contains_key(name) {
                    let addr = self.fresh_value();
                    self.emit(Instruction::GlobalAddr { dest: addr, name: name.clone() });
                    return addr;
                }''',
    '''                if self.globals.contains_key(name) {
                    // Apply __asm__("label") redirect (glibc hidden_proto data:
                    // `extern struct opaque_auth _null_auth __asm__("__GI__null_auth")
                    // __attribute__((visibility("hidden")))` — member accesses
                    // like `_null_auth.oa_flavor` must reference __GI__null_auth,
                    // otherwise the object has an unversioned plain reference
                    // that no member defines).
                    let resolved_name = self.asm_label_map.get(name)
                        .cloned()
                        .unwrap_or_else(|| name.clone());
                    let addr = self.fresh_value();
                    self.emit(Instruction::GlobalAddr { dest: addr, name: resolved_name });
                    return addr;
                }''',
    'structs.rs redirect ZZ_6',
)

# ---- 2. symbol_table.rs alias visibility ----
patch(
    f'{ROOT}/src/backend/elf/symbol_table.rs',
    '''            symbols.push(ObjSymbol {
                name: alias.clone(),
                value: target_sym.value,
                size: target_sym.size,
                binding: alias_binding.unwrap_or(target_sym.binding),
                sym_type: alias_type.unwrap_or(target_sym.sym_type),
                visibility: alias_vis.unwrap_or(target_sym.visibility),
                section_name: target_sym.section_name.clone(),
            });''',
    '''            symbols.push(ObjSymbol {
                name: alias.clone(),
                value: target_sym.value,
                size: target_sym.size,
                binding: alias_binding.unwrap_or(target_sym.binding),
                sym_type: alias_type.unwrap_or(target_sym.sym_type),
                // Visibility comes only from an explicit .hidden/.protected
                // directive on the alias itself (GNU as semantics). Copying the
                // target's visibility would make strong_aliases of hidden
                // objects hidden too — e.g. glibc rtld.c's
                // `strong_alias (__pointer_chk_guard_local, __pointer_chk_guard)`
                // would produce a hidden __pointer_chk_guard that the ld.map
                // version script cannot export (GLIBC_PRIVATE), leaving
                // libc.so with an undefined __pointer_chk_guard.
                visibility: alias_vis.unwrap_or(STV_DEFAULT),
                section_name: target_sym.section_name.clone(),
            });''',
    'symbol_table.rs alias visibility ZZ_6',
)

# ---- 3. generation.rs emit_symbol_attrs ----
patch(
    f'{ROOT}/src/backend/generation.rs',
    '''/// Emit .weak/.hidden directives for declaration symbols that are referenced.
fn emit_symbol_attrs(
    cg: &mut dyn ArchCodegen,
    module: &IrModule,
    referenced_symbols: &FxHashSet<String>,
) {
    for (name, is_weak, visibility) in &module.symbol_attrs {
        if !referenced_symbols.contains(name) {
            continue;
        }
        if *is_weak {
            cg.state().emit_fmt(format_args!(".weak {}", name));
        }
        cg.state().emit_visibility(name, visibility);
    }
}''',
    '''/// Emit .weak/.hidden directives for declaration symbols that are referenced
/// or defined.
///
/// The __asm__("label") redirect is applied, so a hidden attribute on the C
/// name lands on the emitted label (glibc hidden_proto: `__GI_x` definitions
/// must be `.hidden`, and pure-reference TUs must NOT emit `.hidden` on the
/// undefined reference — a hidden undefined reference cannot bind to a
/// default-versioned definition at final link).
fn emit_symbol_attrs(
    cg: &mut dyn ArchCodegen,
    module: &IrModule,
    referenced_symbols: &FxHashSet<String>,
) {
    // Globals are emitted under their asm label (if any); the attribute on the
    // C name applies to that label.
    let defined_labels: FxHashSet<&str> =
        module.globals.iter().map(|g| g.name.as_str()).collect();
    for (name, is_weak, visibility) in &module.symbol_attrs {
        let resolved = module
            .asm_labels
            .get(name)
            .map(|s| s.as_str())
            .unwrap_or(name.as_str());
        if !referenced_symbols.contains(name) && !defined_labels.contains(resolved) {
            continue;
        }
        if *is_weak {
            cg.state().emit_fmt(format_args!(".weak {}", resolved));
        }
        cg.state().emit_visibility(resolved, visibility);
    }
}''',
    'generation.rs emit_symbol_attrs ZZ_6',
)

print("ROUND-6 FIXES APPLIED")
