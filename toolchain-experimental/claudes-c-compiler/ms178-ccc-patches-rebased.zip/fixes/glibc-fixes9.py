#!/usr/bin/env python3
"""glibc-fixes9.py — v6.3 fix #14: __asm__("label") redirect in
get_array_base_addr (lvalue.rs). glibc's rtld `_dl_argv[0]` (dl-catch.c,
dl-addr.c) must reference __GI__dl_argv (hidden_proto in elf/ldsodefs.h);
without this the ld.so link fails with
"R_X86_64_PC32 against undefined symbol `_dl_argv'".
Verified: repro emits __GI__dl_argv (DEFAULT UND), matching GCC 14.
"""
import sys

SRC = '/home/user/ccc-work/sources/ccc-src/'

def sub1(path, old, new, tag=''):
    p = SRC + path
    s = open(p).read()
    if new in s:
        print(f"skip (already applied): {tag}: {path}")
        return
    n = s.count(old)
    if n != 1:
        print(f"FAIL {tag}: {path}: found {n} of {old[:70]!r}")
        sys.exit(1)
    open(p, 'w').write(s.replace(old, new))
    print(f"ok {tag}: {path}")

sub1('src/ir/lowering/lvalue.rs',
'''                if let Some(ginfo) = self.globals.get(name).cloned() {
                    let addr = self.fresh_value();
                    self.emit(Instruction::GlobalAddr { dest: addr, name: name.clone() });
                    let is_inline_data = ginfo.is_array || ginfo.c_type.as_ref().is_some_and(|ct| ct.is_vector());
                    if is_inline_data {
                        return Operand::Value(addr);
                    } else {
                        let loaded = self.fresh_value();
                        self.emit(Instruction::Load { dest: loaded, ptr: addr, ty: IrType::Ptr , seg_override: AddressSpace::Default });
                        return Operand::Value(loaded);
                    }
                }''',
'''                if let Some(ginfo) = self.globals.get(name).cloned() {
                    // Apply __asm__("label") redirect (glibc hidden_proto data
                    // arrays/pointers: `_dl_argv[0]` in rtld references
                    // __GI__dl_argv; without this the ld.so link fails with
                    // R_X86_64_PC32 against undefined `_dl_argv`).
                    let resolved_name = self.asm_label_map.get(name)
                        .cloned()
                        .unwrap_or_else(|| name.clone());
                    let addr = self.fresh_value();
                    self.emit(Instruction::GlobalAddr { dest: addr, name: resolved_name });
                    let is_inline_data = ginfo.is_array || ginfo.c_type.as_ref().is_some_and(|ct| ct.is_vector());
                    if is_inline_data {
                        return Operand::Value(addr);
                    } else {
                        let loaded = self.fresh_value();
                        self.emit(Instruction::Load { dest: loaded, ptr: addr, ty: IrType::Ptr , seg_override: AddressSpace::Default });
                        return Operand::Value(loaded);
                    }
                }''',
'array_base_redirect')

print("ROUND-9 ARRAY-BASE REDIRECT APPLIED")
