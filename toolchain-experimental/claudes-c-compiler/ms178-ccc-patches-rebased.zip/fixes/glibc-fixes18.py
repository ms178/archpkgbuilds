#!/usr/bin/env python3
"""glibc-fixes18.py — v6.3 fix #31: x87 fsubr/fdivr register forms + DC-base
correctness fix.

glibc math e_exp2l.S uses `fsubr %st, %st(1)` (and the fdivr twin).

Encodings (verified against GNU as 2.47):
  D8 E0+i fsub  st(i),st      DC E0+i fsub  st,st(i)
  D8 E8+i fsubr st(i),st      DC E8+i fsubr st,st(i)
  D8 F0+i fdiv  st(i),st      DC F0+i fdiv  st,st(i)
  D8 F8+i fdivr st(i),st      DC F8+i fdivr st,st(i)

The old dc_modrm remap table was INVERTED: it encoded `fsub %st, %st(i)` as
DC E8+i (fsubr) and `fdiv` as fdivr. The DC base is the instruction's OWN
base — no swap. Fixed here; `fsubr %st, %st(1)` now emits `dc e9` like GNU as.
"""
import sys

SRC = '/home/user/ccc-work/sources/ccc-src/'

def sub1(path, old, new, tag):
    p = SRC + path
    s = open(p).read()
    if new in s:
        print(f"skip (already applied): {tag}")
        return
    n = s.count(old)
    if n != 1:
        print(f"FAIL {tag}: {path}: found {n} of {old[:70]!r}")
        sys.exit(1)
    open(p, 'w').write(s.replace(old, new))
    print(f"ok {tag}: {path}")

# ---- dispatch: fsubr/fdivr ----
sub1('src/backend/x86/assembler/encoder/mod.rs',
'''            "fsub" => self.encode_x87_arith_reg(ops, 0xD8, 0xDC, 0xE0),
            "fdiv" => self.encode_x87_arith_reg(ops, 0xD8, 0xDC, 0xF0),''',
'''            "fsub" => self.encode_x87_arith_reg(ops, 0xD8, 0xDC, 0xE0),
            "fsubr" => self.encode_x87_arith_reg(ops, 0xD8, 0xDC, 0xE8),
            "fdiv" => self.encode_x87_arith_reg(ops, 0xD8, 0xDC, 0xF0),
            "fdivr" => self.encode_x87_arith_reg(ops, 0xD8, 0xDC, 0xF8),''',
'fsubr_fdivr_dispatch')

# ---- DC-form base correction (no swap) ----
sub1('src/backend/x86/assembler/encoder/avx.rs',
'''                        } else if src_n == 0 {
                            // fadd %st, %st(i) -> DC (base + i)
                            // Note: for fsub/fdiv, the DC form uses reversed base
                            // DC E0+i for fsubr, DC E8+i for fsub (swapped!)
                            // But base_modrm is from the D8 encoding perspective.
                            // The DC form for reverse direction:
                            // fadd: DC C0+i, fmul: DC C8+i, fsub: DC E8+i, fdiv: DC F8+i
                            // (fsub/fdiv swap: D8 E0 = fsub st(i),st; DC E8 = fsub st,st(i))
                            let dc_modrm = match base_modrm {
                                0xC0 => 0xC0, // fadd
                                0xC8 => 0xC8, // fmul
                                0xE0 => 0xE8, // fsub -> fsubr encoding in DC
                                0xF0 => 0xF8, // fdiv -> fdivr encoding in DC
                                0xE8 => 0xE0, // fsubr -> fsub encoding in DC
                                0xF8 => 0xF0, // fdivr -> fdiv encoding in DC
                                _ => base_modrm,
                            };
                            self.bytes.extend_from_slice(&[opcode_sti, dc_modrm + dst_n]);
                        } else {''',
'''                        } else if src_n == 0 {
                            // fadd %st, %st(i) -> DC (base + i). The DC base is
                            // the instruction's OWN base (verified vs GNU as
                            // 2.47): fsub st,st(i) = DC E0+i, fsubr = DC E8+i,
                            // fdiv = DC F0+i, fdivr = DC F8+i. NO swap — the
                            // old remap table encoded fsub st,st(i) as fsubr.
                            self.bytes.extend_from_slice(&[opcode_sti, base_modrm + dst_n]);
                        } else {''',
'fsubr_dc_noswap')

print("ROUND-18 FSUBR/FDIVR + DC-FIX APPLIED")
