#!/usr/bin/env python3
"""glibc-fixes14.py — v6.3 fixes #20/#21: proper GNU symbol versioning.

#20 emit_shared.rs (LCCC's own ELF linker):
  - Split .symver-derived dynsym names ("foo@@V"/"foo@V") into base name +
    version; .dynstr holds BASE names; each version becomes a verdef node
    (index 2..); versym per symbol selects its node; .gnu.hash hashes the
    BASE name. Without this, ld could not bind unversioned references
    (undefined __libc_start_main when linking glibc's build tools against
    the LCCC-built libc.so) because the DSO only carried the compat version
    and no default version node.

#21 elf_writer_common.rs (.symver handler, GNU-as semantics):
  - .symver real, name@@V  -> symbols `real` AND `name@@V` (full version
    string is the alias; verified against binutils 2.47 as).
  - .symver real, name@V   -> symbols `real` AND `name@V`.
  - The previous base-only @@ alias silently vanished for base == name
    (default_symbol_version in glibc -> object had no __libc_start_main@@V).
"""
import sys

SRC = '/home/user/ccc-work/sources/ccc-src/'

def sub1(path, old, new, tag):
    p = SRC + path
    s = open(p).read()
    if new in s:
        print(f"skip (already applied): {tag}")
        return
    n = s.count(old)
    if n != 1:
        print(f"FAIL {tag}: {path}: found {n}")
        sys.exit(1)
    open(p, 'w').write(s.replace(old, new))
    print(f"ok {tag}")

# ---- #21 .symver handler ----
sub1('src/backend/elf_writer_common.rs',
'''            AsmItem::Symver(name, ver_string) => {
                // .symver name, alias@@VERSION  -> default version: the symbol is
                //   renamed to `alias` (symbol table entry `alias`).
                // .symver name, alias@VERSION   -> compat version: the symbol keeps
                //   `name` AND a versioned alias `alias@VERSION` is added, exactly
                //   like GNU as (e.g. glibc's `compat_symbol (libc, _res, _res,
                //   GLIBC_2_0)` -> `.symver _res, _res@GLIBC_2_0`).
                // Truncating at '@' produced a self-alias for `local == symbol`
                // cases and hence duplicate definitions in one object.
                if let Some(at_pos) = ver_string.find('@') {
                    let base = &ver_string[..at_pos];
                    let is_default = ver_string[at_pos..].starts_with("@@");
                    if !base.is_empty() {
                        let alias_name = if is_default {
                            base.to_string()
                        } else {
                            ver_string.clone()
                        };
                        if alias_name.as_str() != name.as_str() {
                            self.aliases.insert(alias_name, name.clone());
                        }
                    }
                }
            }''',
'''            AsmItem::Symver(name, ver_string) => {
                // GNU as semantics (verified against binutils 2.47):
                //   .symver real, name@@V  -> symbols `real` AND `name@@V`
                //   .symver real, name@V   -> symbols `real` AND `name@V`
                // The FULL version string (including @ / @@) is the alias
                // symbol; `name` itself is never renamed. Truncating at '@'
                // produced self-aliases for `local == symbol` cases and
                // duplicate definitions in one object; dropping the @@ alias
                // for base == name broke glibc default_symbol_version
                // (no __libc_start_main@@GLIBC_2.34 in the object).
                if ver_string.contains('@') {
                    if !ver_string.is_empty() {
                        self.aliases.insert(ver_string.clone(), name.clone());
                    }
                }
            }''',
'symver_full_string')

# ---- #20 emit_shared.rs GNU versioning ----
sub1('src/backend/x86/linker/emit_shared.rs',
'''    for name in &dyn_sym_names { dynstr.add(name); }
    let versioned_name = version_script.as_ref().map(|vs| vs.version_name.clone());''',
'''    // Split .symver-derived names ("foo@@GLIBC_2.34", "foo@GLIBC_2.2.5")
    // into (base name, version, is_default). The .dynstr holds base names;
    // versions become verdef nodes. Without this, ld cannot bind unversioned
    // references (e.g. __libc_start_main) against the DSO.
    let mut sym_versions: Vec<(String, Option<String>, bool)> = Vec::new();
    let mut version_set: Vec<String> = Vec::new();
    for name in &dyn_sym_names {
        if let Some(pos) = name.find("@@") {
            let base = name[..pos].to_string();
            let ver = name[pos + 2..].to_string();
            if !version_set.contains(&ver) { version_set.push(ver.clone()); }
            dynstr.add(&base);
            sym_versions.push((base, Some(ver), true));
        } else if let Some(pos) = name.find('@') {
            let base = name[..pos].to_string();
            let ver = name[pos + 1..].to_string();
            if !version_set.contains(&ver) { version_set.push(ver.clone()); }
            dynstr.add(&base);
            sym_versions.push((base, Some(ver), false));
        } else {
            dynstr.add(name);
            sym_versions.push((name.clone(), None, false));
        }
    }
    // Version node names must be in .dynstr BEFORE dynstr_size is computed.
    for v in &version_set {
        dynstr.add(v);
    }
    let versioned_name = version_script.as_ref().map(|vs| vs.version_name.clone());''',
'version_split')

sub1('src/backend/x86/linker/emit_shared.rs',
'''    let (versym_data, verdef_data, verdef_count): (Vec<u8>, Vec<u8>, u64) = if let Some(ref vn) = versioned_name {
        let mut versym = Vec::with_capacity(dynsym_count as usize * 2);
        // dynsym[0]
        versym.extend_from_slice(&0u16.to_le_bytes());
        for name in &dyn_sym_names {
            let idx: u16 = if let Some(g) = globals.get(name) {
                if g.defined_in.is_some() && g.section_idx != SHN_UNDEF {
                    2 // exported definition belongs to the version node
                } else {
                    1 // unversioned global/undefined symbol
                }
            } else { 1 };
            versym.extend_from_slice(&idx.to_le_bytes());
        }
        let mut verdef = Vec::new();
        let base_off = dynstr.get_offset(&base_version_name);
        let ver_off = dynstr.get_offset(vn);
        push_verdef_entry(&mut verdef, 1, &base_version_name, base_off, 28);
        push_verdef_entry(&mut verdef, 2, vn, ver_off, 0);
        (versym, verdef, 2)
    } else {
        (Vec::new(), Vec::new(), 0)
    };''',
'''    let (versym_data, verdef_data, verdef_count): (Vec<u8>, Vec<u8>, u64) = if !version_set.is_empty() {
        // Proper GNU versioning from the objects' .symver names: one verdef
        // node per version; each dynsym entry's versym index selects its node.
        // The base node (1) carries the SONAME.
        let mut versym = Vec::with_capacity(dynsym_count as usize * 2);
        versym.extend_from_slice(&0u16.to_le_bytes()); // dynsym[0]
        for (_, ver, _) in &sym_versions {
            let idx: u16 = match ver {
                Some(v) => 2 + version_set.iter().position(|x| x == v).unwrap_or(0) as u16,
                None => 1,
            };
            versym.extend_from_slice(&idx.to_le_bytes());
        }
        let mut verdef = Vec::new();
        let base_off = dynstr.get_offset(&base_version_name);
        push_verdef_entry(&mut verdef, 1, &base_version_name, base_off, 28);
        for (i, v) in version_set.iter().enumerate() {
            let voff = dynstr.get_offset(v);
            push_verdef_entry(&mut verdef, (2 + i) as u16, v, voff, 0);
        }
        (versym, verdef, 1 + version_set.len() as u64)
    } else if let Some(ref vn) = versioned_name {
        let mut versym = Vec::with_capacity(dynsym_count as usize * 2);
        versym.extend_from_slice(&0u16.to_le_bytes());
        for name in &dyn_sym_names {
            let idx: u16 = if let Some(g) = globals.get(name) {
                if g.defined_in.is_some() && g.section_idx != SHN_UNDEF {
                    2
                } else {
                    1
                }
            } else { 1 };
            versym.extend_from_slice(&idx.to_le_bytes());
        }
        let mut verdef = Vec::new();
        let base_off = dynstr.get_offset(&base_version_name);
        let ver_off = dynstr.get_offset(vn);
        push_verdef_entry(&mut verdef, 1, &base_version_name, base_off, 28);
        push_verdef_entry(&mut verdef, 2, vn, ver_off, 0);
        (versym, verdef, 2)
    } else {
        (Vec::new(), Vec::new(), 0)
    };''',
'versym_multi')

# gnu_hash on base names
sub1('src/backend/x86/linker/emit_shared.rs',
'''    let hashed_sym_hashes: Vec<u32> = defined_syms.iter()
        .map(|name| linker_common::gnu_hash(name.as_bytes()))
        .collect();''',
'''    let hashed_sym_hashes: Vec<u32> = defined_syms.iter()
        .map(|name| linker_common::gnu_hash(sym_base(name).as_bytes()))
        .collect();''',
'hash_base1')

sub1('src/backend/x86/linker/emit_shared.rs',
'''    let hashed_sym_hashes: Vec<u32> = dyn_sym_names[undef_syms.len()..].iter()
        .map(|name| linker_common::gnu_hash(name.as_bytes()))
        .collect();''',
'''    let hashed_sym_hashes: Vec<u32> = dyn_sym_names[undef_syms.len()..].iter()
        .map(|name| linker_common::gnu_hash(sym_base(name).as_bytes()))
        .collect();''',
'hash_base2')

sub1('src/backend/x86/linker/emit_shared.rs',
'''    let mut ds = dynsym_offset as usize + 24; // skip null entry
    for name in &dyn_sym_names {
        let no = dynstr.get_offset(name) as u32;
        w32(&mut out, ds, no);''',
'''    let mut ds = dynsym_offset as usize + 24; // skip null entry
    for name in &dyn_sym_names {
        let no = dynstr.get_offset(&sym_base(name)) as u32;
        w32(&mut out, ds, no);''',
'dynsym_base')

sub1('src/backend/x86/linker/emit_shared.rs',
'''#[derive(Debug, Clone)]
struct VersionScript {''',
'''/// Strip the .symver version suffix from a linker symbol name:
/// "foo@@GLIBC_2.34" / "foo@GLIBC_2.2.5" -> "foo".
fn sym_base(name: &str) -> String {
    if let Some(pos) = name.find('@') {
        name[..pos].to_string()
    } else {
        name.to_string()
    }
}

#[derive(Debug, Clone)]
struct VersionScript {''',
'sym_base_helper')

print("ROUND-14 GNU VERSIONING APPLIED")
