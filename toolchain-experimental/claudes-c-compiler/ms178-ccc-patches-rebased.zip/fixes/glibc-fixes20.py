#!/usr/bin/env python3
"""glibc-fixes20.py — v6.3 fix #35: versioned .symver REFERENCES (GCC/GNU-as
semantics). glibc's math-svid-compat.h emits `compat_symbol_reference` =
`.symver real, name@VER` top-level asm for symbols NOT defined in the TU
(matherr, _LIB_VERSION in k_standardl.c). GCC turns every reference to
`real` into a versioned reference `name@VER`; GNU ld 2.47 refuses to bind
unversioned refs to `foo@VER` definitions under --whole-archive (libm.so
link: "undefined reference to `_LIB_VERSION'/'matherr'").

Three parts:
 a) lower.rs: symver_ref_map (real -> "name@VER") populated in a PRE-PASS
    (before body lowering) from top-level `.symver` asm when `real` is not
    DEFINED in the TU (function def or initialized/non-extern global);
    resolve_ref_name() applies it at every reference site (expr.rs, lvalue.rs,
    structs.rs, expr_access.rs, expr_calls.rs, const_eval_global_addr.rs).
 b) elf_writer_common.rs: the assembler applies the same rule to relocations —
    `.symver real, name@VER` where `real` is never defined as a label rewrites
    the relocation symbol to `name@VER` after all items are parsed (GNU as
    behavior, verified: `movl _LIB_VERSION(%rip)` + .symver -> reloc
    `_LIB_VERSION@GLIBC_2.2.5`). `@@` -> `@` for references.
Verified: nm shows `U _LIB_VERSION@GLIBC_2.2.5` (GCC parity); 57/57 green.
"""
import sys

SRC = '/home/user/ccc-work/sources/ccc-src/'

def sub1(path, old, new, tag):
    p = SRC + path
    s = open(p).read()
    if new in s:
        print(f"skip (already applied): {tag}")
        return
    n = s.count(old)
    if n != 1:
        print(f"FAIL {tag}: {path}: found {n} of {old[:70]!r}")
        sys.exit(1)
    open(p, 'w').write(s.replace(old, new))
    print(f"ok {tag}: {path}")

# ---- a1: field ----
sub1('src/ir/lowering/lower.rs',
'''    pub(super) asm_label_map: FxHashMap<String, String>,''',
'''    pub(super) asm_label_map: FxHashMap<String, String>,
    /// Versioned symbol references from top-level `.symver real, name@VER`
    /// where `real` is NOT defined in this TU. GCC semantics: all references
    /// to `real` become references to `name@VER` (glibc
    /// `compat_symbol_reference`; GNU ld 2.47 refuses to bind unversioned
    /// refs to `foo@VER` definitions under --whole-archive).
    pub(super) symver_ref_map: FxHashMap<String, String>,''',
'symver_field')

sub1('src/ir/lowering/lower.rs',
'''            asm_label_map: FxHashMap::default(),''',
'''            asm_label_map: FxHashMap::default(),
            symver_ref_map: FxHashMap::default(),''',
'symver_init')

# ---- a2: helper ----
sub1('src/ir/lowering/lower.rs',
'''    /// Register function metadata (return type, param types, variadic, sret) for''',
'''    /// Resolve a symbol reference: versioned .symver references first (glibc
    /// compat_symbol_reference), then __asm__("label") redirects, else the
    /// plain name.
    pub(super) fn resolve_ref_name(&self, name: &str) -> String {
        if let Some(v) = self.symver_ref_map.get(name) {
            return v.clone();
        }
        self.asm_label_map
            .get(name)
            .cloned()
            .unwrap_or_else(|| name.to_string())
    }

    /// Register function metadata (return type, param types, variadic, sret) for''',
'resolve_helper')

# ---- a3: pre-pass (before body lowering) ----
sub1('src/ir/lowering/lower.rs',
'''        // Collect constructor/destructor/alias attributes from function definitions and declarations
        for decl in &tu.decls {''',
'''        // Pre-pass: versioned .symver references (GCC semantics). glibc's
        // compat_symbol_reference emits `.symver real, name@VER` as top-level
        // asm; when `real` is NOT defined in this TU, every reference to it
        // must become a versioned reference `name@VER` (GNU ld 2.47 refuses
        // to bind unversioned refs to `foo@VER` under --whole-archive).
        // Must run BEFORE body lowering so references lower correctly.
        {
            let mut defined: std::collections::HashSet<String> =
                std::collections::HashSet::new();
            // Function DEFINITIONS (a mere declaration does not count: glibc's
            // compat_symbol_reference versionizes references to declared-only
            // functions like matherr).
            for decl in &tu.decls {
                if let ExternalDecl::FunctionDef(func) = decl {
                    defined.insert(func.name.clone());
                }
            }
            for decl in &tu.decls {
                if let ExternalDecl::Declaration(decl) = decl {
                    for declarator in &decl.declarators {
                        if !declarator.name.is_empty()
                            && (declarator.init.is_some() || !decl.is_extern())
                        {
                            defined.insert(declarator.name.clone());
                        }
                    }
                }
            }
            for decl in &tu.decls {
                if let ExternalDecl::TopLevelAsm(asm_str) = decl {
                    for line in asm_str.lines() {
                        let t = line.trim();
                        if let Some(rest) = t.strip_prefix(".symver") {
                            let rest = rest.trim();
                            if let Some(comma) = rest.find(',') {
                                let real = rest[..comma].trim().to_string();
                                let alias_ver = rest[comma + 1..].trim().to_string();
                                if !real.is_empty() && alias_ver.contains('@')
                                    && !defined.contains(&real)
                                {
                                    self.symver_ref_map.insert(real, alias_ver);
                                }
                            }
                        }
                    }
                }
            }
        }

        // Collect constructor/destructor/alias attributes from function definitions and declarations
        for decl in &tu.decls {''',
'symver_prepass')

# ---- a4: reference sites ----
sub1('src/ir/lowering/expr.rs',
'''            let resolved = self.asm_label_map.get(name).cloned().unwrap_or_else(|| name.to_string());''',
'''            let resolved = self.resolve_ref_name(name);''',
'ref_expr1')

sub1('src/ir/lowering/expr.rs',
'''            let resolved_name = self.asm_label_map.get(name)
                .cloned()
                .unwrap_or_else(|| name.to_string());
            return self.load_global_var(resolved_name, &ginfo);''',
'''            let resolved_name = self.resolve_ref_name(name);
            return self.load_global_var(resolved_name, &ginfo);''',
'ref_expr2')

sub1('src/ir/lowering/expr.rs',
'''        // Note: implicit declaration warnings are emitted during sema, not here.
        // Apply __asm__("label") linker symbol redirect if present.
        let resolved_name = self.asm_label_map.get(name)
            .cloned()
            .unwrap_or_else(|| name.to_string());
        let dest = self.fresh_value();
        self.emit(Instruction::GlobalAddr { dest, name: resolved_name });''',
'''        // Note: implicit declaration warnings are emitted during sema, not here.
        // Apply __asm__("label") linker symbol redirect if present.
        let resolved_name = self.resolve_ref_name(name);
        let dest = self.fresh_value();
        self.emit(Instruction::GlobalAddr { dest, name: resolved_name });''',
'ref_expr3')

sub1('src/ir/lowering/lvalue.rs',
'''                    let resolved_name = self.asm_label_map.get(name)
                        .cloned()
                        .unwrap_or_else(|| name.clone());
                    let addr = self.fresh_value();
                    self.emit(Instruction::GlobalAddr { dest: addr, name: resolved_name });
                    Some(LValue::Address(addr, addr_space))''',
'''                    let resolved_name = self.resolve_ref_name(name);
                    let addr = self.fresh_value();
                    self.emit(Instruction::GlobalAddr { dest: addr, name: resolved_name });
                    Some(LValue::Address(addr, addr_space))''',
'ref_lvalue1')

sub1('src/ir/lowering/lvalue.rs',
'''                    let resolved_name = self.asm_label_map.get(name)
                        .cloned()
                        .unwrap_or_else(|| name.clone());
                    let addr = self.fresh_value();
                    self.emit(Instruction::GlobalAddr { dest: addr, name: resolved_name });
                    let is_inline_data = ginfo.is_array || ginfo.c_type.as_ref().is_some_and(|ct| ct.is_vector());''',
'''                    let resolved_name = self.resolve_ref_name(name);
                    let addr = self.fresh_value();
                    self.emit(Instruction::GlobalAddr { dest: addr, name: resolved_name });
                    let is_inline_data = ginfo.is_array || ginfo.c_type.as_ref().is_some_and(|ct| ct.is_vector());''',
'ref_lvalue2')

sub1('src/ir/lowering/structs.rs',
'''                    let resolved_name = self.asm_label_map.get(name)
                        .cloned()
                        .unwrap_or_else(|| name.clone());
                    let addr = self.fresh_value();
                    self.emit(Instruction::GlobalAddr { dest: addr, name: resolved_name });
                    return addr;''',
'''                    let resolved_name = self.resolve_ref_name(name);
                    let addr = self.fresh_value();
                    self.emit(Instruction::GlobalAddr { dest: addr, name: resolved_name });
                    return addr;''',
'ref_structs')

sub1('src/ir/lowering/expr_access.rs',
'''            let resolved = self.asm_label_map.get(name.as_str())
                .cloned()
                .unwrap_or_else(|| name.clone());''',
'''            let resolved = self.resolve_ref_name(name.as_str());''',
'ref_expr_access')

sub1('src/ir/lowering/expr_calls.rs',
'''                    let call_name = self.asm_label_map.get(name.as_str())
                        .cloned()
                        .unwrap_or_else(|| name.to_string());''',
'''                    let call_name = self.resolve_ref_name(name.as_str());''',
'ref_calls1')

sub1('src/ir/lowering/expr_calls.rs',
'''                    let call_name = self.asm_label_map.get(call_name.as_str())
                        .cloned()
                        .unwrap_or_else(|| call_name.to_string());''',
'''                    let call_name = self.resolve_ref_name(call_name.as_str());''',
'ref_calls2')

sub1('src/ir/lowering/const_eval_global_addr.rs',
'''                            let resolved = self.asm_label_map.get(name.as_str())
                                .cloned()
                                .unwrap_or_else(|| name.to_string());''',
'''                            let resolved = self.resolve_ref_name(name.as_str());''',
'ref_cega1')

sub1('src/ir/lowering/const_eval_global_addr.rs',
'''                    let resolved = self.asm_label_map.get(name.as_str())
                        .cloned()
                        .unwrap_or_else(|| name.to_string());''',
'''                    let resolved = self.resolve_ref_name(name.as_str());''',
'ref_cega2')

# ---- b: assembler-side relocation rewrite ----
sub1('src/backend/elf_writer_common.rs',
'''    aliases: HashMap<String, String>,''',
'''    aliases: HashMap<String, String>,
    /// `.symver real, name@VER` where `real` is NOT defined in this object:
    /// GNU-as semantics — every reference to `real` becomes a versioned
    /// reference `name@VER` (glibc compat_symbol_reference; needed because
    /// GNU ld 2.47 does not bind unversioned refs to foo@VER under
    /// --whole-archive). Applied to relocations after all items are parsed.
    symver_refs: HashMap<String, String>,''',
'asm_symver_field')

sub1('src/backend/elf_writer_common.rs',
'''            aliases: HashMap::new(),''',
'''            aliases: HashMap::new(),
            symver_refs: HashMap::new(),''',
'asm_symver_init')

sub1('src/backend/elf_writer_common.rs',
'''                if ver_string.contains('@') {
                    if !ver_string.is_empty() {
                        self.aliases.insert(ver_string.clone(), name.clone());
                    }
                }''',
'''                if ver_string.contains('@') {
                    if !ver_string.is_empty() {
                        self.aliases.insert(ver_string.clone(), name.clone());
                        // Candidate versioned REFERENCE: applied only when
                        // `name` is never defined in this object (checked in
                        // build() after all items are parsed).
                        self.symver_refs.insert(name.clone(), ver_string.clone());
                    }
                }''',
'asm_symver_collect')

sub1('src/backend/elf_writer_common.rs',
'''    pub fn build(mut self, items: &[AsmItem]) -> Result<Vec<u8>, String> {
        let items = resolve_numeric_labels(items);
        for item in &items {
            self.process_item(item)?;
        }
        self.emit_elf()
    }''',
'''    pub fn build(mut self, items: &[AsmItem]) -> Result<Vec<u8>, String> {
        let items = resolve_numeric_labels(items);
        for item in &items {
            self.process_item(item)?;
        }
        // GNU-as .symver references: if `real` was never defined as a label,
        // rewrite relocations against it to the versioned name (foo@VER).
        // `@@` in a reference selects the default version -> single @.
        if !self.symver_refs.is_empty() {
            let defined: std::collections::HashSet<&String> =
                self.label_positions.keys().collect();
            for sec in self.sections.iter_mut() {
                for reloc in sec.relocations.iter_mut() {
                    if let Some(ver) = self.symver_refs.get(&reloc.symbol) {
                        if !defined.contains(&reloc.symbol) {
                            reloc.symbol = ver.replace("@@", "@");
                        }
                    }
                }
            }
        }
        self.emit_elf()
    }''',
'asm_symver_apply')

print("ROUND-20 VERSIONED SYMVER REFERENCES APPLIED")
