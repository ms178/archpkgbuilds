#!/usr/bin/env python3
"""glibc-fixes12.py — v6.3 fix #17: _Float128 <-> i128 conversions.

glibc wcstof128_l.c casts F128 -> unsigned __int128 ("internal error:
unsupported float-to-i128 conversion: F128").

Design (x86-64, single-XMM SysV ABI):
- F128 -> i128: load the 16-byte value into %xmm0 (slot / vec-live-reg /
  pointer), call libgcc __fixtfti / __fixunstfti (result %rdx:%rax).
- i128 -> F128: call __floattitf / __floatuntitf; result stays in %xmm0;
  new trait method emit_store_f128_xmm0 stores it (slot / xmm reg / (rax)).
"""
import sys

SRC = '/home/user/ccc-work/sources/ccc-src/'

def sub1(path, old, new, tag):
    p = SRC + path
    s = open(p).read()
    if new in s:
        print(f"skip (already applied): {tag}: {path}")
        return
    n = s.count(old)
    if n != 1:
        print(f"FAIL {tag}: {path}: found {n} of {old[:70]!r}")
        sys.exit(1)
    open(p, 'w').write(s.replace(old, new))
    print(f"ok {tag}: {path}")

sub1('src/backend/x86/codegen/i128_ops.rs',
'''    pub(super) fn emit_float_to_i128_call_impl(&mut self, src: &Operand, to_signed: bool, from_ty: IrType) {
        self.operand_to_rax(src);
        if from_ty == IrType::F32 {
            self.state.emit("    movd %eax, %xmm0");
        } else {
            self.state.emit("    movq %rax, %xmm0");
        }
        let func_name = match (to_signed, from_ty) {
            (true, IrType::F64)  => "__fixdfti",
            (true, IrType::F32)  => "__fixsfti",
            (false, IrType::F64) => "__fixunsdfti",
            (false, IrType::F32) => "__fixunssfti",
            _ => panic!("unsupported float-to-i128 conversion: {:?}", from_ty),
        };
        self.state.emit_fmt(format_args!("    call {}@PLT", func_name));
        self.state.reg_cache.invalidate_all();
    }''',
'''    pub(super) fn emit_float_to_i128_call_impl(&mut self, src: &Operand, to_signed: bool, from_ty: IrType) {
        if from_ty == IrType::F128 {
            // _Float128 (binary128): ONE XMM register per SysV psABI. Load the
            // 16-byte value into %xmm0, then call libgcc's __fixtfti /
            // __fixunstfti (i128 result in %rdx:%rax).
            match src {
                Operand::Value(v) => {
                    if let Some(slot) = self.state.get_slot(v.0) {
                        self.state.out.emit_instr_rbp_reg("    movdqu", slot.0, "xmm0");
                    } else if let Some(&held) = self.state.vec_live_regs.get(&v.0) {
                        if held != "xmm0" {
                            self.state
                                .emit_fmt(format_args!("    movdqa %{}, %xmm0", held));
                        }
                    } else {
                        self.operand_to_reg(src, "rax");
                        self.state.emit("    movdqu (%rax), %xmm0");
                    }
                }
                _ => {
                    self.operand_to_reg(src, "rax");
                    self.state.emit("    movdqu (%rax), %xmm0");
                }
            }
            let func_name = if to_signed { "__fixtfti" } else { "__fixunstfti" };
            self.state.emit_fmt(format_args!("    call {}@PLT", func_name));
            self.state.reg_cache.invalidate_all();
            return;
        }
        self.operand_to_rax(src);
        if from_ty == IrType::F32 {
            self.state.emit("    movd %eax, %xmm0");
        } else {
            self.state.emit("    movq %rax, %xmm0");
        }
        let func_name = match (to_signed, from_ty) {
            (true, IrType::F64)  => "__fixdfti",
            (true, IrType::F32)  => "__fixsfti",
            (false, IrType::F64) => "__fixunsdfti",
            (false, IrType::F32) => "__fixunssfti",
            _ => panic!("unsupported float-to-i128 conversion: {:?}", from_ty),
        };
        self.state.emit_fmt(format_args!("    call {}@PLT", func_name));
        self.state.reg_cache.invalidate_all();
    }''',
'f128_to_i128')

sub1('src/backend/x86/codegen/i128_ops.rs',
'''        let func_name = match (from_signed, to_ty) {
            (true, IrType::F64)  => "__floattidf",
            (true, IrType::F32)  => "__floattisf",
            (false, IrType::F64) => "__floatuntidf",
            (false, IrType::F32) => "__floatuntisf",
            _ => panic!("unsupported i128-to-float conversion: {:?}", to_ty),
        };
        self.state.emit_fmt(format_args!("    call {}@PLT", func_name));
        self.state.reg_cache.invalidate_all();
        if to_ty == IrType::F32 {
            self.state.emit("    movd %xmm0, %eax");
        } else {
            self.state.emit("    movq %xmm0, %rax");
        }
    }''',
'''        let func_name = match (from_signed, to_ty) {
            (true, IrType::F64)  => "__floattidf",
            (true, IrType::F32)  => "__floattisf",
            (true, IrType::F128) => "__floattitf",
            (false, IrType::F64) => "__floatuntidf",
            (false, IrType::F32) => "__floatuntisf",
            (false, IrType::F128) => "__floatuntitf",
            _ => panic!("unsupported i128-to-float conversion: {:?}", to_ty),
        };
        self.state.emit_fmt(format_args!("    call {}@PLT", func_name));
        self.state.reg_cache.invalidate_all();
        if to_ty == IrType::F128 {
            // _Float128 result stays in %xmm0 (single-XMM SysV ABI).
            return;
        }
        if to_ty == IrType::F32 {
            self.state.emit("    movd %xmm0, %eax");
        } else {
            self.state.emit("    movq %xmm0, %rax");
        }
    }''',
'i128_to_f128')

sub1('src/backend/traits.rs',
'''    /// Emit f32/f64 -> i128/u128 conversion via compiler-rt call.
    /// `src` is the float operand, `to_signed` indicates signed vs unsigned,
    /// `from_ty` is F32 or F64. Result should be left in the acc pair.
    fn emit_float_to_i128_call(&mut self, src: &Operand, to_signed: bool, from_ty: IrType);''',
'''    /// Emit f32/f64 -> i128/u128 conversion via compiler-rt call.
    /// `src` is the float operand, `to_signed` indicates signed vs unsigned,
    /// `from_ty` is F32 or F64. Result should be left in the acc pair.
    fn emit_float_to_i128_call(&mut self, src: &Operand, to_signed: bool, from_ty: IrType);

    /// Store a _Float128 result still in %xmm0 (single-XMM SysV ABI) to `dest`.
    /// Only needed for the i128 -> _Float128 cast path; other arches panic.
    fn emit_store_f128_xmm0(&mut self, _dest: &Value) {
        unimplemented!("_Float128 i128-cast result storage not implemented on this target")
    }''',
'trait_f128_store')

sub1('src/backend/x86/codegen/globals.rs',
'''    // These thin helpers avoid circular delegation issues:
    fn emit_store_result_impl(&mut self, dest: &Value) {
        self.store_rax_to(dest);
    }''',
'''    // These thin helpers avoid circular delegation issues:
    fn emit_store_result_impl(&mut self, dest: &Value) {
        self.store_rax_to(dest);
    }

    fn emit_store_f128_xmm0(&mut self, dest: &Value) {
        if self
            .state
            .value_use_counts
            .get(dest.0 as usize)
            .copied()
            .unwrap_or(0)
            == 0
        {
            return;
        }
        if let Some(&reg) = self.reg_assignments.get(&dest.0) {
            if is_xmm_reg(reg) && reg.0 != 0 {
                self.state
                    .emit_fmt(format_args!("    movdqa %xmm0, %{}", phys_reg_name(reg)));
                return;
            }
        }
        if let Some(slot) = self.state.get_slot(dest.0) {
            self.state.out.emit_instr_reg_rbp("    movdqu", "xmm0", slot.0);
            return;
        }
        self.operand_to_reg(&Operand::Value(*dest), "rax");
        self.state.emit("    movdqu %xmm0, (%rax)");
    }''',
'x86_f128_store')

sub1('src/backend/traits.rs',
'''    // i128/u128 -> float/double: call compiler-rt __floattidf/__floattisf/__floatuntidf/__floatuntisf
    if is_i128_type(from_ty) && to_ty.is_float() {
        let from_signed = from_ty.is_signed();
        cg.emit_i128_to_float_call(src, from_signed, to_ty);
        cg.emit_store_result(dest);
        return;
    }''',
'''    // i128/u128 -> float/double: call compiler-rt __floattidf/__floattisf/__floatuntidf/__floatuntisf
    if is_i128_type(from_ty) && to_ty.is_float() {
        let from_signed = from_ty.is_signed();
        cg.emit_i128_to_float_call(src, from_signed, to_ty);
        if to_ty == IrType::F128 {
            // _Float128 result stays in %xmm0 (single-XMM SysV ABI).
            cg.emit_store_f128_xmm0(dest);
        } else {
            cg.emit_store_result(dest);
        }
        return;
    }''',
'cast_route_f128')

print("ROUND-12 F128<->I128 CASTS APPLIED")
