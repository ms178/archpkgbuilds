#!/usr/bin/env python3
"""glibc-fixes8.py — v6.3 fix #13: GNU-as symbol-difference parsing for data
directives (`(.LSTART_restore_rt-1)-.` in glibc .eh_frame / x86_64 .S files).

Agent A's v6.2 only parsed plain `sym-sym` diffs in immediates; the
parenthesized, addend-carrying, and dot-relative forms fell through to a
literal Symbol reference, producing
"relocation R_X86_64_32 against undefined symbol `(.LSTART_restore_rt-1)-.'"
at the ld.so link. Ported from my v6.2 (validated against GNU as 2.44/2.47:
.eh_frame byte-identical).
"""
import sys

SRC = '/home/user/ccc-work/sources/ccc-src/'

def sub1(path, old, new, tag=''):
    p = SRC + path
    s = open(p).read()
    if new in s:
        print(f"skip (already applied): {tag}: {path}")
        return
    n = s.count(old)
    if n != 1:
        print(f"FAIL {tag}: {path}: found {n} of {old[:70]!r}")
        sys.exit(1)
    open(p, 'w').write(s.replace(old, new))
    print(f"ok {tag}: {path}")

sub1('src/backend/x86/assembler/parser.rs',
'''        // Check for symbol+offset or symbol-offset (e.g., GD_struct+128, arr+33)
        if let Some(val) = parse_symbol_offset(trimmed) {
            vals.push(val);
            continue;
        }

        // Symbol reference''',
'''        // Check for symbol+offset or symbol-offset (e.g., GD_struct+128, arr+33)
        if let Some(val) = parse_symbol_offset(trimmed) {
            vals.push(val);
            continue;
        }

        // GNU as symbol-difference forms without spaces or with parentheses
        // (glibc .eh_frame emits `(.LSTART_restore_rt-1)-.`,
        //  `.LEND_restore_rt-(.LSTART_restore_rt-1)`, `.LENDCIE_-.LSTARTCIE_`).
        if let Some(val) = try_parse_sym_diff(trimmed) {
            vals.push(val);
            continue;
        }

        // Symbol reference''',
'symdiff_call')

sub1('src/backend/x86/assembler/parser.rs',
'''/// Parse symbol+offset or symbol-offset expressions (e.g., GD_struct+128).''',
'''/// Split `sym`, `sym+N`, `sym-N`, `(sym±N)` into (symbol, addend) where the
/// value equals `symbol + addend`. Returns None for non-label strings.
fn parse_sym_addend(s: &str) -> Option<(String, i64)> {
    let t = s.trim();
    let t = t.strip_prefix('(').and_then(|x| x.strip_suffix(')')).unwrap_or(t);
    let t = t.trim();
    if t.is_empty() {
        return None;
    }
    for (i, c) in t.char_indices().skip(1) {
        if c == '+' || c == '-' {
            let sym = t[..i].trim();
            if !is_label_like(sym) {
                continue;
            }
            let num_raw: String = t[i..].chars().filter(|c| !c.is_whitespace()).collect();
            let v: i64 = if let Some(r) = num_raw.strip_prefix('+') {
                r.parse().ok()?
            } else if let Some(r) = num_raw.strip_prefix('-') {
                -r.parse::<i64>().ok()?
            } else {
                continue;
            };
            return Some((sym.to_string(), v));
        }
    }
    if is_label_like(t) {
        Some((t.to_string(), 0))
    } else {
        None
    }
}

/// Parse GNU-as symbol-difference expressions that lack spaces around the
/// operator or use parentheses: `(a-1)-.`, `a-(b-1)`, `(a+2)-b`, `a-b`.
/// Returns DataValue::SymbolDiffAddend(a, b, add) meaning `a - b + add`.
fn try_parse_sym_diff(s: &str) -> Option<DataValue> {
    let s = s.trim();
    if s.is_empty() {
        return None;
    }
    let bytes = s.as_bytes();
    let mut depth = 0i32;
    for i in 0..bytes.len() {
        let c = bytes[i] as char;
        if c == '(' {
            depth += 1;
        } else if c == ')' {
            depth -= 1;
        } else if c == '-' && depth == 0 && i > 0 {
            let lhs = &s[..i];
            let rhs = &s[i + 1..];
            let (a, add_a) = parse_sym_addend(lhs)?;
            if rhs.trim() == "." {
                // (a ± N) - .  ==  a - . ± N   (PC-relative, GNU as encodes as
                // a PC32 reloc with the addend folded in)
                return Some(DataValue::SymbolDiffAddend(a, ".".to_string(), add_a));
            }
            if let Some((b, add_b)) = parse_sym_addend(rhs) {
                // a + add_a - (b + add_b) = a - b + (add_a - add_b)
                return Some(DataValue::SymbolDiffAddend(a, b, add_a - add_b));
            }
            return None;
        }
    }
    None
}

/// Parse symbol+offset or symbol-offset expressions (e.g., GD_struct+128).''',
'symdiff_helpers')

print("ROUND-8 SYMDIFF PORT APPLIED")
